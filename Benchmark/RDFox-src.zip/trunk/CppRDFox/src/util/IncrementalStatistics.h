// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifndef INCREMENTALSTATISTICS_H_
#define INCREMENTALSTATISTICS_H_

#include "../reasoning/IncrementalMonitor.h"
#include "AbstractStatistics.h"

class IncrementalStatistics : public AbstractStatisticsImpl<IncrementalMonitor> {

public:

    static const size_t SUMMARY_EDB_BEFORE                                      = 0;
    static const size_t SUMMARY_IDB_BEFORE                                      = SUMMARY_EDB_BEFORE + 1;
    static const size_t SUMMARY_TO_DELETE                                       = SUMMARY_IDB_BEFORE + 1;
    static const size_t SUMMARY_TO_INSERT                                       = SUMMARY_TO_DELETE + 1;
    static const size_t SUMMARY_EDB_AFTER                                       = SUMMARY_TO_INSERT + 1;
    static const size_t SUMMARY_IDB_AFTER                                       = SUMMARY_EDB_AFTER + 1;

    static const size_t EVALUATION_OF_DELETED_RULES_TITLE                       = SUMMARY_IDB_AFTER + 1;

    static const size_t BACKWARD_FORWARD_TITLE                                  = EVALUATION_OF_DELETED_RULES_TITLE + 1 + NUMBER_OF_DERIVATION_COUNTERS;
    static const size_t BACKWARD_FORWARD_EXTRACTED_TUPLES                       = BACKWARD_FORWARD_TITLE + 1;
    static const size_t BACKWARD_FORWARD_EXTRACTED_TUPLES_PROVED                = BACKWARD_FORWARD_EXTRACTED_TUPLES + 1;
    static const size_t BACKWARD_FORWARD_ADDED_TO_CHECKED                       = BACKWARD_FORWARD_EXTRACTED_TUPLES_PROVED + 1;
    static const size_t BACKWARD_FORWARD_ADDED_TO_CHECKED_OPTIMIZED             = BACKWARD_FORWARD_ADDED_TO_CHECKED + 1;
    static const size_t BACKWARD_FORWARD_RULES                                  = BACKWARD_FORWARD_ADDED_TO_CHECKED_OPTIMIZED + 1;
    static const size_t BACKWARD_FORWARD_RULES_NO_INSTANCE                      = BACKWARD_FORWARD_RULES + 1;
    static const size_t BACKWARD_FORWARD_RULE_INSTANCES                         = BACKWARD_FORWARD_RULES_NO_INSTANCE + 1;
    static const size_t BACKWARD_FORWARD_RULE_INSTANCES_REPLACEMENT             = BACKWARD_FORWARD_RULE_INSTANCES + 1;
    static const size_t BACKWARD_FORWARD_RULE_INSTANCES_REFLEXIVITY             = BACKWARD_FORWARD_RULE_INSTANCES_REPLACEMENT + 1;
    static const size_t BACKWARD_FORWARD_RULE_INSTANCES_RULES                   = BACKWARD_FORWARD_RULE_INSTANCES_REFLEXIVITY + 1;

    static const size_t BACKWARD_FORWARD_FORWARD_TITLE                          = BACKWARD_FORWARD_RULE_INSTANCES_RULES + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_DELAYED                        = BACKWARD_FORWARD_FORWARD_TITLE + 1 + NUMBER_OF_DERIVATION_COUNTERS;
    static const size_t BACKWARD_FORWARD_FORWARD_DELAYED_REPLACEMENT            = BACKWARD_FORWARD_FORWARD_DELAYED + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_DELAYED_REPLACEMENT_SUCCESFUL  = BACKWARD_FORWARD_FORWARD_DELAYED_REPLACEMENT + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_DELAYED_REFLEXIVITY            = BACKWARD_FORWARD_FORWARD_DELAYED_REPLACEMENT_SUCCESFUL + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_DELAYED_REFLEXIVITY_SUCCESFUL  = BACKWARD_FORWARD_FORWARD_DELAYED_REFLEXIVITY + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_DELAYED_RULES                  = BACKWARD_FORWARD_FORWARD_DELAYED_REFLEXIVITY_SUCCESFUL + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_DELAYED_RULES_SUCCESFUL        = BACKWARD_FORWARD_FORWARD_DELAYED_RULES + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_SHORT_CIRCUIT_REFLEXIVITY_EDB  = BACKWARD_FORWARD_FORWARD_DELAYED_RULES_SUCCESFUL + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_DENORMALIZED_CHECKED           = BACKWARD_FORWARD_FORWARD_SHORT_CIRCUIT_REFLEXIVITY_EDB + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_USED_DELAYED                   = BACKWARD_FORWARD_FORWARD_DENORMALIZED_CHECKED + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_USED_EDB                       = BACKWARD_FORWARD_FORWARD_USED_DELAYED + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_USED_PREVIOUS_LEVEL            = BACKWARD_FORWARD_FORWARD_USED_EDB + 1;
    static const size_t BACKWARD_FORWARD_FORWARD_DISPROVED                      = BACKWARD_FORWARD_FORWARD_USED_PREVIOUS_LEVEL + 1;

    static const size_t BACKWARD_FORWARD_PROPAGATE_DEL_TITLE                    = BACKWARD_FORWARD_FORWARD_DISPROVED + 1;

    static const size_t DELETION_PROPAGATION_TITLE                              = BACKWARD_FORWARD_PROPAGATE_DEL_TITLE + 1 + NUMBER_OF_DERIVATION_COUNTERS;
    static const size_t DELETION_PROPAGATION_DELETED                            = DELETION_PROPAGATION_TITLE + 1;
    static const size_t DELETION_PROPAGATION_DELETED_CHANGED                    = DELETION_PROPAGATION_DELETED + 1;
    static const size_t DELETION_PROPAGATION_ADDED                              = DELETION_PROPAGATION_DELETED_CHANGED + 1;
    static const size_t DELETION_PROPAGATION_ADDED_CHANGED                      = DELETION_PROPAGATION_ADDED + 1;
    static const size_t DELETION_PROPAGATION_COPIED_CLASSES                     = DELETION_PROPAGATION_ADDED_CHANGED + 1;

    static const size_t EVALUATION_OF_INSERTED_RULES_TITLE                      = DELETION_PROPAGATION_COPIED_CLASSES + 1;

    static const size_t TUPLE_INSERTION_TITLE                                   = EVALUATION_OF_INSERTED_RULES_TITLE + 1 + NUMBER_OF_DERIVATION_COUNTERS;
    static const size_t TUPLE_INSERTION_DERIVATIONS_FROM_INS                    = TUPLE_INSERTION_TITLE + 1 + NUMBER_OF_DERIVATION_COUNTERS;
    static const size_t TUPLE_INSERTION_DERIVATIONS_FROM_INS_SUCCESSFUL         = TUPLE_INSERTION_DERIVATIONS_FROM_INS + 1;

    static const size_t NUMBER_OF_INCREMENTAL_COUNTERS                          = TUPLE_INSERTION_DERIVATIONS_FROM_INS_SUCCESSFUL + 1;

protected:

    struct ThreadStateEx : public ThreadState {
        std::vector<bool> m_ruleInstanceSeenInBackwardChaining;

        ThreadStateEx(const size_t numberOfLevels, const size_t numberOfCountersPerLevel, const char* const* counterDescriptions);

    };

    virtual const char* const* describeStatistics(size_t& numberOfCounters);

    virtual std::unique_ptr<ThreadState> newThreadState(const size_t numberOfLevels, const size_t numberOfCountersPerLevel, const char* const* counterDescriptions);

public:

    IncrementalStatistics();

    virtual void taskStarted(const DataStore& dataStore, const size_t maxComponentLevel);

    virtual void taskFinished(const DataStore& dataStore);

    virtual void deletedRuleEvaluationStarted(const size_t workerIndex, const RuleInfo& ruleInfo);
    
    virtual void deletedRuleEvaluationFinished(const size_t workerIndex);
    
    virtual void addedRuleEvaluationStarted(const size_t workerIndex, const RuleInfo& ruleInfo);
    
    virtual void addedRuleEvaluationFinished(const size_t workerIndex);
    
    virtual void tupleDeletionPreviousLevelsStarted(const size_t workerIndex);

    virtual void tupleDeletionRecursiveStarted(const size_t workerIndex);

    virtual void tupleDeletionFinished(const size_t workerIndex);

    virtual void possiblyDeletedTupleExtracted(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    virtual void possiblyDeletedTupleProcessed(const size_t workerIndex, const bool proved);

    virtual void deletionPropagationStarted(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const bool fromPreviousLevel);

    virtual void propagatedDeletionViaReplacement(const size_t workerIndex, const ResourceID resourceID, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const bool wasAdded);

    virtual void deletionPropagationFinished(const size_t workerIndex);

    virtual void checkingProvabilityStarted(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const bool addedToChecked);

    virtual void tupleOptimized(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    virtual void reflexiveSameAsRuleInstancesOptimized(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    virtual void backwardReflexiveSameAsRuleInstanceStarted(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const std::vector<ResourceID>& supportingArgumentsBuffer, const std::vector<ArgumentIndex>& supportingArgumentIndexes);

    virtual void backwardReflexiveSameAsRuleInstanceFinished(const size_t workerIndex);

    virtual void backwardReplacementRuleInstanceStarted(const size_t workerIndex, const size_t positionIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    virtual void backwardReplacementRuleInstanceFinished(const size_t workerIndex);

    virtual void backwardRuleStarted(const size_t workerIndex, const HeadAtomInfo& headAtomInfo);

    virtual void backwardRuleInstanceStarted(const size_t workerIndex, const HeadAtomInfo& headAtomInfo, const SupportingFactsEvaluator& currentBodyMatches);

    virtual void backwardRuleInstanceAtomStarted(const size_t workerIndex, const HeadAtomInfo& headAtomInfo, const SupportingFactsEvaluator& currentBodyMatches, const size_t currentBodyIndex);

    virtual void backwardRuleInstanceAtomFinished(const size_t workerIndex);

    virtual void backwardRuleInstanceFinished(const size_t workerIndex);

    virtual void backwardRuleFinished(const size_t workerIndex);

    virtual void checkingProvabilityFinished(const size_t workerIndex);

    virtual void pivotlessRulePropagationStarted(const size_t workerIndex, const RuleInfo& ruleInfo);

    virtual void pivotlessRulePropagationFinished(const size_t workerIndex);

    virtual void propagateStarted(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    virtual void checkedReflexiveSameAsTupleProvedFromEDB(const size_t workerIndex, const ResourceID originalResourceID, const ResourceID denormalizedResourceID, const ResourceID normalizedProvedResourceID, const bool wasAdded);

    virtual void checkedTupleChecked(const size_t workerIndex, const std::vector<ResourceID>& originalArgumentsBuffer, const std::vector<ResourceID>& denormalizedArgumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    virtual void checkedTupleProved(const size_t workerIndex, const std::vector<ResourceID>& originalArgumentsBuffer, const std::vector<ResourceID>& denormalizedArgumentsBuffer, const std::vector<ResourceID>& normalizedProvedArgumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const bool fromEDB, const bool fromDelayed, const bool fromPrviousLevel, const bool wasAdded);

    virtual void saturateProvedStarted(const size_t workerIndex);

    virtual void tupleProvedDelayed(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const bool wasAdded);

    virtual void reflexiveSameAsTupleDerivedDelayed(const size_t workerIndex, const ResourceID resourceID, const bool wasAdded);

    virtual void tupleNormalizedDelayed(const size_t workerIndex, std::vector<ResourceID>& originalArgumentsBuffer, const std::vector<ArgumentIndex>& originalArgumentIndexes, std::vector<ResourceID>& normalizedArgumentsBuffer, const std::vector<ArgumentIndex>& normalizedArgumentIndexes, const bool wasAdded);

    virtual void checkedTupleDisproved(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const bool wasAdded);

    virtual void propagateFinished(const size_t workerIndex);

    virtual void updateEqualityManagerStarted(const size_t workerIndex);

    virtual void equivalenceClassCopied(const size_t workerIndex, const ResourceID resourceID, const EqualityManager& sourceEqualityManager, const EqualityManager& targetEqualityManager);

    virtual void updateEqualityManagerFinished(const size_t workerIndex);

    virtual void propagateDeletedProvedStarted(const size_t workerIndex);

    virtual void tupleDeleted(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const bool wasDeleted);

    virtual void tupleAdded(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const bool wasAdded);

    virtual void propagateDeletedProvedFinished(const size_t workerIndex);

    virtual void insertionPreviousLevelsStarted(const size_t workerIndex);
    
    virtual void insertionRecursiveStarted(const size_t workerIndex);

    virtual void insertedTupleAddedToIDB(const size_t workerIndex, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const bool wasAdded);

    virtual void insertionFinished(const size_t workerIndex);

};

#endif /* INCREMENTALSTATISTICS_H_ */
