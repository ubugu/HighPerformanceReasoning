// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#if defined(__APPLE__)
#pragma GCC diagnostic ignored "-Wconversion"
#endif

#if !defined(WIN32) && !defined(__APPLE__)
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wmaybe-uninitialized"
#endif

#include <dlib/all/source.cpp>
