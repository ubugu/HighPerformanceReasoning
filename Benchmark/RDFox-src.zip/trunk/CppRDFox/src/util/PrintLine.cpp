// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "PrintLine.h"

Mutex s_outputMutex;
