// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifdef WITH_TEST
#include <CppTest/main.h>
#endif

#include "../src/all.h"
#include "../src/RDFStoreException.h"
#include "../src/shell/Shell.h"

void waitForKey() {
    char c[256];
    std::cout << "Press something... ";
    std::cin >> c;
}

int runShell(int argc, char* argv[]) {
    Shell shell(std::cin, std::cout);
    {
        std::string root(argv[2]);
        size_t directoryDelimiter = root.find_last_of('/');
        if (directoryDelimiter == std::string::npos)
            directoryDelimiter = root.find_last_of('\\');
        std::string scriptName;
        if (directoryDelimiter != std::string::npos) {
            scriptName = root.substr(directoryDelimiter + 1);
            root.erase(directoryDelimiter + 1);
        }
        shell.setRootDirectory(root);
        if (!scriptName.empty())
            shell.executeCommand("exec " + scriptName);
    }
    shell.run();
    return 0;
}

int main(int argc, char* argv[]) {
    int exitCode;
#ifdef WITH_TEST
    CppTest::MainResult mainResult = CppTest::main(argc, argv);
    if (mainResult == CppTest::ALL_TESTS_PASSED)
        exitCode = 0;
    else if (mainResult == CppTest::AT_LEAST_ONE_TEST_FAILED)
        exitCode = 1;
    else
#endif
    if (argc >= 3 && ::strcmp(argv[1], "-shell") == 0)
        exitCode = runShell(argc, argv);
    else {
#ifdef WITH_TEST
        std::cout << "Usage: CppRDFox [-test | -testd] [test1 test2 ...] | -shell <directory or script>" << std::endl;
#else
        std::cout << "Usage: CppRDFox -shell <root directory>" << std::endl;
#endif
        exitCode = 1;
    }
#ifdef WIN32
        waitForKey();
#endif
    return exitCode;
}
