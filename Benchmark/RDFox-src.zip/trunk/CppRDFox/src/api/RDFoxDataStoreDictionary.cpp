// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#define _CRT_SECURE_NO_WARNINGS

#include "../../include/RDFoxDataStore.h"
#include "../dictionary/Dictionary.h"
#include "../Common.h"
#include "api.h"

bool RDFoxDataStoreDictionary_GetResource(const RDFoxDataStoreDictionary vDictionary, const RDFoxDataStoreResourceID resourceID, RDFoxDataStoreDatatypeID* datatypeID, char* const lexicalFormBuffer, size_t* const lexicalFormBufferLength) {
    API_FUNCTION_START
    Dictionary& dictionary = *reinterpret_cast<Dictionary*>(vDictionary);
    std::string lexicalForm;
    if (!dictionary.getResource(resourceID, lexicalForm, *datatypeID))
        throw RDF_STORE_EXCEPTION("ResourceID not in dictionary.");
    copyTextToMemory(lexicalForm, lexicalFormBuffer, *lexicalFormBufferLength);
    API_FUNCTION_END("Error while retrieving a resource.")
}

bool RDFoxDataStoreDictionary_GetDatatypeIRI(const RDFoxDataStoreDatatypeID datatypeID, char* const datatypeIRIBuffer, size_t* const datatypeIRIBufferSize) {
    API_FUNCTION_START
    copyTextToMemory(Dictionary::getDatatypeIRI(datatypeID), datatypeIRIBuffer, *datatypeIRIBufferSize);
    API_FUNCTION_END("Error while retrieving a datatype.")
}

bool RDFoxDataStoreDictionary_ResolveResourceValue(RDFoxDataStoreResourceID* const resourceID, const RDFoxDataStoreDictionary vDictionary, const char* const lexicalForm, const RDFoxDataStoreDatatypeID datatypeID) {
    API_FUNCTION_START
    Dictionary& dictionary = *reinterpret_cast<Dictionary*>(vDictionary);
    *resourceID = dictionary.resolveResource(lexicalForm, datatypeID);
    API_FUNCTION_END("Error while resolving a resource.")
}

bool RDFoxDataStoreDictionary_ResolveResource(RDFoxDataStoreResourceID* const resourceID, const RDFoxDataStoreDictionary vDictionary, const RDFoxDataStoreResourceTypeID resourceTypeID, const char* const lexicalForm, const char* const datatypeIRI) {
    API_FUNCTION_START
    Dictionary& dictionary = *reinterpret_cast<Dictionary*>(vDictionary);
    *resourceID = dictionary.resolveResource(static_cast<ResourceType>(resourceTypeID), lexicalForm, datatypeIRI);
    API_FUNCTION_END("Error while resolving a resource.")
}

