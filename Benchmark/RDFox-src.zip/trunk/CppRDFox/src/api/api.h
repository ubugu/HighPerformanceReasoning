// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifndef API_H_
#define API_H_

#include "../Common.h"
#include "../RDFStoreException.h"
#include "../util/ThreadLocalPointer.h"

extern ThreadLocalPointer<std::string> s_RDFoxDataStoreErrorMessage;


#define API_FUNCTION_START\
    try {\

#define API_FUNCTION_ERROR_MESSAGE\


#define API_FUNCTION_END(errorMessage)\
        return true;\
    }\
    catch (const std::exception& e) {\
        s_RDFoxDataStoreErrorMessage->assign(std::string(errorMessage) + ": " + e.what());\
    }\
    catch(...) {\
        s_RDFoxDataStoreErrorMessage->assign(errorMessage);\
    }\
    return false;


#endif /* API_H_ */
