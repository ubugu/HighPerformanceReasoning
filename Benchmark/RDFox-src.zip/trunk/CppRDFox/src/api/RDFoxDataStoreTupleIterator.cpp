// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "../../include/RDFoxDataStore.h"
#include "../logic/Logic.h"
#include "../formats/turtle/SPARQLParser.h"
#include "../dictionary/Dictionary.h"
#include "../querying/QueryCompiler.h"
#include "../storage/DataStore.h"
#include "../util/Prefixes.h"
#include "../util/APILogEntry.h"
#include "api.h"

bool RDFoxDataStoreTupleIterator_CompileQuery(RDFoxDataStoreTupleIterator* const vTupleIterator, RDFoxDataStore vDataStore, const char* const queryText, const bool useBushy, const bool useDistinct, const bool exactCardinality, const bool allAnswersInRoot) {
    API_FUNCTION_START
    DataStore& dataStore = *reinterpret_cast<DataStore*>(vDataStore);
    QueryCompiler queryCompiler(dataStore);
    queryCompiler.m_useBushyJoins = useBushy;
    queryCompiler.m_distinctThroughout = useDistinct;
    queryCompiler.m_exactCardinality = exactCardinality;
    queryCompiler.m_chooseRootWithAllAnswerVariables = allAnswersInRoot;
    Prefixes prefixes(Prefixes::s_defaultPrefixes);
    SPARQLParser parser(prefixes);
    LogicFactory factory(newLogicFactory());
    Query query = parser.parse(factory, queryText, strlen(queryText));
    *vTupleIterator = reinterpret_cast<RDFoxDataStoreTupleIterator>(queryCompiler.compileQuery(query).release());
    if (::logAPICalls()) {
        APIDataStoreLogEntry entry(dataStore);
        entry.getOutput()
            << "# RDFoxDataStoreTupleIterator_CompileQuery()" << std::endl
            << "set bushy " << (useBushy ? "true" : "false") << std::endl
            << "set distinct " << (useDistinct ? "true" : "false") << std::endl
            << "set cardinality " << (exactCardinality ? "true" : "false") << std::endl
            << "set root-has-answers " << (allAnswersInRoot ? "true" : "false") << std::endl
            << "run ! \\" << std::endl;
        for (const char* characterPointer = queryText; *characterPointer != 0; ++characterPointer) {
            if (*characterPointer == '\n')
                entry.getOutput() << "\\";
            entry.getOutput() << *characterPointer;
        }
        entry.getOutput() << std::endl << std::endl;
    }
    API_FUNCTION_END("Error while compiling the query.")
}

bool RDFoxDataStoreTupleIterator_GetArity(size_t* const arity, const RDFoxDataStoreTupleIterator vTupleIterator) {
    API_FUNCTION_START
    *arity = reinterpret_cast<TupleIterator*>(vTupleIterator)->getArity();
    API_FUNCTION_END("Error while retrieving the arity of the tuple iterator.")
}

bool RDFoxDataStoreTupleIterator_Open(size_t* const multiplicity, const RDFoxDataStoreTupleIterator vTupleIterator, const size_t arity, RDFoxDataStoreResourceID* const resourceIDs) {
    API_FUNCTION_START
    TupleIterator* iterator = reinterpret_cast<TupleIterator*>(vTupleIterator);
    if(arity != iterator->getArity())
        RDF_STORE_EXCEPTION("Mismatch between the provided arity and the iterator's arity.");
    *multiplicity = iterator->open();
    if (*multiplicity > 0)
        for (size_t index = 0; index < iterator->getArity(); index++)
            resourceIDs[index] = iterator->getArgumentsBuffer()[iterator->getArgumentIndexes()[index]];
    API_FUNCTION_END("Error while opening the iterator.")
}

bool RDFoxDataStoreTupleIterator_GetNext(size_t* const multiplicity, const RDFoxDataStoreTupleIterator vTupleIterator, const size_t arity, RDFoxDataStoreResourceID* const resourceIDs) {
    API_FUNCTION_START
    TupleIterator* iterator = reinterpret_cast<TupleIterator*>(vTupleIterator);
    if(arity != iterator->getArity())
        RDF_STORE_EXCEPTION("Mismatch between the provided arity and the iterator's arity.");
    *multiplicity = iterator->advance();
    if (*multiplicity > 0)
        for (size_t index = 0; index < iterator->getArity(); index++)
            resourceIDs[index] = iterator->getArgumentsBuffer()[iterator->getArgumentIndexes()[index]];
    API_FUNCTION_END("Error while advancing the iterator.")
}

bool RDFoxDataStoreTupleIterator_GetResource(const RDFoxDataStoreTupleIterator vTupleIterator, const RDFoxDataStoreResourceID resourceID, RDFoxDataStoreDatatypeID* datatypeID, char* const lexicalFormBuffer, size_t* const lexicalFormBufferSize) {
    API_FUNCTION_START
    const ResourceValueCache& resourceValueCache = reinterpret_cast<QueryIterator*>(vTupleIterator)->getResourceValueCache();
    std::string lexicalForm;
    if (!resourceValueCache.getResource(resourceID, lexicalForm, *datatypeID))
        throw RDF_STORE_EXCEPTION("ResourceID not in dictionary");
    copyTextToMemory(lexicalForm, lexicalFormBuffer, *lexicalFormBufferSize);
    API_FUNCTION_END("Error while retrieving a resource.")
}

void RDFoxDataStoreTupleIterator_Dispose(const RDFoxDataStoreTupleIterator vTupleIterator) {
    delete reinterpret_cast<TupleIterator*>(vTupleIterator);
}
