// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "uk_ac_ox_cs_JRDFox_store_TupleIterator.h"
#include "uk_ac_ox_cs_JRDFox_store_Dictionary.h"

#include "JRDFoxCommon.h"
#include "../storage/DataStore.h"
#include "../logic/Logic.h"
#include "../formats/turtle/SPARQLParser.h"
#include "../querying/QueryCompiler.h"
#include "../util/Prefixes.h"
#include "../util/APILogEntry.h"

JNIEXPORT jlong JNICALL Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nCompileQuery(JNIEnv* env, jclass, jlong dataStorePtr, jstring jQueryText, jobjectArray prefixesArray, jboolean useBushy, jboolean useDistinct, jboolean exactCardinality, jboolean allAnswersInRoot, jbyte queryDomain, jintArray jArityArray) {
    JNI_METHOD_START("Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nCompileQuery")
    LogicFactory factory(newLogicFactory());
    Query query;
    Prefixes prefixes = uk_ac_ox_cs_JRDFox_Common_GetPrefixes(env, prefixesArray);
    DataStore& dataStore = *reinterpret_cast<DataStore*>(dataStorePtr);
    QueryCompiler queryCompiler(dataStore);
    queryCompiler.m_useBushyJoins = (useBushy != 0);
    queryCompiler.m_distinctThroughout = (useDistinct != 0);
    queryCompiler.m_exactCardinality = (exactCardinality != 0);
    queryCompiler.m_queryDomain = static_cast<QueryDomain>(queryDomain);
    queryCompiler.m_chooseRootWithAllAnswerVariables = (allAnswersInRoot != 0);
    SPARQLParser parser(prefixes);
    std::string queryText = uk_ac_ox_cs_JRDFox_Common_GetString(env, jQueryText);
    query = parser.parse(factory, queryText.c_str(), queryText.length());
    TupleIterator* tupleIterator = queryCompiler.compileQuery(query).release();
    JavaIntArray arityArray(env, jArityArray);
    arityArray[0] = static_cast<jint>(tupleIterator->getArity());
    if (::logAPICalls()) {
        APIDataStoreLogEntry entry(dataStore);
        entry.getOutput()
            << "# Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nCompileQuery()" << std::endl
            << "set bushy " << (useBushy ? "true" : "false") << std::endl
            << "set distinct " << (useDistinct ? "true" : "false") << std::endl
            << "set cardinality " << (exactCardinality ? "true" : "false") << std::endl
            << "set root-has-answers " << (allAnswersInRoot ? "true" : "false") << std::endl
            << "set query-domain " << (queryDomain == QUERY_DOMAIN_EDB ? "EDB" : (queryDomain == QUERY_DOMAIN_IDB ? "IDB" : (queryDomain == QUERY_DOMAIN_IDBrep ? "IDBrep" : "IDBrepNoEDB"))) << std::endl
            << "run ! \\" << std::endl;
        for (const char* characterPointer = queryText.c_str(); *characterPointer != 0; ++characterPointer) {
            if (*characterPointer == '\n')
                entry.getOutput() << "\\";
            entry.getOutput() << *characterPointer;
        }
        entry.getOutput() << std::endl << std::endl;
    }
    JNI_RMETHOD_END("Error while compiling query. ", reinterpret_cast<jlong>(tupleIterator), 0)
}

JNIEXPORT jint JNICALL Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nOpen(JNIEnv * env, jclass, jlong jTupleIteratorPtr, jint windowSize, jlong jResourceIDsPtr, jlong jMultiplicitiesPtr) {
    JNI_METHOD_START("Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nOpen")
    TupleIterator* iterator = reinterpret_cast<TupleIterator*>(jTupleIteratorPtr);
    jlong* resourceIDs = reinterpret_cast<jlong*>(jResourceIDsPtr);
    jlong* multiplicities = reinterpret_cast<jlong*>(jMultiplicitiesPtr);
    size_t tupleIndex, tupleResourceIndex, multiplicity;
    for (tupleIndex = 0, tupleResourceIndex = 0, multiplicity = iterator->open(); (tupleIndex == 0 && multiplicity > 0) || (tupleIndex > 0 && tupleIndex < static_cast<size_t>(windowSize) && (multiplicity = iterator->advance()) > 0); tupleIndex++) {
        multiplicities[tupleIndex] = multiplicity;
        for (size_t resourceIndex = 0; resourceIndex < iterator->getArity(); resourceIndex++)
            resourceIDs[tupleResourceIndex++] = static_cast<jlong>(iterator->getArgumentsBuffer()[iterator->getArgumentIndexes()[resourceIndex]]);
    }
    JNI_RMETHOD_END("Error while opening the iterator.", static_cast<jint>(tupleIndex), 0)
}

JNIEXPORT jint JNICALL Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nAdvance(JNIEnv * env, jclass, jlong jTupleIteratorPtr, jint windowSize, jlong jResourceIDsPtr, jlong jMultiplicitiesPtr) {
    JNI_METHOD_START("Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nAdvance")
    TupleIterator* iterator = reinterpret_cast<TupleIterator*>(jTupleIteratorPtr);
    jlong* resourceIDs = reinterpret_cast<jlong*>(jResourceIDsPtr);
    jlong* multiplicities = reinterpret_cast<jlong*>(jMultiplicitiesPtr);
    size_t multiplicity, tupleIndex, tupleResourceIndex;
    for (tupleIndex = 0, tupleResourceIndex = 0; tupleIndex < static_cast<size_t>(windowSize) && (multiplicity = iterator->advance()) > 0; tupleIndex++) {
        multiplicities[tupleIndex] = multiplicity;
        for (size_t resourceIndex = 0; resourceIndex < iterator->getArity(); resourceIndex++)
            resourceIDs[tupleResourceIndex++] = static_cast<jlong>(iterator->getArgumentsBuffer()[iterator->getArgumentIndexes()[resourceIndex]]);
    }
    JNI_RMETHOD_END("Error while advancing the iterator.", static_cast<jint>(tupleIndex), 0)
}

JNIEXPORT jint JNICALL Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nGetResources(JNIEnv* env, jclass, jlong tupleIteratorPtr, jlong resourceIDsPtr, jint firstIndex, jint limitIndex, jlong stringByteBufferPtr, jint stringByteBufferLength, jlong stringLengthsBufferPtr, jlong datatypeIDsBufferPtr) {
    JNI_METHOD_START("Java_uk_ac_ox_cs_JRDFox_store_Dictionary_nGetResources")
    jint firstUnprocessedIndex = getResources(&reinterpret_cast<QueryIterator*>(tupleIteratorPtr)->getResourceValueCache(), resourceIDsPtr, firstIndex, limitIndex, stringByteBufferPtr, stringByteBufferLength, stringLengthsBufferPtr, datatypeIDsBufferPtr);
    JNI_RMETHOD_END("Error getting ground terms from the dictionary.", firstUnprocessedIndex, 0)
}

JNIEXPORT void JNICALL Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nDispose(JNIEnv* env, jclass, jlong tupleIteratorPtr) {
    JNI_METHOD_START("Java_uk_ac_ox_cs_JRDFox_store_TupleIterator_nDispose")
    if (tupleIteratorPtr != 0)
        delete reinterpret_cast<TupleIterator*>(tupleIteratorPtr);
    JNI_METHOD_END("Error while disposing of the iterator.")
}
