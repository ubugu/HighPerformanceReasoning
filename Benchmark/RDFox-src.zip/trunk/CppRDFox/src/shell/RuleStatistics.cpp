// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "../Common.h"
#include "../logic/Logic.h"
#include "../util/Vocabulary.h"
#include "ShellCommand.h"

class RuleStatistics: public ShellCommand {

protected:

    struct PredicateStats {
        ResourceByName m_predicate;
        size_t m_headOccurrences;
        size_t m_bodyOccurrences;

        PredicateStats(const ResourceByName& predicate) : m_predicate(predicate),  m_headOccurrences(0), m_bodyOccurrences(0) {
        }
    };

    struct RuleStats : private Unmovable {
        const size_t m_numberOfBodyLiterals;
        std::vector<Rule> m_rules;

        RuleStats(size_t numberOfBodyLiterals) : m_numberOfBodyLiterals(numberOfBodyLiterals), m_rules() {
        }
    };

    always_inline static bool totalOccurrencesCompare(const PredicateStats* predicateStats1, const PredicateStats* predicateStats2) {
        return predicateStats1->m_headOccurrences + predicateStats1->m_bodyOccurrences > predicateStats2->m_headOccurrences + predicateStats2->m_bodyOccurrences;
    }

    typedef std::unordered_map<ResourceByName, std::unique_ptr<PredicateStats>> PredicateStatsMap;

    typedef std::map<size_t, std::unique_ptr<RuleStats> > RuleStatsMap;

    always_inline static PredicateStats* getPredicateStatistics(PredicateStatsMap& predicateStatsMap, const Predicate& rdfPredicate, const ResourceByName& rdfType, const Literal& literal) {
        if (literal->getType() == ATOM_FORMULA && literal->getNumberOfArguments() == 3 && to_pointer_cast<Atom>(literal)->getPredicate() == rdfPredicate) {
            const Term predicateTerm = literal->getArgument(1);
            ResourceByName predicate;
            if (predicateTerm == rdfType) {
                const Term objectTerm = literal->getArgument(2);
                if (objectTerm->getType() == RESOURCE_BY_NAME)
                    predicate = static_pointer_cast<ResourceByName>(objectTerm);
            }
            else if (predicateTerm->getType() == RESOURCE_BY_NAME)
                predicate = static_pointer_cast<ResourceByName>(predicateTerm);
            if (predicate.get() != nullptr) {
                std::unique_ptr<PredicateStats>& predicateStats = predicateStatsMap[predicate];
                if (predicateStats.get() == nullptr)
                    predicateStats.reset(new PredicateStats(predicate));
                return predicateStats.get();
            }
        }
        return nullptr;
    }

    always_inline static size_t getNumberOfDigits(size_t number) {
        if (number == 0)
            return 1;
        else {
            size_t digits = 0;
            while (number != 0) {
                ++digits;
                number /= 10;
            }
            return digits;
        }
    }

public:

    RuleStatistics() : ShellCommand("rulestats") {
    }

    virtual std::string getOneLineHelp() const {
        return "analyzes currently loaded rules";
    }

    virtual void printHelpPage(std::ostream& output) const {
        output
            << "rulestats [print-rules]" << std::endl
            << "    Conducts a comprehensive statistical analysis of the currently loaded rules." << std::endl;
    }

    virtual void execute(Shell& shell, Shell::ArgumentsTokenizer& arguments) const {
        if (isDataStoreActive(shell)) {
            bool printRules = false;
            if (arguments.symbolLowerCaseTokenEquals("print-rules")) {
                arguments.nextToken();
                printRules = true;
            }
            shell.printLine("Producing rule statistics", (printRules ? "; rules will be printed sorted by the number of body atoms" : ""), ".");
            std::unique_ptr<std::ofstream> resultsOutputFile;
            std::ostream* selectedOutput;
            if (!shell.selectOutput(selectedOutput, resultsOutputFile) || selectedOutput == 0)
                return;
            LogicFactory logicFactory(::newLogicFactory());
            const Predicate rdfPredicate = logicFactory->getRDFPredicate();
            const ResourceByName rdfType = logicFactory->getIRIReference(RDF_TYPE);
            DatalogProgram datalogProgram;
            shell.getDataStore().getRules(datalogProgram, logicFactory);
            size_t maxNumberOfBodyLiteralsWidth = 5;
            size_t maxFrequencyWidth = getNumberOfDigits(datalogProgram.size());
            RuleStatsMap RuleStatssByBodySize;
            PredicateStatsMap predicateStatsMap;
            for (auto iterator = datalogProgram.begin(); iterator != datalogProgram.end(); ++iterator) {
                const Rule& rule = *iterator;
                const size_t numberOfBodyLiterals = rule->getNumberOfBodyLiterals();
                maxNumberOfBodyLiteralsWidth = std::max(maxNumberOfBodyLiteralsWidth, getNumberOfDigits(numberOfBodyLiterals));
                std::unique_ptr<RuleStats>& ruleStats = RuleStatssByBodySize[numberOfBodyLiterals];
                if (ruleStats.get() == nullptr)
                    ruleStats.reset(new RuleStats(numberOfBodyLiterals));
                ruleStats->m_rules.push_back(rule);
                const std::vector<Atom>& head = rule->getHead();
                for (auto iterator = head.begin(); iterator != head.end(); ++iterator) {
                    PredicateStats* headPredicateStats = getPredicateStatistics(predicateStatsMap, rdfPredicate, rdfType, *iterator);
                    if (headPredicateStats != nullptr)
                        headPredicateStats->m_headOccurrences++;
                }
                const std::vector<Literal>& body = rule->getBody();
                for (auto iterator = body.begin(); iterator != body.end(); ++iterator) {
                    PredicateStats* bodyPredicateStats = getPredicateStatistics(predicateStatsMap, rdfPredicate, rdfType, *iterator);
                    if (bodyPredicateStats != nullptr)
                        bodyPredicateStats->m_bodyOccurrences++;
                }
            }
            const std::streamsize currentWidth = selectedOutput->width();
            *selectedOutput << "======== RULES STATISTICS ========" << std::endl;
            *selectedOutput << std::setw(static_cast<int>(maxNumberOfBodyLiteralsWidth)) << std::right << "Atoms" << std::setw(static_cast<int>(currentWidth)) << std::left << "    " << std::setw(static_cast<int>(maxFrequencyWidth)) << std::right << "Rules" << std::setw(static_cast<int>(currentWidth)) << std::left << std::endl;
            for (RuleStatsMap::iterator iterator = RuleStatssByBodySize.begin(); iterator != RuleStatssByBodySize.end(); ++iterator)
                *selectedOutput << std::setw(static_cast<int>(maxNumberOfBodyLiteralsWidth)) << std::right << iterator->second->m_numberOfBodyLiterals << std::setw(static_cast<int>(currentWidth)) << std::left << "    " << std::setw(static_cast<int>(maxFrequencyWidth)) << std::right << iterator->second->m_rules.size() << std::setw(static_cast<int>(currentWidth)) << std::left << std::endl;
            *selectedOutput << "----------------------------------" << std::endl;
            if (printRules) {
                for (RuleStatsMap::iterator iterator = RuleStatssByBodySize.begin(); iterator != RuleStatssByBodySize.end(); ++iterator) {
                    RuleStats& RuleStats = *iterator->second;
                    *selectedOutput << RuleStats.m_rules.size() << " RULE" << (RuleStats.m_rules.size() != 1 ? "S" : "") << " WITH " << RuleStats.m_numberOfBodyLiterals << " BODY ATOM" << (RuleStats.m_numberOfBodyLiterals != 1 ? "S" : "") << std::endl;
                    for (std::vector<Rule>::iterator iterator = RuleStats.m_rules.begin(); iterator != RuleStats.m_rules.end(); ++iterator)
                        *selectedOutput << (*iterator)->toString(shell.getPrefixes()) << std::endl;
                }
            }
            *selectedOutput << "----------------------------------" << std::endl;
            *selectedOutput << std::setw(static_cast<int>(maxNumberOfBodyLiteralsWidth)) << std::right << "Total:" << std::setw(static_cast<int>(currentWidth)) << std::left << "   " << std::setw(static_cast<int>(maxFrequencyWidth)) << std::right << datalogProgram.size() << std::setw(static_cast<int>(currentWidth)) << std::left << std::endl;
            size_t maxPredicateNameLength = 0;
            size_t maxTotalOccurrences = 0;
            size_t maxHeadOccurrences = 0;
            size_t maxBodyOccurrences = 0;
            std::vector<PredicateStats*> predicateStatsVector;
            for (auto iterator = predicateStatsMap.begin(); iterator != predicateStatsMap.end(); ++iterator) {
                const size_t predicateNameLength = iterator->first->getResourceText().m_lexicalForm.length();
                if (predicateNameLength > maxPredicateNameLength)
                    maxPredicateNameLength = predicateNameLength;
                const size_t totalOccurrences = iterator->second->m_headOccurrences + iterator->second->m_bodyOccurrences;
                if (totalOccurrences > maxTotalOccurrences)
                    maxTotalOccurrences = totalOccurrences;
                if (iterator->second->m_headOccurrences > maxHeadOccurrences)
                    maxHeadOccurrences = iterator->second->m_headOccurrences;
                if (iterator->second->m_bodyOccurrences > maxBodyOccurrences)
                    maxBodyOccurrences = iterator->second->m_bodyOccurrences;
                predicateStatsVector.push_back(iterator->second.get());
            }
            std::sort(predicateStatsVector.begin(), predicateStatsVector.end(), totalOccurrencesCompare);
            const size_t totalOccurrencesWidth = getNumberOfDigits(maxTotalOccurrences);
            const size_t headOccurrencesWidth = getNumberOfDigits(maxHeadOccurrences);
            const size_t bodyOccurrencesWidth = getNumberOfDigits(maxBodyOccurrences);
            for (auto iterator = predicateStatsVector.begin(); iterator != predicateStatsVector.end(); ++iterator) {
                selectedOutput->width(maxPredicateNameLength);
                *selectedOutput << (*iterator)->m_predicate->getResourceText().m_lexicalForm;
                selectedOutput->width(currentWidth);
                *selectedOutput << " : ";
                selectedOutput->width(totalOccurrencesWidth);
                *selectedOutput << std::right << ((*iterator)->m_headOccurrences +  (*iterator)->m_bodyOccurrences);
                selectedOutput->width(currentWidth);
                *selectedOutput << " [";
                selectedOutput->width(headOccurrencesWidth);
                *selectedOutput << (*iterator)->m_headOccurrences;
                selectedOutput->width(currentWidth);
                *selectedOutput << " / ";
                selectedOutput->width(bodyOccurrencesWidth);
                *selectedOutput << (*iterator)->m_bodyOccurrences;
                selectedOutput->width(currentWidth);
                *selectedOutput << "]" << std::left << std::endl;
            }
            *selectedOutput << "==================================" << std::endl;
            shell.printLine("Rule statistics printed.");
        }
    }
};

static RuleStatistics s_ruleStatistics;
