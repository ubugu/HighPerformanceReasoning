// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "../all.h"
#include "ShellCommand.h"

class Execute : public ShellCommand {

public:

    Execute() : ShellCommand("exec") {
    }

    virtual std::string getOneLineHelp() const {
        return "executes scripts";
    }

    virtual void printHelpPage(std::ostream& output) const {
        output <<
            "exec [<repeat number>] <file name>*" << std::endl <<
            "    Executes the contents of the specified scripts, each repeated the specified number of times." << std::endl;
    }

    always_inline void printStartMessage(Shell& shell, const std::string& inputFileName, const size_t repeatNumber) const {
        OutputProtector protector(shell);
        shell.getOutput() << "Executing script \"" << inputFileName << "\"";
        if (repeatNumber > 1)
            shell.getOutput() << " " << repeatNumber << " times";
        shell.getOutput() << "." << std::endl;
    }

    virtual void execute(Shell& shell, Shell::ArgumentsTokenizer& arguments) const {
        size_t repeatNumber = 1;
        if (arguments.isNumber()) {
            repeatNumber = static_cast<size_t>(atoi(arguments.getToken(0).c_str()));
            arguments.nextToken();
        }
        while (arguments.isSymbol() || arguments.isQuotedString() || arguments.isQuotedIRI()) {
            std::string inputFileName = arguments.getToken();
            arguments.nextToken();
            shell.expandRelativeFileName(inputFileName, "dir.root");
            std::ifstream input(inputFileName.c_str(), std::ifstream::in);
            if (input.good()) {
                printStartMessage(shell, inputFileName, repeatNumber);
                for (size_t iteration = 0; iteration < repeatNumber; ++iteration) {
                    shell.run(input, false);
                    OutputProtector protector(shell);
                    shell.getOutput() << "Script \"" << inputFileName << "\" finished";
                    if (repeatNumber > 1)
                        shell.getOutput() << " for iteration " << (iteration + 1);
                    shell.getOutput() << "." << std::endl;
                }
                input.close();
            }
            else
                shell.printLine("Cannot open script \"", inputFileName, "\".");
        }
    }

};

static Execute s_execute;
