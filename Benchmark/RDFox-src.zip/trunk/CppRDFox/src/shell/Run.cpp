// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "../RDFStoreException.h"
#include "../dictionary/ResourceValueCache.h"
#include "../dictionary/Dictionary.h"
#include "../logic/Logic.h"
#include "../querying/TermArray.h"
#include "../querying/QueryCompiler.h"
#include "../storage/TupleIterator.h"
#include "../util/ThreadContext.h"
#include "../util/IteratorPrinting.h"
#include "../util/File.h"
#include "../util/MemoryMappedFileView.h"
#include "../formats/turtle/SPARQLParser.h"
#include "ShellCommand.h"

always_inline static QueryDomain getQueryDomain(const std::string& queryDomainString) {
    if (queryDomainString == "IDB")
        return QUERY_DOMAIN_IDB;
    else if (queryDomainString == "EDB")
        return QUERY_DOMAIN_EDB;
    else if (queryDomainString == "IDBrep")
        return QUERY_DOMAIN_IDBrep;
    else if (queryDomainString == "IDBrepNoEDB")
        return QUERY_DOMAIN_IDBrepNoEDB;
    else {
        std::ostringstream message;
        message << "Query domain '" << queryDomainString << "' is unknown.";
        throw RDF_STORE_EXCEPTION(message.str());
    }
}

always_inline static const char* getQueryDomainString(const QueryDomain queryDomain) {
    switch (queryDomain) {
    case QUERY_DOMAIN_EDB:
        return "EDB";
    case QUERY_DOMAIN_IDB:
        return "IDB";
    case QUERY_DOMAIN_IDBrep:
        return "IDBrep";
    case QUERY_DOMAIN_IDBrepNoEDB:
        return "IDBrepNoEDB";
    default:
        UNREACHABLE;
    }
}

std::unique_ptr<QueryIterator> compileQuery(Shell& shell, Query& query, TermArray& termArray, bool silent) {
    QueryCompiler queryCompiler(shell.getDataStore());
    queryCompiler.m_reorderConjunctions = shell.getBooleanVariable("reorder-conjunctions");
    queryCompiler.m_useBushyJoins = shell.getBooleanVariable("bushy");
    queryCompiler.m_distinctThroughout = shell.getBooleanVariable("distinct");
    queryCompiler.m_exactCardinality = shell.getBooleanVariable("cardinality");
    queryCompiler.m_queryDomain = getQueryDomain(shell.getStringVariable("query-domain"));
    queryCompiler.m_chooseRootWithAllAnswerVariables = shell.getBooleanVariable("root-has-answers");
    if (!silent) {
        Shell::OutputProtector protector(shell);
        shell.getOutput()
            << "Reorder conjunctions:          " << (queryCompiler.m_reorderConjunctions ? "on" : "off") << std::endl
            << "Use bushy joins:               " << (queryCompiler.m_useBushyJoins ? "on" : "off") << std::endl
            << "Distinct throughout:           " << (queryCompiler.m_distinctThroughout ? "on" : "off") << std::endl
            << "Exact cardinality:             " << (queryCompiler.m_exactCardinality ? "on" : "off") << std::endl
            << "Root has all answer variables: " << (queryCompiler.m_chooseRootWithAllAnswerVariables ? "on" : "off") << std::endl
            << "Query domain:                  " << getQueryDomainString(queryCompiler.m_queryDomain) << std::endl;
    }
    return queryCompiler.compileQuery(query, termArray);
}

void executeQuery(Shell& shell, Prefixes& prefixes, const char* const queryText, const size_t queryLength) {
    try {
        LogicFactory factory(newLogicFactory());
        Query query;
        SPARQLParser parser(prefixes);
        query = parser.parse(factory, queryText, queryLength);
        std::unique_ptr<std::ofstream> resultsOutputFile;
        std::ostream* output;
        if (shell.selectOutput(output, resultsOutputFile)) {
            const TimePoint compilationStartTimePoint = ::getTimePoint();
            TermArray termArray;
            std::unique_ptr<QueryIterator> queryIterator = compileQuery(shell, query, termArray, false);
            const Duration compilationDuration = ::getTimePoint() - compilationStartTimePoint;
            if (shell.getBooleanVariable("explain")) {
                IteratorPrinting iteratorPrinting(prefixes, termArray, shell.getDataStore().getDictionary());
                iteratorPrinting.printIteratorSubtree(*queryIterator, shell.getOutput());
            }
            size_t numberOfReturnedTuples = 0;
            size_t totalNumberAnswers = 0;
            const ResourceValueCache& resourceValueCache = queryIterator->getResourceValueCache();
            const std::vector<ResourceID>& argumentsBuffer = queryIterator->getArgumentsBuffer();
            const std::vector<ArgumentIndex>& argumentIndexes = queryIterator->getArgumentIndexes();
            ResourceValue resourceValue;
            std::string literalText;
            const TimePoint evaluationStartTimePoint = ::getTimePoint();
            size_t multiplicity = queryIterator->open();
            if (multiplicity > 0 && output) {
                const std::map<std::string, std::string>& prefixIRIsByPrefixNames = prefixes.getPrefixIRIsByPrefixNames();
                for (auto &prefix : prefixIRIsByPrefixNames)
                    *output << "@prefix " << prefix.first << " <" << prefix.second << "> .\n";
            }
            while (multiplicity != 0) {
                if (output) {
                    for (size_t index = 0; index < queryIterator->getArgumentIndexes().size(); ++index) {
                        const ResourceID resourceID = argumentsBuffer[argumentIndexes[index]];
                        if (resourceID == INVALID_RESOURCE_ID)
                            *output << "UNDEF";
                        else if (resourceValueCache.getResource(argumentsBuffer[argumentIndexes[index]], resourceValue)) {
                            Dictionary::toTurtleLiteral(resourceValue, prefixes, literalText);
                            *output << literalText;
                        }
                        else
                            throw RDF_STORE_EXCEPTION("Internal error: resource ID cannot be resolved.");
                        *output << ' ';
                    }
                    *output << '.';
                    if (multiplicity > 1)
                        *output << " # " << multiplicity;
                    *output << '\n';
                }
                ++numberOfReturnedTuples;
                totalNumberAnswers += multiplicity;
                multiplicity = queryIterator->advance();
            }
            const Duration evaluationDuration = ::getTimePoint() - evaluationStartTimePoint;
            if (resultsOutputFile.get()) {
                resultsOutputFile->close();
                resultsOutputFile.reset(0);
            }
            Shell::OutputProtector protector(shell);
            std::streamsize oldPrecision = shell.getOutput().precision(3);
            shell.getOutput()
                << "Number of returned tuples: " << numberOfReturnedTuples << std::endl
                << "Total number of answers:   " << totalNumberAnswers << std::endl
                << "Query compilation time:    " << compilationDuration/1000.0 << " s" << std::endl
                << "Query evaluation time:     " << evaluationDuration/1000.0 << " s" << std::endl;
            shell.getOutput().precision(oldPrecision);
        }
    }
    catch(RDFStoreException& e) {
        shell.printError(e, "The supplied query is invalid.");
        return;
    }
}

class Run : public ShellCommand {

public:

    Run() : ShellCommand("run") {
    }

    virtual std::string getOneLineHelp() const {
        return "queries the store";
    }

    virtual void printHelpPage(std::ostream& output) const {
        output
            << "run (! <query text> | <file name>*)" << std::endl
            << "    Queries the store with the given query or with queries stored in the specified files." << std::endl;
    }

    virtual void execute(Shell& shell, Shell::ArgumentsTokenizer& arguments) const {
        if (isDataStoreActive(shell)) {
            if (arguments.nonSymbolTokenEquals('!')) {
                arguments.nextToken();
                const char* remainingTextStart;
                size_t remainingTextLength;
                arguments.getRemainingText(remainingTextStart, remainingTextLength);
                executeQuery(shell, shell.getPrefixes(), remainingTextStart, remainingTextLength);
            }
            else {
                while (arguments.isSymbol() || arguments.isQuotedString() || arguments.isQuotedIRI()) {
                    std::string inputFileName = arguments.getToken();
                    arguments.nextToken();
                    shell.expandRelativeFileName(inputFileName, "dir.queries");
                    File file;
                    try {
                        file.open(inputFileName, File::OPEN_EXISTING_FILE, true, false, true, false);
                        const size_t fileSize = file.getSize();
                        MemoryMappedFileView fileView;
                        fileView.open(file);
                        fileView.mapView(0, fileSize);
                        std::string queryText(reinterpret_cast<const char*>(fileView.getMappedData()), fileSize);
                        file.close();
                        shell.printLine(queryText);
                        Prefixes prefixes;
                        executeQuery(shell, prefixes, queryText.c_str(), queryText.length());
                    }
                    catch (const RDFStoreException& e) {
                        shell.printError(e, "The query could not be evaluated.");
                    }
                }
            }
        }
    }

};

static Run s_run;
