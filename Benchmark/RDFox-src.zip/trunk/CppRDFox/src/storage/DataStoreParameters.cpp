// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "../util/InputStream.h"
#include "../util/OutputStream.h"
#include "DataStoreParameters.h"

DataStoreParameters::DataStoreParameters() : m_keyValuePairs() {
}

DataStoreParameters::DataStoreParameters(const DataStoreParameters& other) : m_keyValuePairs(other.m_keyValuePairs) {
}

DataStoreParameters::DataStoreParameters(DataStoreParameters&& other) : m_keyValuePairs(std::move(other.m_keyValuePairs)) {
}

DataStoreParameters::~DataStoreParameters() {
}

std::unordered_map<std::string, std::string>::const_iterator DataStoreParameters::begin() const {
    return m_keyValuePairs.begin();
}

std::unordered_map<std::string, std::string>::const_iterator DataStoreParameters::end() const {
    return m_keyValuePairs.end();
}

bool DataStoreParameters::containsKey(const std::string& key) const {
    return m_keyValuePairs.find(key) != m_keyValuePairs.end();
}

const char* DataStoreParameters::getString(const std::string& key, const char* const defaultValue) const {
    const std::unordered_map<std::string, std::string>::const_iterator iterator = m_keyValuePairs.find(key);
    if (iterator == m_keyValuePairs.end())
        return defaultValue;
    else
        return iterator->second.c_str();
}

void DataStoreParameters::setString(const std::string& key, const std::string& value) {
    m_keyValuePairs[key] = value;
}

uint64_t DataStoreParameters::getNumber(const std::string& key, const uint64_t defaultValue, const uint64_t invalidValue) const {
    const std::unordered_map<std::string, std::string>::const_iterator iterator = m_keyValuePairs.find(key);
    if (iterator == m_keyValuePairs.end())
        return defaultValue;
    else {
        const char* stringValue = iterator->second.c_str();
        char* firstUnconverted;
        const uint64_t result = strtoull(stringValue, &firstUnconverted, 10);
        if (stringValue + iterator->second.size() != firstUnconverted)
            return invalidValue;
        else
            return result;
    }
}

void DataStoreParameters::setNumber(const std::string& key, const uint64_t value) {
    std::ostringstream buffer;
    buffer << value;
    m_keyValuePairs[key] = buffer.str();
}

bool DataStoreParameters::getBoolean(const std::string& key, const bool defaultValue) const {
    const std::unordered_map<std::string, std::string>::const_iterator iterator = m_keyValuePairs.find(key);
    if (iterator == m_keyValuePairs.end())
        return defaultValue;
    else
        return iterator->second == "true" || iterator->second == "on" || iterator->second == "yes";
}

void DataStoreParameters::setBoolean(const std::string& key, const bool value) {
    if (value)
        m_keyValuePairs[key] = "true";
    else
        m_keyValuePairs[key] = "false";
}

void DataStoreParameters::save(OutputStream& outputStream) const {
    outputStream.writeString("DataStoreParameters");
    outputStream.write(m_keyValuePairs.size());
    for (std::unordered_map<std::string, std::string>::const_iterator iterator = m_keyValuePairs.begin(); iterator != m_keyValuePairs.end(); ++iterator) {
        outputStream.writeString(iterator->first);
        outputStream.writeString(iterator->second);
    }
}

void DataStoreParameters::load(InputStream& inputStream) {
    if (!inputStream.checkNextString("DataStoreParameters"))
        throw RDF_STORE_EXCEPTION("Cannot load DataStoreParameters.");
    const size_t numberOfPairs = inputStream.read<size_t>();
    m_keyValuePairs.clear();
    std::string key;
    std::string value;
    for (size_t pairIndex = 0; pairIndex < numberOfPairs; ++pairIndex) {
        inputStream.readString(key, 4096);
        inputStream.readString(value, 4096);
        m_keyValuePairs[key] = value;
    }
}
