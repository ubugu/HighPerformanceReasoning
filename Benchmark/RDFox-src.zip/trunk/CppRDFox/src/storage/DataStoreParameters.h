// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifndef DATASTOREPARAMETERS_H_
#define DATASTOREPARAMETERS_H_

#include "../all.h"

class InputStream;
class OutputStream;

class DataStoreParameters {

protected:

    std::unordered_map<std::string, std::string> m_keyValuePairs;

public:

    DataStoreParameters();

    DataStoreParameters(const DataStoreParameters& other);

    DataStoreParameters(DataStoreParameters&& other);

    DataStoreParameters& operator=(const DataStoreParameters& other) = delete;

    DataStoreParameters& operator=(DataStoreParameters&& other) = delete;

    ~DataStoreParameters();

    std::unordered_map<std::string, std::string>::const_iterator begin() const;

    std::unordered_map<std::string, std::string>::const_iterator end() const;

    bool containsKey(const std::string& key) const;

    const char* getString(const std::string& key, const char* const defaultValue) const;

    void setString(const std::string& key, const std::string& value);

    uint64_t getNumber(const std::string& key, const uint64_t defaultValue, const uint64_t invalidValue) const;

    void setNumber(const std::string& key, const uint64_t value);
    
    bool getBoolean(const std::string& key, const bool defaultValue) const;

    void setBoolean(const std::string& key, const bool value);

    void save(OutputStream& outputStream) const;

    void load(InputStream& inputStream);

    friend bool operator==(const DataStoreParameters& parameters1, const DataStoreParameters& parameters2);

    friend bool operator!=(const DataStoreParameters& parameters1, const DataStoreParameters& parameters2);

};

always_inline bool operator==(const DataStoreParameters& parameters1, const DataStoreParameters& parameters2) {
    return parameters1.m_keyValuePairs == parameters2.m_keyValuePairs;
}

always_inline bool operator!=(const DataStoreParameters& parameters1, const DataStoreParameters& parameters2) {
    return parameters1.m_keyValuePairs != parameters2.m_keyValuePairs;
}

#endif /* DATASTOREPARAMETERS_H_ */
