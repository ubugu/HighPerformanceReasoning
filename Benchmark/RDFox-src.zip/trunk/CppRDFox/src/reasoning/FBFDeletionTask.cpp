// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "../dictionary/Dictionary.h"
#include "AbstractDeletionTaskImpl.h"
#include "FBFDeletionTask.h"

// FBFDeletionTask

template<bool callMonitor>
always_inline std::unique_ptr<ReasoningTaskWorker> FBFDeletionTask::doCreateWorker1(DatalogEngineWorker& datalogEngineWorker) {
    if (m_componentLevel == static_cast<size_t>(-1))
        return doCreateWorker2<callMonitor, false>(datalogEngineWorker);
    else
        return doCreateWorker2<callMonitor, true>(datalogEngineWorker);
}

template<bool callMonitor, bool checkComponentLevel>
always_inline std::unique_ptr<ReasoningTaskWorker> FBFDeletionTask::doCreateWorker2(DatalogEngineWorker& datalogEngineWorker) {
    if (m_datalogEngine.getRuleIndex().componentLevelHasRules(m_componentLevel))
        return doCreateWorker3<callMonitor, checkComponentLevel, true>(datalogEngineWorker);
    else
        return doCreateWorker3<callMonitor, checkComponentLevel, false>(datalogEngineWorker);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent>
always_inline std::unique_ptr<ReasoningTaskWorker> FBFDeletionTask::doCreateWorker3(DatalogEngineWorker& datalogEngineWorker) {
    switch (m_datalogEngine.getDataStore().getEqualityAxiomatizationType()) {
    case EQUALITY_AXIOMATIZATION_NO_UNA:
        return std::unique_ptr<ReasoningTaskWorker>(new FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, EQUALITY_AXIOMATIZATION_NO_UNA>(*this, datalogEngineWorker));
    case EQUALITY_AXIOMATIZATION_UNA:
        return std::unique_ptr<ReasoningTaskWorker>(new FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, EQUALITY_AXIOMATIZATION_UNA>(*this, datalogEngineWorker));
    case EQUALITY_AXIOMATIZATION_OFF:
    default:
        return std::unique_ptr<ReasoningTaskWorker>(new FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, EQUALITY_AXIOMATIZATION_OFF>(*this, datalogEngineWorker));
    }
}

std::unique_ptr<ReasoningTaskWorker> FBFDeletionTask::doCreateWorker(DatalogEngineWorker& datalogEngineWorker) {
    if (m_incrementalMonitor == nullptr)
        return doCreateWorker1<false>(datalogEngineWorker);
    else
        return doCreateWorker1<true>(datalogEngineWorker);
}

void FBFDeletionTask::doInitialize() {
    AbstractDeletionTask::doInitialize();
    m_datalogEngine.getRuleIndex().resetProving();
    m_datalogEngine.getRuleIndex().forgetTemporaryConstants();
}

FBFDeletionTask::FBFDeletionTask(DatalogEngine& datalogEngine, IncrementalMonitor* const incrementalMonitor, IncrementalReasoningState& incrementalReasoningState, const size_t componentLevel) :
    AbstractDeletionTask(datalogEngine, incrementalMonitor, incrementalReasoningState, componentLevel),
    m_ruleQueue(m_datalogEngine.getDataStore().getMemoryManager())
{
}

// FBFDeletionTaskWorker::ReflexivityCheckHelper

static const std::vector<ArgumentIndex> s_reflexivityCheckHelperArgumentIndexes{0, 1, 2};
static const ArgumentIndexSet s_reflexivityCheckHelperBoundArguments[3]{
    { 0 },
    { 1 },
    { 2 }
};

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline size_t FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::ReflexivityCheckHelper::ensureOnTuple(const IncrementalReasoningState& incrementalReasoningState, size_t multiplicity) {
    while (multiplicity != 0 && ((incrementalReasoningState.getGlobalFlags(m_tupleIterator->getCurrentTupleIndex()) & GF_DISPROVED) == GF_DISPROVED))
        multiplicity = m_tupleIterator->advance();
    return multiplicity;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::ReflexivityCheckHelper::ReflexivityCheckHelper(TupleTable& tripleTable, const size_t positionIndex) :
    m_previous(),
    m_currentTupleBuffer(3, INVALID_RESOURCE_ID),
    m_tupleIterator(tripleTable.createTupleIterator(m_currentTupleBuffer, s_reflexivityCheckHelperArgumentIndexes, s_reflexivityCheckHelperBoundArguments[positionIndex], s_reflexivityCheckHelperBoundArguments[positionIndex], TUPLE_STATUS_COMPLETE | TUPLE_STATUS_IDB | TUPLE_STATUS_IDB_MERGED, TUPLE_STATUS_COMPLETE | TUPLE_STATUS_IDB))
{
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline size_t FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::ReflexivityCheckHelper::open(ThreadContext& threadContext, const IncrementalReasoningState &incrementalReasoningState) {
    return ensureOnTuple(incrementalReasoningState, m_tupleIterator->open(threadContext));
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline size_t FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::ReflexivityCheckHelper::advance(const IncrementalReasoningState &incrementalReasoningState) {
    return ensureOnTuple(incrementalReasoningState, m_tupleIterator->advance());
}

// FBFDeletionTaskWorker::StackFrame

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::StackFrame::StackFrame() :
    m_previous(),
    m_returnAddress(0),
    m_tupleIndex(INVALID_TUPLE_INDEX),
    m_currentTupleBuffer(3, INVALID_RESOURCE_ID),
    m_allProved(false),
    m_multiplicity(0),
    m_currentPositionIndex(0),
    m_currentReflexivityCheckHelper(),
    m_currentIndexingPatternNumber(static_cast<size_t>(-1)),
    m_currentHeadAtomInfo(nullptr),
    m_currentBodyMatches(),
    m_currentBodyIndex(0)
{
}

// FBFDeletionTaskWorker

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline std::unique_ptr<typename FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::ReflexivityCheckHelper> FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::getReflexivityCheckHelper(const size_t positionIndex) {
    std::unique_ptr<ReflexivityCheckHelper>& head = m_reflexivityCheckHelperHeads[positionIndex];
    if (head.get() == 0)
        return std::unique_ptr<ReflexivityCheckHelper>(new ReflexivityCheckHelper(this->m_tripleTable, positionIndex));
    else {
        std::unique_ptr<ReflexivityCheckHelper> result = std::move(head);
        head = std::move(result->m_previous);
        return result;
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline void FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::leaveReflexivityCheckHelper(std::unique_ptr<ReflexivityCheckHelper> reflexivityCheckHelper, const size_t positionIndex) {
    std::unique_ptr<ReflexivityCheckHelper>& head = m_reflexivityCheckHelperHeads[positionIndex];
    reflexivityCheckHelper->m_previous = std::move(head);
    head = std::move(reflexivityCheckHelper);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline std::unique_ptr<typename FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::StackFrame> FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::getStackFrame(const TupleIndex tupleIndex, const std::vector<ResourceID> argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, std::unique_ptr<StackFrame> previous) {
    assert(tupleIndex != INVALID_TUPLE_INDEX);
    std::unique_ptr<StackFrame> stackFrame;
    if (m_usedStackFrames.get() == 0)
        stackFrame.reset(new StackFrame());
    else {
        stackFrame = std::move(m_usedStackFrames);
        m_usedStackFrames = std::move(stackFrame->m_previous);
    }
    stackFrame->m_tupleIndex = tupleIndex;
    stackFrame->m_previous = std::move(previous);
    for (size_t positionIndex = 0; positionIndex < 3; ++positionIndex)
        stackFrame->m_currentTupleBuffer[positionIndex] = argumentsBuffer[argumentIndexes[positionIndex]];
    return std::move(stackFrame);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline void FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::leaveStackFrame(std::unique_ptr<StackFrame> stackFrame) {
    stackFrame->m_previous = std::move(m_usedStackFrames);
    stackFrame->m_returnAddress = 0;
    stackFrame->m_tupleIndex = INVALID_TUPLE_INDEX;
    stackFrame->m_allProved = false;
    stackFrame->m_multiplicity = 0;
    stackFrame->m_currentPositionIndex = 0;
    assert(stackFrame->m_currentReflexivityCheckHelper.get() == nullptr);
    stackFrame->m_currentIndexingPatternNumber = 0;
    stackFrame->m_currentHeadAtomInfo = nullptr;
    assert(stackFrame->m_currentBodyMatches.get() == nullptr);
    stackFrame->m_currentBodyIndex = 0;
    m_usedStackFrames = std::move(stackFrame);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::FBFDeletionTaskWorker(FBFDeletionTask& deletionTask, DatalogEngineWorker& datalogEngineWorker) :
    AbstractDeletionTaskWorker<FBFDeletionTaskWorkerType>(deletionTask, datalogEngineWorker),
    m_dictionary(this->m_dataStore.getDictionary()),
    m_provingEqualityManager(this->m_ruleIndex.getProvingEqualityManager()),
    m_ruleQueue(deletionTask.m_ruleQueue),
    m_queriesForNormalizationSPO(),
    m_queriesForEBDContainmentCheckSPO(),
    m_currentTupleIndex2(INVALID_TUPLE_INDEX),
    m_currentTupleBuffer4(3, INVALID_RESOURCE_ID),
    m_currentTupleBuffer5(3, INVALID_RESOURCE_ID),
    m_currentTupleBuffer6(3, INVALID_RESOURCE_ID),
    m_currentTupleBuffer7(3, INVALID_RESOURCE_ID),
    m_currentTupleBuffer8(3, INVALID_RESOURCE_ID),
    m_currentTupleBuffer9(3, INVALID_RESOURCE_ID),
    m_reflexivityCheckHelperHeads(),
    m_usedStackFrames(),
    m_checkedTuples()
{
    ArgumentIndexSet allInputArguments;
    for (ArgumentIndex argumentIndex = 0; argumentIndex < 3; ++argumentIndex) {
        allInputArguments.clear();
        allInputArguments.add(argumentIndex);
        m_queriesForNormalizationSPO[argumentIndex] = this->m_tripleTable.createTupleIterator(m_currentTupleBuffer4, this->m_currentTupleArgumentIndexes, allInputArguments, allInputArguments, TUPLE_STATUS_COMPLETE, TUPLE_STATUS_COMPLETE);
        m_queriesForEBDContainmentCheckSPO[argumentIndex] = this->m_tripleTable.createTupleIterator(m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes, allInputArguments, allInputArguments, TUPLE_STATUS_COMPLETE | TUPLE_STATUS_EDB, TUPLE_STATUS_COMPLETE | TUPLE_STATUS_EDB);
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::~FBFDeletionTaskWorker() {
    // Just letting the object die would recursively kill the lists of stack frames etc., which could blow the stack.
    // Therefore, we perform the cleanup in a non-recursive way.
    while (m_usedStackFrames.get() != nullptr) {
        std::unique_ptr<StackFrame> topStackFrame = std::move(m_usedStackFrames);
        m_usedStackFrames = std::move(topStackFrame->m_previous);
    }
    for (size_t argumentIndex = 0; argumentIndex < 3; ++argumentIndex) {
        std::unique_ptr<ReflexivityCheckHelper> head = std::move(m_reflexivityCheckHelperHeads[argumentIndex]);
        while (head.get() != nullptr) {
            std::unique_ptr<ReflexivityCheckHelper> topHelper = std::move(head);
            head = std::move(topHelper->m_previous);
        }
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline size_t FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::ensureOnRewriteTuple(TupleIterator& tupleIterator, size_t multiplicity) {
    while (multiplicity != 0 && ((this->m_incrementalReasoningState.getCurrentLevelFlags(tupleIterator.getCurrentTupleIndex()) & (LF_PROVED | LF_PROVED_MERGED)) != LF_PROVED))
        multiplicity = tupleIterator.advance();
    return multiplicity;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline void FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::rewrite(ThreadContext& threadContext, const ResourceID resourceID1, const ResourceID resourceID2) {
    const DatatypeID resource1DatatypeID = m_dictionary.getDatatypeID(resourceID1);
    const DatatypeID resource2DatatypeID = m_dictionary.getDatatypeID(resourceID2);
    ResourceID sourceID;
    ResourceID targetID;
    bool clash;
    if (resource1DatatypeID == D_BLANK_NODE && resource2DatatypeID != D_BLANK_NODE) {
        sourceID = resourceID1;
        targetID = resourceID2;
        clash = false;
    }
    else if (resource1DatatypeID != D_BLANK_NODE && resource2DatatypeID == D_BLANK_NODE) {
        sourceID = resourceID2;
        targetID = resourceID1;
        clash = false;
    }
    else {
        // At this point, either both or none of the resources are blank nodes.
        // *DatatypeID > D_BLANK_NODE means that the resource is a literal; hence, if either resource is a literal,
        // then the other resource is not a blank node and so we've got a clash. In addition, we've got a clash if
        // we're using UNA and both resources are IRI references.
        clash = (resource1DatatypeID > D_BLANK_NODE) || (resource2DatatypeID > D_BLANK_NODE) || (equalityAxiomatizationType == EQUALITY_AXIOMATIZATION_UNA && resource1DatatypeID == D_IRI_REFERENCE && resource2DatatypeID == D_IRI_REFERENCE);
        if (resourceID1 < resourceID2) {
            sourceID = resourceID2;
            targetID = resourceID1;
        }
        else {
            sourceID = resourceID1;
            targetID = resourceID2;
        }
    }
    if (m_provingEqualityManager.merge<false>(sourceID, targetID)) {
        if (callMonitor) {
            this->m_incrementalMonitor->constantMerged(this->m_workerIndex, sourceID, targetID, true);
            this->m_incrementalMonitor->normalizeConstantStarted(this->m_workerIndex, sourceID);
        }
        // Fix the facts
        for (size_t positionIndex = 0; positionIndex < 3; ++positionIndex) {
            TupleIterator& tupleIterator = *m_queriesForNormalizationSPO[positionIndex];
            m_currentTupleBuffer4[positionIndex] = sourceID;
            size_t multiplicity = ensureOnRewriteTuple(tupleIterator, tupleIterator.open(threadContext));
            while (multiplicity != 0) {
                // We must copy the tuple; otherwise, the following call to normalize() could override the value of mergedID, which breaks the iterator.
                AddResult addResult = ALREADY_EXISTS;
                if (m_provingEqualityManager.normalize(m_currentTupleBuffer4, m_currentTupleBuffer5, this->m_currentTupleArgumentIndexes) && this->m_incrementalReasoningState.template addCurrentLevelFlags<false>(tupleIterator.getCurrentTupleIndex(), LF_PROVED_MERGED))
                    addResult = addProvedTuple(threadContext, m_currentTupleBuffer5, this->m_currentTupleArgumentIndexes);
                if (callMonitor) {
                    switch (addResult) {
                    case ALREADY_EXISTS:
                        this->m_incrementalMonitor->tupleNormalized(this->m_workerIndex, m_currentTupleBuffer4, this->m_currentTupleArgumentIndexes, m_currentTupleBuffer5, this->m_currentTupleArgumentIndexes, false);
                        break;
                    case ADDED:
                        this->m_incrementalMonitor->tupleNormalized(this->m_workerIndex, m_currentTupleBuffer4, this->m_currentTupleArgumentIndexes, m_currentTupleBuffer5, this->m_currentTupleArgumentIndexes, true);
                        break;
                    case ALREADY_DELAYED:
                        this->m_incrementalMonitor->tupleNormalizedDelayed(this->m_workerIndex, m_currentTupleBuffer4, this->m_currentTupleArgumentIndexes, m_currentTupleBuffer5, this->m_currentTupleArgumentIndexes, false);
                        break;
                    case DELAYED:
                        this->m_incrementalMonitor->tupleNormalizedDelayed(this->m_workerIndex, m_currentTupleBuffer4, this->m_currentTupleArgumentIndexes, m_currentTupleBuffer5, this->m_currentTupleArgumentIndexes, true);
                        break;
                    }
                }
                multiplicity = ensureOnRewriteTuple(tupleIterator, tupleIterator.advance());
            }
        }
        if (callMonitor)
            this->m_incrementalMonitor->normalizeConstantFinished(this->m_workerIndex);
        // Fix the rules
        if (!m_ruleQueue.initializeLarge())
            throw RDF_STORE_EXCEPTION("Cannot initialize rule queue.");
        this->m_ruleIndex.template enqueueRulesToReevaluateIncremental<checkComponentLevel>(sourceID, this->m_componentLevel, m_ruleQueue);
        // Fix the facts. We call proveNormalTuple() to prevent recursion, which might prevent inlining (and some compilers complain then).
        RuleInfo* ruleInfo;
        while ((ruleInfo = m_ruleQueue.dequeue<false>()) != nullptr)
            ruleInfo->template evaluateRuleIncremental<FBFDeletionTaskWorkerType, &FBFDeletionTaskWorkerType::proveNormalTupleProxy, checkComponentLevel, callMonitor>(threadContext, *this, this->m_componentLevel, this->m_incrementalMonitor);
    }
    else {
        if (callMonitor)
            this->m_incrementalMonitor->constantMerged(this->m_workerIndex, sourceID, targetID, false);
    }
    if (clash) {
        m_currentTupleBuffer5[0] = targetID;
        m_currentTupleBuffer5[1] = m_provingEqualityManager.normalize(this->m_dictionary.resolveResource(RDF_TYPE, D_IRI_REFERENCE));
        m_currentTupleBuffer5[2] = m_provingEqualityManager.normalize(this->m_dictionary.resolveResource(OWL_NOTHING, D_IRI_REFERENCE));
        // We call proveNormalTuple() to prevent recursion, which might prevent inlining (and some compilers complain then).
        proveNormalTuple(threadContext, m_currentTupleBuffer5, this->m_currentTupleArgumentIndexes);
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline void FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::proveNormalTuple(ThreadContext& threadContext, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    switch (addProvedTuple(threadContext, argumentsBuffer, argumentIndexes)) {
    case ALREADY_EXISTS:
        if (callMonitor)
            this->m_incrementalMonitor->tupleDerived(this->m_workerIndex, argumentsBuffer, argumentIndexes, true, false);
        break;
    case ADDED:
        if (callMonitor)
            this->m_incrementalMonitor->tupleDerived(this->m_workerIndex, argumentsBuffer, argumentIndexes, true, true);
        break;
    case ALREADY_DELAYED:
        if (callMonitor)
            this->m_incrementalMonitor->tupleProvedDelayed(this->m_workerIndex, argumentsBuffer, argumentIndexes, false);
        break;
    case DELAYED:
        if (callMonitor)
            this->m_incrementalMonitor->tupleProvedDelayed(this->m_workerIndex, argumentsBuffer, argumentIndexes, true);
        break;
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline void FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::proveNormalTupleProxy(ThreadContext& threadContext, FBFDeletionTaskWorker& target, const HeadAtomInfo& headAtomInfo, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    target.proveNormalTuple(threadContext, argumentsBuffer, argumentIndexes);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::isProveAtomPositive(FBFDeletionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return
        (((target.m_incrementalReasoningState.getCurrentLevelFlags(tupleIndex) & (LF_PROVED | LF_PROVED_MERGED)) == LF_PROVED) &&
        (bodyLiteralInfo.getLiteralPosition() == AFTER_PIVOT_ATOM || target.m_currentTupleIndex2 != tupleIndex));
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::isProveAtomNegative(FBFDeletionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return
        ((tupleStatus & (TUPLE_STATUS_IDB | TUPLE_STATUS_IDB_MERGED)) == TUPLE_STATUS_IDB) ||
        ((target.m_incrementalReasoningState.getGlobalFlags(tupleIndex) & (GF_ADDED | GF_ADDED_MERGED)) == GF_ADDED);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::isProveIteratorPositive(FBFDeletionTaskWorkerType& target, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return
        ((target.m_incrementalReasoningState.getCurrentLevelFlags(tupleIndex) & (LF_PROVED | LF_PROVED_MERGED)) == LF_PROVED);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::isProveIteratorNegative(FBFDeletionTaskWorkerType& target, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return
        ((tupleStatus & (TUPLE_STATUS_IDB | TUPLE_STATUS_IDB_MERGED)) == TUPLE_STATUS_IDB) ||
        ((target.m_incrementalReasoningState.getGlobalFlags(tupleIndex) & (GF_ADDED | GF_ADDED_MERGED)) == GF_ADDED);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline void FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::proveTuple(ThreadContext& threadContext, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    if (equalityAxiomatizationType == EQUALITY_AXIOMATIZATION_OFF || m_provingEqualityManager.isNormal(argumentsBuffer, argumentIndexes)) {
        switch (addProvedTuple(threadContext, argumentsBuffer, argumentIndexes)) {
        case ALREADY_EXISTS:
            if (callMonitor)
                this->m_incrementalMonitor->tupleDerived(this->m_workerIndex, argumentsBuffer, argumentIndexes, true, false);
            break;
        case ADDED:
            if (callMonitor)
                this->m_incrementalMonitor->tupleDerived(this->m_workerIndex, argumentsBuffer, argumentIndexes, true, true);
            if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF && argumentsBuffer[argumentIndexes[1]] == OWL_SAME_AS_ID && argumentsBuffer[argumentIndexes[0]] != argumentsBuffer[argumentIndexes[2]])
                rewrite(threadContext, argumentsBuffer[argumentIndexes[0]], argumentsBuffer[argumentIndexes[2]]);
            break;
        case ALREADY_DELAYED:
            if (callMonitor)
                this->m_incrementalMonitor->tupleProvedDelayed(this->m_workerIndex, argumentsBuffer, argumentIndexes, false);
            break;
        case DELAYED:
            if (callMonitor)
                this->m_incrementalMonitor->tupleProvedDelayed(this->m_workerIndex, argumentsBuffer, argumentIndexes, true);
            break;
        }
    }
    else {
        if (callMonitor)
            this->m_incrementalMonitor->tupleDerived(this->m_workerIndex, argumentsBuffer, argumentIndexes, false, false);
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline void FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::proveTupleProxy(ThreadContext& threadContext, FBFDeletionTaskWorker& target, const HeadAtomInfo& headAtomInfo, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    target.proveTuple(threadContext, argumentsBuffer, argumentIndexes);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline typename FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::AddResult FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::addProvedTuple(ThreadContext& threadContext, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    const TupleIndex tupleIndex = this->m_tripleTable.addTuple(threadContext, argumentsBuffer, argumentIndexes, 0, 0).second;
    bool inCheckedSet;
    if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF && this->m_equalityManager.normalize(argumentsBuffer, argumentIndexes, m_currentTupleBuffer5, this->m_currentTupleArgumentIndexes)) {
        const TupleIndex normalizedTupleIndex = this->m_tripleTable.getTupleIndex(threadContext, m_currentTupleBuffer5, this->m_currentTupleArgumentIndexes);
        inCheckedSet = normalizedTupleIndex != INVALID_TUPLE_INDEX && ((this->m_incrementalReasoningState.getCurrentLevelFlags(normalizedTupleIndex) & LF_CHECKED) == LF_CHECKED);
    }
    else
        inCheckedSet = (this->m_incrementalReasoningState.getCurrentLevelFlags(tupleIndex) & LF_CHECKED) == LF_CHECKED;
    if (inCheckedSet) {
        if (this->m_incrementalReasoningState.template addCurrentLevelFlags<false>(tupleIndex, LF_PROVED_NEW)) {
            this->m_incrementalReasoningState.getProvedList().template enqueue<false>(tupleIndex);
            return ADDED;
        }
        else
            return ALREADY_EXISTS;
    }
    else {
        if (this->m_incrementalReasoningState.template addGlobalFlags<false>(tupleIndex, GF_DELAYED))
            return DELAYED;
        else
            return ALREADY_DELAYED;
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::occursInEDB(ThreadContext& threadContext, const ResourceID resourceID) {
    for (size_t positionIndex = 0; positionIndex < 3; ++positionIndex) {
        m_currentTupleBuffer6[positionIndex] = resourceID;
        if (m_queriesForEBDContainmentCheckSPO[positionIndex]->open(threadContext) != 0)
            return true;
    }
    return false;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::provedInPreviousLevel(const TupleIndex tupleIndex, const TupleStatus tupleStatus, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF || !checkComponentLevel || this->m_componentLevel == 0)
        return false;
    return
        (tupleStatus & (TUPLE_STATUS_IDB_MERGED | TUPLE_STATUS_IDB)) == TUPLE_STATUS_IDB &&
        ((this->m_incrementalReasoningState.getGlobalFlags(tupleIndex) & (GF_DELETED | GF_ADDED)) != GF_DELETED) &&
        this->m_ruleIndex.getComponentLevel(argumentsBuffer, argumentIndexes) < this->m_componentLevel;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
void FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::propagate(ThreadContext& threadContext, const TupleIndex tupleIndex, const std::vector<ResourceID>& currentTupleBuffer) {
    // Check whether the propagated fact is proved
    if (callMonitor)
        this->m_incrementalMonitor->propagateStarted(this->m_workerIndex, currentTupleBuffer, this->m_currentTupleArgumentIndexes);
    if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF) {
        // Short-circuit the derivations of many reflexivity tuples by looking them up in the EDB.
        if (currentTupleBuffer[1] == OWL_SAME_AS_ID) {
            assert(currentTupleBuffer[0] == currentTupleBuffer[2]);
            const ResourceID originalResourceID = currentTupleBuffer[0];
            for (ResourceID denormalizedResourceID = originalResourceID; denormalizedResourceID != INVALID_RESOURCE_ID; denormalizedResourceID = this->m_equalityManager.getNextEqual(denormalizedResourceID)) {
                if (occursInEDB(threadContext, denormalizedResourceID)) {
                    const ResourceID normalizedProvedResourceID = m_provingEqualityManager.normalize(denormalizedResourceID);
                    m_currentTupleBuffer6[1] = OWL_SAME_AS_ID;
                    m_currentTupleBuffer6[0] = m_currentTupleBuffer6[2] = m_provingEqualityManager.normalize(normalizedProvedResourceID);
                    const TupleIndex tupleIndex = this->m_tripleTable.addTuple(threadContext, m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes, 0, 0).second;
                    if (this->m_incrementalReasoningState.template addCurrentLevelFlags<false>(tupleIndex, LF_PROVED_NEW)) {
                        this->m_incrementalReasoningState.getProvedList().template enqueue<false>(tupleIndex);
                        if (callMonitor)
                            this->m_incrementalMonitor->checkedReflexiveSameAsTupleProvedFromEDB(this->m_workerIndex, originalResourceID, denormalizedResourceID, normalizedProvedResourceID, true);
                    }
                    else {
                        if (callMonitor)
                            this->m_incrementalMonitor->checkedReflexiveSameAsTupleProvedFromEDB(this->m_workerIndex, originalResourceID, denormalizedResourceID, normalizedProvedResourceID, false);
                    }
                }
            }
        }
        // Prove the tuple from EDB or delayed
        bool firstTuple = true;
        for (m_currentTupleBuffer6[0] = currentTupleBuffer[0]; m_currentTupleBuffer6[0] != INVALID_RESOURCE_ID; m_currentTupleBuffer6[0] = this->m_equalityManager.getNextEqual(m_currentTupleBuffer6[0]))
            for (m_currentTupleBuffer6[1] = currentTupleBuffer[1]; m_currentTupleBuffer6[1] != INVALID_RESOURCE_ID; m_currentTupleBuffer6[1] = this->m_equalityManager.getNextEqual(m_currentTupleBuffer6[1]))
                for (m_currentTupleBuffer6[2] = currentTupleBuffer[2]; m_currentTupleBuffer6[2] != INVALID_RESOURCE_ID; m_currentTupleBuffer6[2] = this->m_equalityManager.getNextEqual(m_currentTupleBuffer6[2])) {
                    // Check whether the denormalized tuple is in the EDB or whether the normalized version is proved; we use getTupleIndex() so that the triple is not written into the triple table unnecessarily.
                    // Since getTupleIndex() is quite an expensive operation, we omit the call for the first tuple (which, due to the way the above loops are implemented, is tupleIndex).
                    TupleIndex denormalizedTupleIndex;
                    if (firstTuple) {
                        denormalizedTupleIndex = tupleIndex;
                        firstTuple = false;
                    }
                    else
                        denormalizedTupleIndex = this->m_tripleTable.getTupleIndex(threadContext, m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes);
                    if (callMonitor)
                        this->m_incrementalMonitor->checkedTupleChecked(this->m_workerIndex, currentTupleBuffer, m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes);
                    if (denormalizedTupleIndex != INVALID_TUPLE_INDEX) {
                        const TupleStatus tupleStatus = this->m_tripleTable.getTupleStatus(denormalizedTupleIndex);
                        const bool fromEDB = ((tupleStatus & TUPLE_STATUS_EDB) == TUPLE_STATUS_EDB);
                        const bool fromDelayed = !fromEDB && (this->m_incrementalReasoningState.getGlobalFlags(denormalizedTupleIndex) & GF_DELAYED) == GF_DELAYED;
                        const bool fromPreviousLevel = !fromEDB && !fromDelayed && provedInPreviousLevel(denormalizedTupleIndex, tupleStatus, m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes);
                        if (fromEDB || fromDelayed || fromPreviousLevel) {
                            // Normalize by the new equality manager before adding to the triple table
                            if (m_provingEqualityManager.normalize(m_currentTupleBuffer6, m_currentTupleBuffer7, this->m_currentTupleArgumentIndexes))
                                denormalizedTupleIndex = this->m_tripleTable.addTuple(threadContext, m_currentTupleBuffer7, this->m_currentTupleArgumentIndexes, 0, 0).second;
                            if (this->m_incrementalReasoningState.template addCurrentLevelFlags<false>(denormalizedTupleIndex, LF_PROVED_NEW)) {
                                this->m_incrementalReasoningState.getProvedList().template enqueue<false>(denormalizedTupleIndex);
                                if (callMonitor)
                                    this->m_incrementalMonitor->checkedTupleProved(this->m_workerIndex, currentTupleBuffer, m_currentTupleBuffer6, m_currentTupleBuffer7, this->m_currentTupleArgumentIndexes, fromEDB, fromDelayed, fromPreviousLevel, true);
                            }
                            else {
                                if (callMonitor)
                                    this->m_incrementalMonitor->checkedTupleProved(this->m_workerIndex, currentTupleBuffer, m_currentTupleBuffer6, m_currentTupleBuffer7, this->m_currentTupleArgumentIndexes, fromEDB, fromDelayed, fromPreviousLevel, false);
                            }
                        }
                    }
                }
    }
    else {
        if (callMonitor)
            this->m_incrementalMonitor->checkedTupleChecked(this->m_workerIndex, currentTupleBuffer, currentTupleBuffer, this->m_currentTupleArgumentIndexes);
        const TupleStatus tupleStatus = this->m_tripleTable.getTupleStatus(tupleIndex);
        const bool fromEDB = ((tupleStatus & TUPLE_STATUS_EDB) == TUPLE_STATUS_EDB);
        const bool fromDelayed = !fromEDB && (this->m_incrementalReasoningState.getGlobalFlags(tupleIndex) & GF_DELAYED) == GF_DELAYED;
        const bool fromPreviousLevel = !fromEDB && !fromDelayed && provedInPreviousLevel(tupleIndex, tupleStatus, currentTupleBuffer, this->m_currentTupleArgumentIndexes);
        if (fromEDB || fromDelayed || fromPreviousLevel) {
            if (this->m_incrementalReasoningState.template addCurrentLevelFlags<false>(tupleIndex, LF_PROVED_NEW)) {
                this->m_incrementalReasoningState.getProvedList().template enqueue<false>(tupleIndex);
                if (callMonitor)
                    this->m_incrementalMonitor->checkedTupleProved(this->m_workerIndex, currentTupleBuffer, currentTupleBuffer, currentTupleBuffer, this->m_currentTupleArgumentIndexes, fromEDB, fromDelayed, fromPreviousLevel, true);
            }
            else {
                if (callMonitor)
                    this->m_incrementalMonitor->checkedTupleProved(this->m_workerIndex, currentTupleBuffer, currentTupleBuffer, currentTupleBuffer, this->m_currentTupleArgumentIndexes, fromEDB, fromDelayed, fromPreviousLevel, false);
            }
        }
    }
    // Now saturate the proved facts
    if (callMonitor)
        this->m_incrementalMonitor->saturateProvedStarted(this->m_workerIndex);
    while (::atomicRead(this->m_taskRunning)) {
        m_currentTupleIndex2 = this->m_incrementalReasoningState.getProvedList().template dequeue<false>();
        if (m_currentTupleIndex2 == INVALID_TUPLE_INDEX)
            break;
        const TupleFlags tupleFlags = this->m_incrementalReasoningState.getCurrentLevelFlags(m_currentTupleIndex2);
        if ((tupleFlags & (LF_PROVED | LF_PROVED_MERGED | LF_PROVED_NEW)) == LF_PROVED_NEW && this->m_incrementalReasoningState.template addCurrentLevelFlags<false>(m_currentTupleIndex2, LF_PROVED)) {
            this->m_tripleTable.getStatusAndTuple(m_currentTupleIndex2, m_currentTupleBuffer6);
            if (callMonitor)
                this->m_incrementalMonitor->currentTupleExtracted(this->m_workerIndex, m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes);
            if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF && m_provingEqualityManager.normalize(m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes)) {
                this->m_incrementalReasoningState.template addCurrentLevelFlags<false>(m_currentTupleIndex2, LF_PROVED_MERGED);
                const AddResult addResult = addProvedTuple(threadContext, m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes);
                if (callMonitor) {
                    switch (addResult) {
                    case ALREADY_EXISTS:
                        this->m_incrementalMonitor->currentTupleNormalized(this->m_workerIndex, m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes, false);
                        break;
                    case ADDED:
                        this->m_incrementalMonitor->currentTupleNormalized(this->m_workerIndex, m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes, true);
                        break;
                    case ALREADY_DELAYED:
                    case DELAYED:
                        throw RDF_STORE_EXCEPTION("Internal error: if a current tuple is normalized, it is in checked so it cannot be delayed.");
                    }
                }
            }
            else if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF && m_currentTupleBuffer6[1] == OWL_SAME_AS_ID && m_currentTupleBuffer6[0] != m_currentTupleBuffer6[2])
                rewrite(threadContext, m_currentTupleBuffer6[0], m_currentTupleBuffer6[2]);
            else {
                if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF) {
                    m_currentTupleBuffer7[1] = OWL_SAME_AS_ID;
                    for (size_t positionIndex = 0; positionIndex < 3; ++positionIndex) {
                        const ResourceID resourceID = m_currentTupleBuffer6[positionIndex];
                        if (this->template checkReflexivity<1>(resourceID)) {
                            m_currentTupleBuffer7[0] = m_currentTupleBuffer7[2] = resourceID;
                            const AddResult addResult = addProvedTuple(threadContext, m_currentTupleBuffer7, this->m_currentTupleArgumentIndexes);
                            if (callMonitor) {
                                switch (addResult) {
                                case ALREADY_EXISTS:
                                    this->m_incrementalMonitor->reflexiveSameAsTupleDerived(this->m_workerIndex, resourceID, false);
                                    break;
                                case ADDED:
                                    this->m_incrementalMonitor->reflexiveSameAsTupleDerived(this->m_workerIndex, resourceID, true);
                                    break;
                                case ALREADY_DELAYED:
                                    this->m_incrementalMonitor->reflexiveSameAsTupleDerivedDelayed(this->m_workerIndex, resourceID, false);
                                    break;
                                case DELAYED:
                                    this->m_incrementalMonitor->reflexiveSameAsTupleDerivedDelayed(this->m_workerIndex, resourceID, true);
                                    break;
                                }
                            }
                        }
                    }
                }
                this->m_ruleIndex.template applyRulesToPositiveLiteralIncremental<FBFDeletionTaskWorkerType, &FBFDeletionTaskWorkerType::proveTupleProxy, checkComponentLevel ? ALL_IN_COMPONENT : ALL_COMPONENTS, callMonitor>(threadContext, *this, m_currentTupleBuffer6, this->m_currentTupleArgumentIndexes, this->m_componentLevel, this->m_incrementalMonitor);
            }
            if (callMonitor)
                this->m_incrementalMonitor->currentTupleProcessed(this->m_workerIndex);
        }
    }
    if (callMonitor)
        this->m_incrementalMonitor->propagateFinished(this->m_workerIndex);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::allProved(ThreadContext& threadContext, const TupleIndex normalizedTupleIndex, const std::vector<ResourceID>& normalizedArgumentsBuffer, const std::vector<ArgumentIndex>& normalizedArgumentIndexes) {
    if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF) {
        const TupleFlags tupleFlags = this->m_incrementalReasoningState.getGlobalFlags(normalizedTupleIndex);
        if ((tupleFlags & GF_DISPROVED) == GF_DISPROVED)
            return false;
        else if ((tupleFlags & GF_NORM_PROVED) != GF_NORM_PROVED) {
            const ResourceID subjectID = normalizedArgumentsBuffer[normalizedArgumentIndexes[0]];
            const ResourceID predicateID = normalizedArgumentsBuffer[normalizedArgumentIndexes[1]];
            const ResourceID objectID = normalizedArgumentsBuffer[normalizedArgumentIndexes[2]];
            for (m_currentTupleBuffer8[0] = subjectID; m_currentTupleBuffer8[0] != INVALID_RESOURCE_ID; m_currentTupleBuffer8[0] = this->m_equalityManager.getNextEqual(m_currentTupleBuffer8[0]))
                for (m_currentTupleBuffer8[1] = predicateID; m_currentTupleBuffer8[1] != INVALID_RESOURCE_ID; m_currentTupleBuffer8[1] = this->m_equalityManager.getNextEqual(m_currentTupleBuffer8[1]))
                    for (m_currentTupleBuffer8[2] = objectID; m_currentTupleBuffer8[2] != INVALID_RESOURCE_ID; m_currentTupleBuffer8[2] = this->m_equalityManager.getNextEqual(m_currentTupleBuffer8[2])) {
                        // getTupleIndex() is an expensive operation, so we try to avoid it if we can.
                        m_provingEqualityManager.normalize(m_currentTupleBuffer8, this->m_currentTupleArgumentIndexes, m_currentTupleBuffer9, this->m_currentTupleArgumentIndexes);
                        TupleIndex tupleIndex;
                        if (m_currentTupleBuffer9[0] == subjectID && m_currentTupleBuffer9[1] == predicateID && m_currentTupleBuffer9[2] == objectID)
                            tupleIndex = normalizedTupleIndex;
                        else
                            tupleIndex = this->m_tripleTable.getTupleIndex(threadContext, m_currentTupleBuffer9, this->m_currentTupleArgumentIndexes);
                        if (tupleIndex == INVALID_TUPLE_INDEX || (this->m_incrementalReasoningState.getCurrentLevelFlags(tupleIndex) & LF_PROVED) == 0)
                            return false;
                    }
            this->m_incrementalReasoningState.template addGlobalFlags<false>(normalizedTupleIndex, GF_NORM_PROVED);
        }
        return true;
    }
    else
        return (this->m_incrementalReasoningState.getCurrentLevelFlags(normalizedTupleIndex) & LF_PROVED) == LF_PROVED;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::allDisproved(ThreadContext& threadContext, const TupleIndex normalizedTupleIndex) {
    if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF) {
        if ((this->m_incrementalReasoningState.getGlobalFlags(normalizedTupleIndex) & GF_NORM_PROVED) == GF_NORM_PROVED)
            return false;
        this->m_tripleTable.getStatusAndTuple(normalizedTupleIndex, m_currentTupleBuffer8);
        const ResourceID subjectID = m_currentTupleBuffer8[0];
        const ResourceID predicateID = m_currentTupleBuffer8[1];
        const ResourceID objectID = m_currentTupleBuffer8[2];
        for (m_currentTupleBuffer8[0] = subjectID; m_currentTupleBuffer8[0] != INVALID_RESOURCE_ID; m_currentTupleBuffer8[0] = this->m_equalityManager.getNextEqual(m_currentTupleBuffer8[0]))
            for (m_currentTupleBuffer8[1] = predicateID; m_currentTupleBuffer8[1] != INVALID_RESOURCE_ID; m_currentTupleBuffer8[1] = this->m_equalityManager.getNextEqual(m_currentTupleBuffer8[1]))
                for (m_currentTupleBuffer8[2] = objectID; m_currentTupleBuffer8[2] != INVALID_RESOURCE_ID; m_currentTupleBuffer8[2] = this->m_equalityManager.getNextEqual(m_currentTupleBuffer8[2])) {
                    // getTupleIndex() is an expensive operation, so we try to avoid it if we can.
                    m_provingEqualityManager.normalize(m_currentTupleBuffer8, this->m_currentTupleArgumentIndexes, m_currentTupleBuffer9, this->m_currentTupleArgumentIndexes);
                    TupleIndex tupleIndex;
                    if (m_currentTupleBuffer9[0] == subjectID && m_currentTupleBuffer9[1] == predicateID && m_currentTupleBuffer9[2] == objectID)
                        tupleIndex = normalizedTupleIndex;
                    else
                        tupleIndex = this->m_tripleTable.getTupleIndex(threadContext, m_currentTupleBuffer9, this->m_currentTupleArgumentIndexes);
                    if (tupleIndex != INVALID_TUPLE_INDEX && (this->m_incrementalReasoningState.getCurrentLevelFlags(tupleIndex) & LF_PROVED) == LF_PROVED)
                        return false;
                }
        return true;
    }
    else
        return (this->m_incrementalReasoningState.getCurrentLevelFlags(normalizedTupleIndex) & LF_PROVED) != LF_PROVED;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::allReflexiveSameAsProved(ThreadContext& threadContext, const ResourceID resourceID) {
    m_currentTupleBuffer8[1] = OWL_SAME_AS_ID;
    for (ResourceID denormalizedResourceID = resourceID; denormalizedResourceID != INVALID_RESOURCE_ID; denormalizedResourceID = this->m_equalityManager.getNextEqual(denormalizedResourceID)) {
        m_currentTupleBuffer8[0] = m_currentTupleBuffer8[2] = denormalizedResourceID;
        m_provingEqualityManager.normalize(m_currentTupleBuffer8, this->m_currentTupleArgumentIndexes);
        const TupleIndex tupleIndex = this->m_tripleTable.getTupleIndex(threadContext, m_currentTupleBuffer8, this->m_currentTupleArgumentIndexes);
        if (tupleIndex != INVALID_TUPLE_INDEX && (this->m_incrementalReasoningState.getCurrentLevelFlags(tupleIndex) & LF_PROVED) == 0)
            return false;
    }
    return true;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::isSupportingAtomPositive(FBFDeletionTaskWorkerType& target, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return
        (tupleStatus & (TUPLE_STATUS_IDB | TUPLE_STATUS_IDB_MERGED)) == TUPLE_STATUS_IDB &&
        (target.m_incrementalReasoningState.getGlobalFlags(tupleIndex) & (GF_DISPROVED | GF_ADDED)) != GF_DISPROVED;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::isSupportingAtomNegative(FBFDeletionTaskWorkerType& target, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return
        ((tupleStatus & (TUPLE_STATUS_IDB | TUPLE_STATUS_IDB_MERGED)) == TUPLE_STATUS_IDB) ||
        ((target.m_incrementalReasoningState.getGlobalFlags(tupleIndex) & (GF_ADDED | GF_ADDED_MERGED)) == GF_ADDED);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline bool FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::check(ThreadContext& threadContext, TupleIndex checkTupleIndex, const std::vector<ResourceID>* checkArgumentsBuffer, const std::vector<ArgumentIndex>* checkArgumentIndexes) {
    m_checkedTuples.clear();
    // This implements the pseudo-code; however, due to possibly large recursion depth, we simulate recursion using a stack.
    std::unique_ptr<StackFrame> stack;
    std::unique_ptr<StackFrame> temporaryStackFrame;
    bool returnValue = false;
    // This is the beginning of the function as in the pseudo-code; arguments are stored in checkTupleIndex, checkArgumentsBuffer, and checkArgumentIndexes.
    check_start:
    if ((this->m_incrementalReasoningState.getGlobalFlags(checkTupleIndex) & (GF_DISPROVED | GF_ADDED)) != GF_DISPROVED && this->m_incrementalReasoningState.template addCurrentLevelFlags<false>(checkTupleIndex, LF_CHECKED)) {
        if (callMonitor)
            this->m_incrementalMonitor->checkingProvabilityStarted(this->m_workerIndex, *checkArgumentsBuffer, *checkArgumentIndexes, true);
        temporaryStackFrame = getStackFrame(checkTupleIndex, *checkArgumentsBuffer, *checkArgumentIndexes, std::move(stack));
        stack = std::move(temporaryStackFrame);
        // We record all checked tuples so that we can identify disproved facts after recursion finishes.
        m_checkedTuples.push_back(stack->m_tupleIndex);
        // Propagate the consequences of the current element.
        propagate(threadContext, stack->m_tupleIndex, stack->m_currentTupleBuffer);
        // Exit the function if the tuple has been proved.
        if (allProved(threadContext, stack->m_tupleIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes)) {
            stack->m_allProved = true;
            if (callMonitor)
                this->m_incrementalMonitor->tupleOptimized(this->m_workerIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes);
            goto check_return;
        }
        // If we're optimizing equality, we check reflexivity and replacement rules
        if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF) {
            // If this is an equality, we check the reflexivity rules.
            if (stack->m_currentTupleBuffer[1] == OWL_SAME_AS_ID) {
                for (stack->m_currentPositionIndex = 0; stack->m_currentPositionIndex < 3; ++stack->m_currentPositionIndex) {
                    stack->m_currentReflexivityCheckHelper = getReflexivityCheckHelper(stack->m_currentPositionIndex);
                    stack->m_currentReflexivityCheckHelper->m_currentTupleBuffer[stack->m_currentPositionIndex] = stack->m_currentTupleBuffer[0];
                    for (stack->m_multiplicity = stack->m_currentReflexivityCheckHelper->open(threadContext, this->m_incrementalReasoningState); stack->m_currentPositionIndex < 3 && stack->m_multiplicity != 0; stack->m_multiplicity = stack->m_currentReflexivityCheckHelper->advance(this->m_incrementalReasoningState)) {
                        // Exit the loop if all reflexivity tuples have been proved.
                        if (allReflexiveSameAsProved(threadContext, stack->m_currentTupleBuffer[0])) {
                            leaveReflexivityCheckHelper(std::move(stack->m_currentReflexivityCheckHelper), stack->m_currentPositionIndex);
                            if (callMonitor)
                                this->m_incrementalMonitor->reflexiveSameAsRuleInstancesOptimized(this->m_workerIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes);
                            // In Java, we'd use "break <label>" to break of the outer loop. Since C++ doesn't support this, we use a goto.
                            // One could solve this problem with a flag, but we'd need to add it to BackingAtom due to recursion, and
                            // all this seems too complex for a goto convert!
                            goto check_replacement;
                        }
                        // Check the rule instance.
                        if (callMonitor)
                            this->m_incrementalMonitor->backwardReflexiveSameAsRuleInstanceStarted(this->m_workerIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes, stack->m_currentReflexivityCheckHelper->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes);
                        // Make the recursive call
                        checkTupleIndex = stack->m_currentReflexivityCheckHelper->m_tupleIterator->getCurrentTupleIndex();
                        checkArgumentsBuffer = &stack->m_currentReflexivityCheckHelper->m_currentTupleBuffer;
                        checkArgumentIndexes = &s_reflexivityCheckHelperArgumentIndexes;
                        stack->m_returnAddress = 1;
                        goto check_start;
                        // Return address 1
                        check_return_address_1:
                        if (callMonitor)
                            this->m_incrementalMonitor->backwardReflexiveSameAsRuleInstanceFinished(this->m_workerIndex);
                        // Exit the function if the tuple has been proved.
                        if (allProved(threadContext, stack->m_tupleIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes)) {
                            leaveReflexivityCheckHelper(std::move(stack->m_currentReflexivityCheckHelper), stack->m_currentPositionIndex);
                            stack->m_allProved = true;
                            if (callMonitor)
                                this->m_incrementalMonitor->tupleOptimized(this->m_workerIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes);
                            goto check_return;
                        }
                    }
                    leaveReflexivityCheckHelper(std::move(stack->m_currentReflexivityCheckHelper), stack->m_currentPositionIndex);
                }
            }
            // Check replacement rules
            check_replacement:
            for (stack->m_currentPositionIndex = 0; stack->m_currentPositionIndex < 3; ++stack->m_currentPositionIndex) {
                if (!this->isSingleton(stack->m_currentTupleBuffer[stack->m_currentPositionIndex]) && this->template checkReflexivity<2>(stack->m_currentTupleBuffer[stack->m_currentPositionIndex])) {
                    m_currentTupleBuffer8[1] = OWL_SAME_AS_ID;
                    m_currentTupleBuffer8[0] = m_currentTupleBuffer8[2] = stack->m_currentTupleBuffer[stack->m_currentPositionIndex];
                    // Check if the tuple is disproved.
                    checkTupleIndex = this->m_tripleTable.addTuple(threadContext, m_currentTupleBuffer8, this->m_currentTupleArgumentIndexes, 0, 0).second;
                    if ((this->m_incrementalReasoningState.getGlobalFlags(checkTupleIndex) & GF_DISPROVED) != GF_DISPROVED) {
                        if (callMonitor)
                            this->m_incrementalMonitor->backwardReplacementRuleInstanceStarted(this->m_workerIndex, stack->m_currentPositionIndex, m_currentTupleBuffer8, this->m_currentTupleArgumentIndexes);
                        // Make the recursive call; we already loaded checkTupleIndex earlier.
                        checkArgumentsBuffer = &m_currentTupleBuffer8;
                        checkArgumentIndexes = &s_reflexivityCheckHelperArgumentIndexes;
                        stack->m_returnAddress = 2;
                        goto check_start;
                        // Return address 2
                        check_return_address_2:
                        if (callMonitor)
                            this->m_incrementalMonitor->backwardReplacementRuleInstanceFinished(this->m_workerIndex);
                        // Exit the function if the tuple has been proved.
                        if (allProved(threadContext, stack->m_tupleIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes)) {
                            stack->m_allProved = true;
                            if (callMonitor)
                                this->m_incrementalMonitor->tupleOptimized(this->m_workerIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes);
                            goto check_return;
                        }
                    }
                }
            }
        }
        // Now check the actual rules. At the outer level, iterate through all indenxing patterns
        for (stack->m_currentIndexingPatternNumber = 0; stack->m_currentIndexingPatternNumber < 8; ++stack->m_currentIndexingPatternNumber) {
            for (stack->m_currentHeadAtomInfo = this->m_ruleIndex.getMatchingHeadAtomInfos(threadContext, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes, stack->m_currentIndexingPatternNumber); stack->m_currentHeadAtomInfo != nullptr; stack->m_currentHeadAtomInfo = stack->m_currentHeadAtomInfo->getNextMatchingHeadAtomInfo(stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes)) {
                if (callMonitor)
                    this->m_incrementalMonitor->backwardRuleStarted(this->m_workerIndex, *stack->m_currentHeadAtomInfo);
                stack->m_currentBodyMatches = stack->m_currentHeadAtomInfo->getSupportingFactsEvaluator(stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes);
                for (stack->m_multiplicity = stack->m_currentBodyMatches->open(threadContext); stack->m_multiplicity != 0; stack->m_multiplicity = stack->m_currentBodyMatches->advance()) {
                    if (callMonitor)
                        this->m_incrementalMonitor->backwardRuleInstanceStarted(this->m_workerIndex, *stack->m_currentHeadAtomInfo, *stack->m_currentBodyMatches);
                    for (stack->m_currentBodyIndex = 0; stack->m_currentBodyIndex < stack->m_currentBodyMatches->getNumberOfBodyLiterals(); ++stack->m_currentBodyIndex) {
                        if (stack->m_currentHeadAtomInfo->isSupportingFactsAtom(stack->m_currentBodyIndex)) {
                            if (callMonitor)
                                this->m_incrementalMonitor->backwardRuleInstanceAtomStarted(this->m_workerIndex, *stack->m_currentHeadAtomInfo, *stack->m_currentBodyMatches, stack->m_currentBodyIndex);
                            // Make the recursive call
                            checkTupleIndex = stack->m_currentBodyMatches->getBodyLiteral(stack->m_currentBodyIndex).getCurrentTupleIndex();
                            checkArgumentsBuffer = &stack->m_currentBodyMatches->getBodyLiteral(stack->m_currentBodyIndex).getArgumentsBuffer();
                            checkArgumentIndexes = &stack->m_currentBodyMatches->getBodyLiteral(stack->m_currentBodyIndex).getArgumentIndexes();
                            stack->m_returnAddress = 3;
                            goto check_start;
                            // Return address 3
                            check_return_address_3:
                            if (callMonitor)
                                this->m_incrementalMonitor->backwardRuleInstanceAtomFinished(this->m_workerIndex);
                            // Exit the function if the tuple has been proved.
                            if (allProved(threadContext, stack->m_tupleIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes)) {
                                stack->m_currentHeadAtomInfo->leaveSupportFactsEvaluator(std::move(stack->m_currentBodyMatches));
                                stack->m_allProved = true;
                                if (callMonitor) {
                                    this->m_incrementalMonitor->tupleOptimized(this->m_workerIndex, stack->m_currentTupleBuffer, this->m_currentTupleArgumentIndexes);
                                    this->m_incrementalMonitor->backwardRuleInstanceFinished(this->m_workerIndex);
                                    this->m_incrementalMonitor->backwardRuleFinished(this->m_workerIndex);
                                }
                                goto check_return;
                            }
                        }
                    }
                    if (callMonitor)
                        this->m_incrementalMonitor->backwardRuleInstanceFinished(this->m_workerIndex);
                }
                stack->m_currentHeadAtomInfo->leaveSupportFactsEvaluator(std::move(stack->m_currentBodyMatches));
                if (callMonitor)
                    this->m_incrementalMonitor->backwardRuleFinished(this->m_workerIndex);
            }
        }
        // Return here
        check_return:
        returnValue = stack->m_allProved;
        temporaryStackFrame = std::move(stack);
        stack = std::move(temporaryStackFrame->m_previous);
        leaveStackFrame(std::move(temporaryStackFrame));
    }
    else {
        if (callMonitor)
            this->m_incrementalMonitor->checkingProvabilityStarted(this->m_workerIndex, *checkArgumentsBuffer, *checkArgumentIndexes, false);
        // In our pseudo-code, we compute return value here. However, this is useful only at the top of recursion
        // (the return value is ignored outherwise) so the following 'if' saves us unnecessary calls to allProved().
        if (stack.get() == nullptr)
            returnValue = allProved(threadContext, checkTupleIndex, *checkArgumentsBuffer, *checkArgumentIndexes);
    }
    if (callMonitor)
        this->m_incrementalMonitor->checkingProvabilityFinished(this->m_workerIndex);
    // We're done if there is nothing on the stack; otherwise, we continue recursion from the place as shown on the stack.
    if (stack.get() != nullptr) {
        switch (stack->m_returnAddress) {
        case 1:
            goto check_return_address_1;
        case 2:
            goto check_return_address_2;
        case 3:
            goto check_return_address_3;
        }
    }
    // This is executed after recursion finishes, and it determines which of the checked tuples are disproved.
    for (auto iterator = m_checkedTuples.begin(); iterator != m_checkedTuples.end(); ++iterator) {
        if (allDisproved(threadContext, *iterator)) {
            if (this->m_incrementalReasoningState.template addGlobalFlags<false>(*iterator, GF_DISPROVED)) {
                if (callMonitor) {
                    this->m_tripleTable.getStatusAndTuple(*iterator, m_currentTupleBuffer8);
                    this->m_incrementalMonitor->checkedTupleDisproved(this->m_workerIndex, m_currentTupleBuffer8, this->m_currentTupleArgumentIndexes, true);
                }
            }
            else {
                if (callMonitor) {
                    this->m_tripleTable.getStatusAndTuple(*iterator, m_currentTupleBuffer8);
                    this->m_incrementalMonitor->checkedTupleDisproved(this->m_workerIndex, m_currentTupleBuffer8, this->m_currentTupleArgumentIndexes, false);
                }
            }
        }
    }
    return returnValue;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
void FBFDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType>::run(ThreadContext& threadContext) {
    // Set up the incremental filters.
    typename BodyLiteralInfoFilters<FBFDeletionTaskWorkerType, &FBFDeletionTaskWorkerType::isProveAtomPositive, &FBFDeletionTaskWorkerType::isProveAtomNegative, false>::BodyLiteralInfoFilters bodyLiteralInfoFilters(this->m_ruleIndex, *this);
    typename BodyTupleIteratorFilters<FBFDeletionTaskWorkerType, &FBFDeletionTaskWorkerType::isProveIteratorPositive, &FBFDeletionTaskWorkerType::isProveIteratorNegative, BODY_TUPLE_ITERATOR_FILTER_INCREMENTAL>::BodyTupleIteratorFilters bodyTupleIteratorFiltersIncremental(this->m_ruleIndex, *this);
    typename BodyTupleIteratorFilters<FBFDeletionTaskWorkerType, &FBFDeletionTaskWorkerType::isSupportingAtomPositive, &FBFDeletionTaskWorkerType::isSupportingAtomNegative, BODY_TUPLE_ITERATOR_FILTER_SUPPORTING_FACTS>::BodyTupleIteratorFilters bodyTupleIteratorFiltersSupportingFacts(this->m_ruleIndex, *this);
    // Apply the pivotless rules so that the delayed facts are initialized properly.
    if (this->m_ruleIndex.hasPivotlessRules()) {
        if (!m_ruleQueue.initializeLarge())
            throw RDF_STORE_EXCEPTION("Cannot initialize rule queue.");
        this->m_ruleIndex.template enqueueRulesWithoutPositivePivot<checkComponentLevel>(this->m_componentLevel, m_ruleQueue);
        RuleInfo* ruleInfo;
        while ((ruleInfo = m_ruleQueue.template dequeue<false>()) != nullptr) {
            if (callMonitor)
                this->m_incrementalMonitor->pivotlessRulePropagationStarted(this->m_workerIndex, *ruleInfo);
            ruleInfo->template evaluateRuleIncremental<FBFDeletionTaskWorkerType, &FBFDeletionTaskWorkerType::proveTupleProxy, checkComponentLevel, callMonitor>(threadContext, *this, this->m_componentLevel, this->m_incrementalMonitor);
            if (callMonitor)
                this->m_incrementalMonitor->pivotlessRulePropagationFinished(this->m_workerIndex);
        }

    }
    // Now do the usual thing.
    AbstractDeletionTaskWorker<FBFDeletionTaskWorkerType>::run(threadContext);
}
