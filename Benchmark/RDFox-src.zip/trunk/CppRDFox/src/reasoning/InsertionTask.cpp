// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "AbstractMaterializationTaskImpl.h"
#include "InsertionTask.h"
#include "IncrementalReasoningState.h"
#include "IncrementalMonitor.h"

// InsertionTask

template<bool callMonitor>
always_inline std::unique_ptr<ReasoningTaskWorker> InsertionTask::doCreateWorker1(DatalogEngineWorker& datalogEngineWorker) {
    if (m_componentLevel == static_cast<size_t>(-1))
        return doCreateWorker2<callMonitor, false>(datalogEngineWorker);
    else
        return doCreateWorker2<callMonitor, true>(datalogEngineWorker);
}

template<bool callMonitor, bool checkComponentLevel>
always_inline std::unique_ptr<ReasoningTaskWorker> InsertionTask::doCreateWorker2(DatalogEngineWorker& datalogEngineWorker) {
    if (m_datalogEngine.getRuleIndex().componentLevelHasRules(m_componentLevel))
        return doCreateWorker3<callMonitor, checkComponentLevel, true>(datalogEngineWorker);
    else
        return doCreateWorker3<callMonitor, checkComponentLevel, false>(datalogEngineWorker);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent>
always_inline std::unique_ptr<ReasoningTaskWorker> InsertionTask::doCreateWorker3(DatalogEngineWorker& datalogEngineWorker) {
    switch (m_datalogEngine.getDataStore().getEqualityAxiomatizationType()) {
    case EQUALITY_AXIOMATIZATION_NO_UNA:
        return doCreateWorker4<callMonitor, checkComponentLevel, hasRulesInComponent, EQUALITY_AXIOMATIZATION_NO_UNA>(datalogEngineWorker);
    case EQUALITY_AXIOMATIZATION_UNA:
        return doCreateWorker4<callMonitor, checkComponentLevel, hasRulesInComponent, EQUALITY_AXIOMATIZATION_UNA>(datalogEngineWorker);
    case EQUALITY_AXIOMATIZATION_OFF:
    default:
        return doCreateWorker4<callMonitor, checkComponentLevel, hasRulesInComponent, EQUALITY_AXIOMATIZATION_OFF>(datalogEngineWorker);
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline std::unique_ptr<ReasoningTaskWorker> InsertionTask::doCreateWorker4(DatalogEngineWorker& datalogEngineWorker) {
    if (isMultithreaded())
        return std::unique_ptr<ReasoningTaskWorker>(new InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, true>(*this, datalogEngineWorker));
    else
        return std::unique_ptr<ReasoningTaskWorker>(new InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, false>(*this, datalogEngineWorker));
}

std::unique_ptr<ReasoningTaskWorker> InsertionTask::doCreateWorker(DatalogEngineWorker& datalogEngineWorker) {
    if (m_materializationMonitor == 0)
        return doCreateWorker1<false>(datalogEngineWorker);
    else
        return doCreateWorker1<true>(datalogEngineWorker);
}

void InsertionTask::doInitialize() {
    AbstractMaterializationTask::doInitialize();
    // The following test is needed because, when rules are added, the maximum component level changes; however, the new initially added lists are all empty, so the following is safe.
    if (m_componentLevel != static_cast<size_t>(-1) && m_incrementalReasoningState.hasInitiallyAddedList(m_componentLevel))
        m_incrementalReasoningState.getAddedList().appendUnprocessed(m_incrementalReasoningState.getInitiallyAddedList(m_componentLevel));
    m_incrementalReasoningState.getAddedList().resetDequeuePosition();
    if (m_datalogEngine.getRuleIndex().componentLevelHasRulesWithNegation(m_componentLevel))
        m_incrementalReasoningState.getDeleteList().resetDequeuePosition();
}

InsertionTask::InsertionTask(DatalogEngine& datalogEngine, IncrementalMonitor* const incrementalMonitor, IncrementalReasoningState& incrementalReasoningState, const size_t componentLevel, const uint64_t afterLastAddedInPreviousLevell) :
    AbstractMaterializationTask(datalogEngine, incrementalMonitor, componentLevel),
    m_incrementalReasoningState(incrementalReasoningState),
    m_afterLastAddedInPreviousLevels(afterLastAddedInPreviousLevell)
{
}

// InsertionMaterializationTaskWorker

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::InsertionTaskWorker(InsertionTask& insertionTask, DatalogEngineWorker& datalogEngineWorker) :
    AbstractMaterializationTaskWorker<InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded> >(insertionTask, datalogEngineWorker),
    m_insertionTask(insertionTask),
    m_incrementalReasoningState(m_insertionTask.m_incrementalReasoningState)
{
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::isInIDA(const TupleIndex tupleIndex, const TupleStatus tupleStatus, InsertionTaskWorkerType& target) {
    const TupleFlags tupleFlags = target.m_incrementalReasoningState.getGlobalFlags(tupleIndex);
    return
        (((tupleStatus & (TUPLE_STATUS_IDB | TUPLE_STATUS_IDB_MERGED)) == TUPLE_STATUS_IDB) && ((tupleFlags & (GF_DELETED | GF_ADDED_MERGED)) == 0)) ||
        ((tupleFlags & (GF_ADDED | GF_ADDED_MERGED)) == GF_ADDED) ||
        (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF && ((target.m_incrementalReasoningState.getCurrentLevelFlags(tupleIndex) & (LF_PROVED | LF_PROVED_MERGED)) == LF_PROVED) && ((tupleFlags & GF_ADDED_MERGED) == 0));
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::isActiveAtomPreviousLevelsPositive(InsertionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return
        isInIDA(tupleIndex, tupleStatus, target) &&
        (bodyLiteralInfo.getLiteralPosition() == AFTER_PIVOT_ATOM || (target.m_incrementalReasoningState.getGlobalFlags(tupleIndex) & (GF_ADDED | GF_DELETED)) != GF_ADDED);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::isActiveAtomPreviousLevelsNegative(InsertionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return
        isInIDA(tupleIndex, tupleStatus, target) ||
        (bodyLiteralInfo.getLiteralPosition() == AFTER_PIVOT_ATOM || (target.m_incrementalReasoningState.getGlobalFlags(tupleIndex) & (GF_ADDED | GF_DELETED)) == GF_DELETED);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::isActiveAtomRecursivePositive(InsertionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    if (bodyLiteralInfo.getLiteralPosition() == BEFORE_PIVOT_ATOM && target.m_currentTupleIndex == tupleIndex)
        return false;
    return isInIDA(tupleIndex, tupleStatus, target);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::isActiveAtomRecursiveNegative(InsertionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return isInIDA(tupleIndex, tupleStatus, target);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::isActiveAtomReevaluate(InsertionTaskWorkerType& target, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return isInIDA(tupleIndex, tupleStatus, target);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::isActiveAtomRewrite(InsertionTaskWorkerType& target, const TupleIndex tupleIndex, const TupleStatus tupleStatus) {
    return isInIDA(tupleIndex, tupleStatus, target);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline void InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::startRuleReevaluation() {
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::markMerged(const TupleIndex tupleIndex) {
    // The order is here important for parallelisation. Essentially, we ensure that GF_ADDED_MERGED means that a tuple has been merged during insertion.
    // This must be done before removing the tuple from the actual database so that we can test this flag in isIDA.
    const bool result = m_incrementalReasoningState.addGlobalFlags<multithreaded>(tupleIndex, GF_ADDED_MERGED);
    this->m_tripleTable.deleteAddTupleStatus(tupleIndex, 0, 0, 0, TUPLE_STATUS_IDB, TUPLE_STATUS_IDB, TUPLE_STATUS_IDB_MERGED);
    return result;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::addTuple(ThreadContext& threadContext, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    const TupleIndex tupleIndex = this->m_currentTupleReceiver->addTuple(threadContext, argumentsBuffer, argumentIndexes, 0, 0).second;
    if (m_incrementalReasoningState.addGlobalFlags<multithreaded>(tupleIndex, GF_ADDED_NEW)) {
        m_incrementalReasoningState.getAddedList().template enqueue<s_multithreaded>(tupleIndex);
        return true;
    }
    else
        return false;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline void InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::applyPreviousLevelRulesPositive(ThreadContext& threadContext) {
    typename BodyLiteralInfoFilters<InsertionTaskWorkerType, &InsertionTaskWorkerType::isActiveAtomPreviousLevelsPositive, &InsertionTaskWorkerType::isActiveAtomPreviousLevelsNegative, true>::BodyLiteralInfoFilters bodyLiteralInfoFilters(this->m_ruleIndex, *this);
    while (::atomicRead(this->m_taskRunning) && (this->m_currentTupleIndex = m_incrementalReasoningState.getAddedList().template dequeue<s_multithreaded>(m_insertionTask.m_afterLastAddedInPreviousLevels)) != INVALID_TUPLE_INDEX) {
        if ((m_incrementalReasoningState.getGlobalFlags(this->m_currentTupleIndex) & (GF_ADDED | GF_ADDED_MERGED | GF_DELETED)) == GF_ADDED) {
            this->m_tripleTable.getStatusAndTuple(this->m_currentTupleIndex, this->m_currentTupleBuffer1);
            if (callMonitor)
                this->m_materializationMonitor->currentTupleExtracted(this->m_workerIndex, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes);
            this->m_ruleIndex.template applyRulesToPositiveLiteralMain<InsertionTaskWorkerType, &InsertionTaskWorkerType::deriveTupleProxy, checkComponentLevel ? ALL_IN_COMPONENT : ALL_COMPONENTS, callMonitor>(threadContext, *this, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes, this->m_componentLevel, this->m_materializationMonitor);
            if (callMonitor)
                this->m_materializationMonitor->currentTupleProcessed(this->m_workerIndex);
        }
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline void InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::applyPreviousLevelRulesNegative(ThreadContext& threadContext) {
    typename BodyLiteralInfoFilters<InsertionTaskWorkerType, &InsertionTaskWorkerType::isActiveAtomPreviousLevelsPositive, &InsertionTaskWorkerType::isActiveAtomPreviousLevelsNegative, true>::BodyLiteralInfoFilters bodyLiteralInfoFilters(this->m_ruleIndex, *this);
    while (::atomicRead(this->m_taskRunning) && (this->m_currentTupleIndex = m_incrementalReasoningState.getDeleteList().template dequeue<s_multithreaded>()) != INVALID_TUPLE_INDEX) {
        if ((m_incrementalReasoningState.getGlobalFlags(this->m_currentTupleIndex) & (GF_ADDED | GF_ADDED_MERGED | GF_DELETED)) == GF_DELETED) {
            this->m_tripleTable.getStatusAndTuple(this->m_currentTupleIndex, this->m_currentTupleBuffer1);
            if (callMonitor)
                this->m_materializationMonitor->currentTupleExtracted(this->m_workerIndex, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes);
            this->m_ruleIndex.template applyRulesToNegativeLiteralMain<InsertionTaskWorkerType, &InsertionTaskWorkerType::deriveTupleProxy, checkComponentLevel ? ALL_IN_COMPONENT : ALL_COMPONENTS, callMonitor>(threadContext, *this, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes, this->m_componentLevel, this->m_materializationMonitor);
            if (callMonitor)
                this->m_materializationMonitor->currentTupleProcessed(this->m_workerIndex);
        }
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::tryApplyRecursiveRules(ThreadContext& threadContext) {
    this->m_currentTupleIndex = m_incrementalReasoningState.getAddedList().template dequeue<s_multithreaded>();
    if (this->m_currentTupleIndex != INVALID_TUPLE_INDEX && !isInIDA(this->m_currentTupleIndex, this->m_tripleTable.getStatusAndTuple(this->m_currentTupleIndex, this->m_currentTupleBuffer1), *this)) {
        if (callMonitor)
            this->m_materializationMonitor->currentTupleExtracted(this->m_workerIndex, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes);
        if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF && this->m_equalityManager.normalize(this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes)) {
            markMerged(this->m_currentTupleIndex);
            if (addTuple(threadContext, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes)) {
                if (callMonitor)
                    this->m_materializationMonitor->currentTupleNormalized(this->m_workerIndex, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes, true);
            }
            else {
                if (callMonitor)
                    this->m_materializationMonitor->currentTupleNormalized(this->m_workerIndex, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes, false);
            }
        }
        else {
            if (m_incrementalReasoningState.addGlobalFlags<multithreaded>(this->m_currentTupleIndex, GF_ADDED)) {
                if (callMonitor)
                    static_cast<IncrementalMonitor*>(this->m_materializationMonitor)->insertedTupleAddedToIDB(this->m_workerIndex, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes, true);
            }
            else {
                if (callMonitor)
                    static_cast<IncrementalMonitor*>(this->m_materializationMonitor)->insertedTupleAddedToIDB(this->m_workerIndex, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes, false);
            }
            if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF && this->m_currentTupleBuffer1[1] == OWL_SAME_AS_ID && this->m_currentTupleBuffer1[0] != this->m_currentTupleBuffer1[2])
                this->rewrite(threadContext, this->m_currentTupleBuffer1[0], this->m_currentTupleBuffer1[2]);
            else {
                if (equalityAxiomatizationType != EQUALITY_AXIOMATIZATION_OFF) {
                    this->m_currentTupleBuffer2[1] = OWL_SAME_AS_ID;
                    for (size_t positionIndex = 0; positionIndex < 3; ++positionIndex) {
                        const ResourceID resourceID = this->m_currentTupleBuffer1[positionIndex];
                        if (this->m_hasReflexiveSameAs.template add<s_multithreaded>(resourceID)) {
                            this->m_currentTupleBuffer2[0] = this->m_currentTupleBuffer2[2] = resourceID;
                            if (addTuple(threadContext, this->m_currentTupleBuffer2, this->m_currentTupleArgumentIndexes)) {
                                if (callMonitor)
                                    this->m_materializationMonitor->reflexiveSameAsTupleDerived(this->m_workerIndex, resourceID, true);
                            }
                            else {
                                if (callMonitor)
                                    this->m_materializationMonitor->reflexiveSameAsTupleDerived(this->m_workerIndex, resourceID, false);
                            }
                        }
                    }
                }
                if (hasRulesInComponent)
                    this->m_ruleIndex.template applyRulesToPositiveLiteralMain<InsertionTaskWorkerType, &InsertionTaskWorkerType::deriveTupleProxy, checkComponentLevel ? ALL_IN_COMPONENT : ALL_COMPONENTS, callMonitor>(threadContext, *this, this->m_currentTupleBuffer1, this->m_currentTupleArgumentIndexes, this->m_componentLevel, this->m_materializationMonitor);
            }
        }
        if (callMonitor)
            this->m_materializationMonitor->currentTupleProcessed(this->m_workerIndex);
        return true;
    }
    return false;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::hasAllocatedWork() {
    return false;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::canAllocateMoreWork() {
    return this->m_ruleQueue.peekDequeue() != nullptr || this->m_mergedConstants.peekDequeue() != INVALID_RESOURCE_ID || m_incrementalReasoningState.getAddedList().peekDequeue() != INVALID_TUPLE_INDEX;
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
void InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::run(ThreadContext& threadContext) {
    if (callMonitor)
        static_cast<IncrementalMonitor*>(this->m_materializationMonitor)->insertionPreviousLevelsStarted(this->m_workerIndex);
    if (hasRulesInComponent) {
        this->applyPreviousLevelRulesPositive(threadContext);
        if (this->m_ruleIndex.componentLevelHasRulesWithNegation(this->m_componentLevel))
            this->applyPreviousLevelRulesNegative(threadContext);
    }
    if (callMonitor)
        static_cast<IncrementalMonitor*>(this->m_materializationMonitor)->insertionRecursiveStarted(this->m_workerIndex);
    this->applyRecursiveRules(threadContext);
    if (callMonitor)
        static_cast<IncrementalMonitor*>(this->m_materializationMonitor)->insertionFinished(this->m_workerIndex);
}
