// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifndef RULEINDEX_H_
#define RULEINDEX_H_

#include "../Common.h"
#include "../logic/Logic.h"
#include "../dictionary/ResourceValueCache.h"
#include "../querying/TermArray.h"
#include "../equality/EqualityManager.h"
#include "../storage/ArgumentIndexSet.h"
#include "../storage/TupleFilter.h"
#include "../storage/TupleTable.h"
#include "../storage/TupleIterator.h"
#include "../util/MemoryManager.h"
#include "../util/SmartPointer.h"
#include "../util/SequentialHashTable.h"
#include "DependencyGraph.h"

class InputStream;
class OutputStream;
class DataStore;
class MaterializationMonitor;
class RuleIndex;
class BodyLiteralInfo;
class PivotBodyLiteralInfo;
class NonPivotBodyLiteralInfo;
class RuleConstantIndex;
class HeadAtomInfo;
class RuleInfo;
class BodyLiteralInfoIndex;
class PivotBodyLiteralInfoPatternMain;
class PivotBodyLiteralInfoPatternIncremental;
class HeadAtomInfoPatternMain;
template<class ObjectType, class PatternType> class LiteralPatternIndex;
template<class PatternType> class PivotBodyLiteralInfoByPatternIndex;
template<class PatternType> class HeadAtomInfoByPatternIndex;
template<typename E> class LockFreeQueue;

typedef PivotBodyLiteralInfoByPatternIndex<PivotBodyLiteralInfoPatternMain> PivotBodyLiteralInfoByPatternIndexMain;
typedef PivotBodyLiteralInfoByPatternIndex<PivotBodyLiteralInfoPatternIncremental> PivotBodyLiteralInfoByPatternIndexIncremental;
typedef HeadAtomInfoByPatternIndex<HeadAtomInfoPatternMain> HeadAtomInfoByPatternIndexMain;

enum ComponentLevelFilter { ALL_IN_COMPONENT = 0, WITH_PIVOT_IN_COMPONENT = 1, ALL_COMPONENTS = 2 };

enum LiteralPosition { BEFORE_PIVOT_ATOM, PIVOT_ATOM, AFTER_PIVOT_ATOM };

template<class T>
using HeadAtomConsumer = void (*)(ThreadContext&, T&, const HeadAtomInfo&, const std::vector<ResourceID>&, const std::vector<ArgumentIndex>&);

// BodyLiteralInfoFilters

template<class T>
using BodyLiteralInfoFilter = bool (*)(T&, const BodyLiteralInfo&, const TupleIndex, const TupleStatus);

template<class T, BodyLiteralInfoFilter<T> positiveBodyLiteralInfoFilter, BodyLiteralInfoFilter<T> negativeBodyLiteralInfoFilter, bool isMain>
class BodyLiteralInfoFilters {

protected:

    template<BodyLiteralInfoFilter<T> bodyLiteralInfoFilter>
    struct Filter : public TupleFilter {

        T& m_target;

        Filter(T& target) : m_target(target) {
        }

        virtual bool processTuple(const void* const tupleFilterContext, const TupleIndex tupleIndex, const TupleStatus tupleStatus) const {
            return (*bodyLiteralInfoFilter)(m_target, *reinterpret_cast<const BodyLiteralInfo*>(tupleFilterContext), tupleIndex, tupleStatus);
        }

    };

    RuleIndex& m_ruleIndex;
    Filter<positiveBodyLiteralInfoFilter> m_positiveTupleFilter;
    Filter<negativeBodyLiteralInfoFilter> m_negativeTupleFilter;

public:

    BodyLiteralInfoFilters(RuleIndex& ruleIndex, T& target);

    ~BodyLiteralInfoFilters();

};

// BodyTupleIteratorFilters

template<class T>
using BodyTupleIteratorFilter = bool (*)(T&, const TupleIndex, const TupleStatus);

enum BodyTupleIteratorFilterType { BODY_TUPLE_ITERATOR_FILTER_MAIN = 0, BODY_TUPLE_ITERATOR_FILTER_INCREMENTAL = 1, BODY_TUPLE_ITERATOR_FILTER_SUPPORTING_FACTS = 2 };

template<class T, BodyTupleIteratorFilter<T> positiveBodyTupleIteratorFilter, BodyTupleIteratorFilter<T> negativeBodyTupleIteratorFilter, BodyTupleIteratorFilterType type>
class BodyTupleIteratorFilters {

protected:

    template<BodyTupleIteratorFilter<T> bodyTupleIteratorFilter>
    struct Filter : public TupleFilter {

        T& m_target;

        Filter(T& target) : m_target(target) {
        }

        virtual bool processTuple(const void* const tupleFilterContext, const TupleIndex tupleIndex, const TupleStatus tupleStatus) const {
            return (*bodyTupleIteratorFilter)(m_target, tupleIndex, tupleStatus);
        }

    };

    RuleIndex& m_ruleIndex;
    Filter<positiveBodyTupleIteratorFilter> m_positiveTupleFilter;
    Filter<negativeBodyTupleIteratorFilter> m_negativeTupleFilter;


public:

    BodyTupleIteratorFilters(RuleIndex& ruleIndex, T& target);

    ~BodyTupleIteratorFilters();
    
};

// ApplicationManager

class ApplicationManager : private Unmovable {

protected:

    struct CompareVariables {
        size_t m_index1;
        size_t m_index2;

        CompareVariables(const size_t index1, const size_t index2) : m_index1(index1), m_index2(index2) {
        }
    };

    struct ArgumentToBuffer {
        size_t m_sourceIndex;
        ArgumentIndex m_targetIndex;

        ArgumentToBuffer(const size_t sourceIndex, const ArgumentIndex targetIndex) : m_sourceIndex(sourceIndex), m_targetIndex(targetIndex) {
        }
    };

    std::vector<CompareVariables> m_compareVariables;
    std::vector<ArgumentToBuffer> m_copyToBuffer;

public:

    ApplicationManager(const TermArray& termArray, const Literal& literal, const ArgumentIndexSet* variablesBoundBefore);

    bool satisfiesEqualities(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    bool prepareApply(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, std::vector<ResourceID>& targetArgumentsBuffer);

};

// LiteralPattern

template<class ObjectType, class PatternType>
class LiteralPattern : private Unmovable {

protected:

    friend class LiteralPatternIndex<ObjectType, PatternType>;

    std::vector<ResourceID> m_originalIndexingPattern;
    std::vector<ResourceID> m_currentIndexingPattern;
    size_t m_indexingPatternNumber;
    ObjectType* m_previousIndexed;
    ObjectType* m_nextIndexed;
    bool m_inByPatternIndex;

public:

    LiteralPattern(const std::vector<ResourceID>& defaultArgumentsBuffer, const EqualityManager& equalityManager, const TermArray& termArray, const Literal& literal);

    ObjectType* getPreviousIndexed() const {
        return m_previousIndexed;
    }

    ObjectType* getNextIndexed() const {
        return m_nextIndexed;
    }

    void ensureNormalized(const EqualityManager& equalityManager);

};

// PivotBodyLiteralInfoPatternMain

class PivotBodyLiteralInfoPatternMain : public LiteralPattern<PivotBodyLiteralInfo, PivotBodyLiteralInfoPatternMain> {

public:

    PivotBodyLiteralInfoPatternMain(const std::vector<ResourceID>& defaultArgumentsBuffer, const EqualityManager& equalityManager, const TermArray& termArray, const Literal& literal);

    LiteralPatternIndex<PivotBodyLiteralInfo, PivotBodyLiteralInfoPatternMain>& getLiteralPatternIndex();

};

// PivotBodyLiteralInfoPatternIncremental

class PivotBodyLiteralInfoPatternIncremental : public LiteralPattern<PivotBodyLiteralInfo, PivotBodyLiteralInfoPatternIncremental> {

public:

    PivotBodyLiteralInfoPatternIncremental(const std::vector<ResourceID>& defaultArgumentsBuffer, const EqualityManager& equalityManager, const TermArray& termArray, const Literal& literal);

    LiteralPatternIndex<PivotBodyLiteralInfo, PivotBodyLiteralInfoPatternIncremental>& getLiteralPatternIndex();

};

// HeadAtomInfoPatternMain

class HeadAtomInfoPatternMain : public LiteralPattern<HeadAtomInfo, HeadAtomInfoPatternMain> {

public:

    HeadAtomInfoPatternMain(const std::vector<ResourceID>& defaultArgumentsBuffer, const EqualityManager& equalityManager, const TermArray& termArray, const Literal& literal);

    LiteralPatternIndex<HeadAtomInfo, HeadAtomInfoPatternMain>& getLiteralPatternIndex();

};

// BodyLiteralInfo

class BodyLiteralInfo : private Unmovable {

    friend SmartPointer<BodyLiteralInfo>::ReferenceManagerType;
    friend class RuleInfo;
    friend class NonPivotBodyLiteralInfo;
    friend class BodyLiteralInfoIndex;
    friend class DependencyGraph;
    friend class RuleIndex;

protected:

    RuleIndex& m_ruleIndex;
    mutable int32_t m_referenceCount;
    const Literal m_literal;
    const size_t m_hashCode;
    size_t m_componentLevel;
    NonPivotBodyLiteralInfo* m_firstChild;
    const std::vector<ArgumentIndex> m_argumentIndexes;
    ArgumentIndexSet m_variablesBoundAfterLiteral;
    std::vector<HeadAtomInfo*> m_lastLiteralForHeadAtoms;
    std::unique_ptr<uint8_t[]> m_componentLevelFilters[ALL_COMPONENTS];

    void addHeadAtomInfo(HeadAtomInfo& headAtomInfo);

    void removeHeadAtomInfo(HeadAtomInfo& headAtomInfo);

    static always_inline size_t hashCodeFor(const BodyLiteralInfo* const parent, const Literal& literal, const LiteralPosition literalPosition) {
        return ((parent == 0 ? 0 : parent->m_hashCode) * 23 + literal->hash()) * 23 + static_cast<size_t>(literalPosition) * 7;
    }

    virtual void setThreadCapacity(const size_t numberOfThreads) = 0;

    virtual void ensureThreadReady(const size_t threadIndex) = 0;

    template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
    void literalMatched(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor);

    void resizeComponentLevelFilters();

    void clearComponentLevelFilters();

    void addToComponentLevelFilter(const ComponentLevelFilter componentLevelFilter, const size_t componentLevel);

    template<ComponentLevelFilter componentLevelFilter>
    always_inline bool isInComponentLevelFilter(const size_t componentLevel) const {
        if (componentLevelFilter == ALL_COMPONENTS)
            return true;
        else
            return (m_componentLevelFilters[componentLevelFilter][componentLevel >> 3] & (static_cast<uint8_t>(1) << (componentLevel & 0x7))) != 0;
    }
    
public:

    BodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, const size_t hashCode);

    virtual ~BodyLiteralInfo();

    always_inline const Literal& getLiteral() const {
        return m_literal;
    }

    always_inline size_t getHashCode() const {
        return m_hashCode;
    }

    always_inline size_t getComponentLevel() const {
        return m_componentLevel;
    }

    virtual BodyLiteralInfo* getParent() const = 0;

    virtual LiteralPosition getLiteralPosition() const = 0;

    always_inline const std::vector<ArgumentIndex>& getArgumentIndexes() const {
        return m_argumentIndexes;
    }

    template<uint8_t ruleType>
    const std::vector<ResourceID>& getArgumentsBuffer(const size_t threadIndex) const;

};

typedef SmartPointer<BodyLiteralInfo> BodyLiteralInfoPtr;

// PivotBodyLiteralInfo

class PivotBodyLiteralInfo : public ApplicationManager, public PivotBodyLiteralInfoPatternMain, public PivotBodyLiteralInfoPatternIncremental, public BodyLiteralInfo {

    friend SmartPointer<PivotBodyLiteralInfo>::ReferenceManagerType;
    friend class PivotBodyLiteralInfoPatternMain;
    friend class PivotBodyLiteralInfoPatternIncremental;

protected:

    const bool m_isPositive;

    virtual void setThreadCapacity(const size_t numberOfThreads);

    virtual void ensureThreadReady(const size_t threadIndex);

public:

    PivotBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, const LiteralPosition literalPosition, BodyLiteralInfo* const parent);

    virtual ~PivotBodyLiteralInfo();

    virtual BodyLiteralInfo* getParent() const;

    virtual LiteralPosition getLiteralPosition() const;

    template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
    void applyTo(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor);

};

typedef SmartPointer<PivotBodyLiteralInfo> PivotBodyLiteralInfoPtr;

// NonPivotBodyLiteralInfo

class NonPivotBodyLiteralInfo : public BodyLiteralInfo {

    friend SmartPointer<NonPivotBodyLiteralInfo>::ReferenceManagerType;
    friend class BodyLiteralInfo;

protected:

    LiteralPosition m_literalPosition;
    BodyLiteralInfoPtr m_parent;
    NonPivotBodyLiteralInfo* m_nextSibling;
    NonPivotBodyLiteralInfo* m_previousSibling;
    unique_ptr_vector<TupleIterator> m_tupleIteratorsByThreadMain;
    unique_ptr_vector<TupleIterator> m_tupleIteratorsByThreadIncremental;

    virtual void setThreadCapacity(const size_t numberOfThreads);

    virtual void ensureThreadReady(const size_t threadIndex);

    template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
    void matchLiteral(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor);

public:

    NonPivotBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, const LiteralPosition literalPosition, BodyLiteralInfo* const parent);

    virtual ~NonPivotBodyLiteralInfo();

    virtual BodyLiteralInfo* getParent() const;

    virtual LiteralPosition getLiteralPosition() const;

};

typedef SmartPointer<NonPivotBodyLiteralInfo> NonPivotBodyLiteralInfoPtr;

// BodyLiteralInfoIndex

class BodyLiteralInfoIndex : private Unmovable {

protected:

    struct BodyLiteralInfoIndexPolicy {

        static const size_t BUCKET_SIZE = sizeof(BodyLiteralInfo*);

        struct BucketContents {
            BodyLiteralInfo* m_bodyLiteralInfo;
        };

        static void getBucketContents(const uint8_t* const bucket, BucketContents& bucketContents);

        static BucketStatus getBucketContentsStatus(const BucketContents& bucketContents, const size_t valuesHashCode, const BodyLiteralInfo* const parent, const Literal& literal, const LiteralPosition literalPosition);

        static BucketStatus getBucketContentsStatus(const BucketContents& bucketContents, const size_t valuesHashCode, const BodyLiteralInfo* const bodyLiteralInfo);

        static bool setBucketContentsIfEmpty(uint8_t* const bucket, const BucketContents& bucketContents);

        static bool isBucketContentsEmpty(const BucketContents& bucketContents);

        static size_t getBucketContentsHashCode(const BucketContents& bucketContents);

        static size_t hashCodeFor(const BodyLiteralInfo* parent, const Literal& literal, const LiteralPosition literalPosition);

        static size_t hashCodeFor(const BodyLiteralInfo* bodyLiteralInfo);

        static void makeBucketEmpty(uint8_t* const bucket);

        static const BodyLiteralInfo* getBodyLiteralInfo(const uint8_t* const bucket);

        static void setBodyLiteralInfo(uint8_t* const bucket, BodyLiteralInfo* const bodyLiteralInfo);

    };

    friend class BodyLiteralInfo;

    SequentialHashTable<BodyLiteralInfoIndexPolicy> m_index;

    void removeBodyLiteralInfo(const BodyLiteralInfo* bodyLiteralInfo);

    template<class AT>
    SmartPointer<AT> getBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, BodyLiteralInfo* const parent, const LiteralPosition literalPosition);

public:

    BodyLiteralInfoIndex(MemoryManager& memoryManager);

    PivotBodyLiteralInfoPtr getPivotBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal);

    NonPivotBodyLiteralInfoPtr getNonPivotBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, BodyLiteralInfo* const parent, const LiteralPosition literalPosition);

    void initialize();

    void setThreadCapacity(const size_t numberOfThreads);

    void ensureThreadReady(const size_t threadIndex);

    BodyLiteralInfo* firstLiteralLocation(uint8_t* & location);

    BodyLiteralInfo*  nextLiteralLocation(uint8_t* & location);

};

// RuleConstant

struct RuleConstant : private Unmovable {
    RuleInfo& m_forRuleInfo;
    ResourceID m_defaultID;
    ResourceID m_currentMainID;
    ResourceID m_currentIncrementalID;
    RuleConstant* m_previous;
    RuleConstant* m_next;

    RuleConstant(RuleInfo& forRule, const ResourceID resourceID, const EqualityManager& equalityManager, const EqualityManager& provingEqualityManager);

};

// SupportingFactsEvaluator

class SupportingFactsEvaluator : private Unmovable {
    
    friend class HeadAtomInfo;
    
protected:
    
    ResourceValueCache& m_resourceValueCache;
    std::vector<ResourceID> m_argumentsBuffer;
    std::unique_ptr<TupleIterator> m_tupleIterator;
    
public:
    
    SupportingFactsEvaluator(ResourceValueCache& resourceValueCache, const ArgumentIndexSet& headVariables, DataStore& dataStore, const std::vector<ResourceID>& defaultArgumentsBuffer, const Rule& rule, const std::vector<ArgumentIndexSet>& literalVariables, const std::vector<std::vector<ArgumentIndex> >& argumentIndexes, const TermArray& termArray, const TupleFilter* & positiveTupleFilter, const TupleFilter* & negativeTupleFilter);

    SupportingFactsEvaluator(const SupportingFactsEvaluator& other);

    ~SupportingFactsEvaluator();

    always_inline const std::vector<ResourceID>& getArgumentsBuffer() const {
        return m_argumentsBuffer;
    }
    
    always_inline size_t getNumberOfBodyLiterals() const {
        return m_tupleIterator->getNumberOfChildIterators();
    }
    
    always_inline const TupleIterator& getBodyLiteral(const size_t literalIndex) const {
        return m_tupleIterator->getChildIterator(literalIndex);
    }
    
    size_t open(ThreadContext& threadContext);
    
    size_t advance();
    
};

// HeadAtomInfo

class HeadAtomInfo : public ApplicationManager, public HeadAtomInfoPatternMain {

    friend class DependencyGraph;
    friend class HeadAtomInfoPatternMain;
    friend class BodyLiteralInfo;
    friend class RuleInfo;

protected:

    RuleInfo& m_ruleInfo;
    const size_t m_headAtomIndex;
    size_t m_componentLevel;
    std::vector<ArgumentIndex> m_headArgumentIndexes;
    std::vector<ArgumentIndex> m_supportingFactsHeadArgumentIndexes;
    std::vector<bool> m_supportingFactsLiterals;
    std::vector<ArgumentToBuffer> m_supportingFactsCopyToBuffer;
    std::unique_ptr<SupportingFactsEvaluator> m_supportingFactsEvaluatorPrototype;
    unique_ptr_vector<SupportingFactsEvaluator> m_supportingFactsEvaluators;

    void setComponentLevel(const size_t componentLevel);

    template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, bool callMonitor>
    void headAtomMatched(ThreadContext& threadContext, T& target, const BodyLiteralInfo* const lastBodyLiteralInfo, MaterializationMonitor* const materializationMonitor);

public:

    HeadAtomInfo(RuleInfo& ruleInfo, const size_t headAtomIndex, std::unordered_set<ResourceID>& ruleConstants, TermArray& termArraySupporting, const std::vector<ArgumentIndexSet>& literalVariablesSupporting, const std::vector<std::vector<ArgumentIndex> >& argumentIndexesSupporting);

    always_inline RuleInfo& getRuleInfo() {
        return m_ruleInfo;
    }

    always_inline const RuleInfo& getRuleInfo() const {
        return m_ruleInfo;
    }

    const Atom& getAtom() const;

    always_inline size_t getHeadAtomIndex() const {
        return m_headAtomIndex;
    }

    always_inline size_t getComponentLevel() const {
        return m_componentLevel;
    }

    always_inline const std::vector<ArgumentIndex>& getHeadArgumentIndexes() const {
        return m_headArgumentIndexes;
    }

    HeadAtomInfo* getNextMatchingHeadAtomInfo(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    void normalizeConstantsMain(const EqualityManager& equalityManager);

    always_inline const std::vector<ArgumentIndex>& getSupportingFactsHeadArgumentIndexes() const {
        return m_supportingFactsHeadArgumentIndexes;
    }

    bool isSupportingFactsAtom(const size_t literalIndex) const;

    SupportingFactsEvaluator& getSupportingFactsEvaluatorPrototype(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    std::unique_ptr<SupportingFactsEvaluator> getSupportingFactsEvaluator(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    void leaveSupportFactsEvaluator(std::unique_ptr<SupportingFactsEvaluator> supportingFactsEvaluator);

};

// RuleInfo

class RuleInfo : public Unmovable {

    friend class RuleIndex;
    friend class HeadAtomInfo;
    friend class HeadAtomInfoPatternMain;
    friend class DependencyGraph;

protected:

    struct EvaluationPlan {
        PivotBodyLiteralInfo& m_pivotBodyLiteralInfo;
        BodyLiteralInfoPtr m_lastBodyLiteralInfo;
        size_t m_cost;

        EvaluationPlan(PivotBodyLiteralInfo& pivotBodyLiteralInfo, BodyLiteralInfoPtr lastBodyLiteralInfo, size_t cost);

    };

    RuleIndex& m_ruleIndex;
    const Rule m_rule;
    const bool m_isInternalRule;
    bool m_active;
    bool m_justAdded;
    bool m_justDeleted;
    bool m_isWithoutPositivePivot;
    bool m_hasNegation;
    bool m_hasAggregation;
    std::unique_ptr<uint8_t[]> m_componentLevelFilter;
    RuleInfo* m_nextRuleInfo;
    RuleInfo* m_previousRuleInfo;
    unique_ptr_vector<RuleConstant> m_ruleConstants;
    std::vector<EvaluationPlan> m_evaluationPlans;
    unique_ptr_vector<HeadAtomInfo> m_headAtomInfos;
    unique_ptr_vector<TupleIterator> m_ruleEvaluatorsByThreadMain;
    unique_ptr_vector<TupleIterator> m_ruleEvaluatorsByThreadIncremental;
    std::vector<std::pair<Variable, ArgumentIndex> > m_supportingFactsVariableIndexes;
    std::vector<ArgumentIndex> m_supportingFactsConstantsIndexes;
    std::vector<ResourceID> m_supportingFactsDefaultArgumentsBuffer;

    void compileForPivot(ArgumentIndexSet& boundArgumentsTemporary, const std::vector<ArgumentIndexSet>& literalVariables, const std::vector<std::vector<ArgumentIndex> >& argumentIndexes, const size_t pivotBodyIndex);

    void ensureActive();

    void ensureInactive();

    void resizeComponentLevelFilter();

    void updateComponentLevelFilters();

    void normalizeConstantsMain(const EqualityManager& equalityManager);

    void normalizeConstantsIncremental(const EqualityManager& equalityManager);

    always_inline HeadAtomInfo& getHeadAtomInfo(const size_t index) {
        return *m_headAtomInfos[index];
    }

    template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, bool checkComponentLevel, bool callMonitor>
    void evaluateRule(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) const;

public:

    RuleInfo(RuleIndex& ruleIndex, const Rule& rule, const bool isInternalRule, const bool active, const bool justAdded, const bool justDeleted);

    ~RuleInfo();

    always_inline const Rule& getRule() const {
        return m_rule;
    }

    always_inline bool isInternalRule() const {
        return m_isInternalRule;
    }

    always_inline bool getActive() const {
        return m_active;
    }

    always_inline bool hasNegation() const {
        return m_hasNegation;
    }

    always_inline bool hasAggregation() const {
        return m_hasAggregation;
    }

    always_inline bool getJustAdded() const {
        return m_justAdded;
    }

    always_inline bool getJustDeleted() const {
        return m_justDeleted;
    }

    always_inline size_t getNumberOfHeadAtoms() const {
        return m_headAtomInfos.size();
    }

    always_inline const HeadAtomInfo& getHeadAtomInfo(const size_t index) const {
        return *m_headAtomInfos[index];
    }

    always_inline bool isInComponentLevelFilter(const size_t componentLevel) const {
        return (m_componentLevelFilter[componentLevel >> 3] & (static_cast<uint8_t>(1) << (componentLevel & 0x7))) != 0;
    }

    const std::vector<ResourceID>& getDefaultArgumentsBuffer() const;

    void setThreadCapacity(const size_t numberOfThreads);

    void ensureThreadReady(const size_t threadIndex);

    template<class T, HeadAtomConsumer<T> headAtomConsumer, bool checkComponentLevel, bool callMonitor>
    void evaluateRuleMain(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) const;

    template<class T, HeadAtomConsumer<T> headAtomConsumer, bool checkComponentLevel, bool callMonitor>
    void evaluateRuleIncremental(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) const;

    always_inline const std::vector<std::pair<Variable, ArgumentIndex> >& getSupportingFactsVariableIndexes() const {
        return m_supportingFactsVariableIndexes;
    }

};

// LiteralPatternIndex

template<class ObjectType, class PatternType>
class LiteralPatternIndex : private Unmovable {

protected:

    struct LiteralPatternIndexPolicy {

        static const size_t BUCKET_SIZE = sizeof(ObjectType*);

        struct BucketContents {
            ObjectType* m_object;
        };

        static void getBucketContents(const uint8_t* const bucket, BucketContents& bucketContents);

        static BucketStatus getBucketContentsStatus(const BucketContents& bucketContents, const size_t valuesHashCode, const ResourceID subjectID, const ResourceID predicateID, const ResourceID objectID);

        static BucketStatus getBucketContentsStatus(const BucketContents& bucketContents, const size_t valuesHashCode, const ObjectType* const object);

        static bool setBucketContentsIfEmpty(uint8_t* const bucket, const BucketContents& bucketContents);

        static bool isBucketContentsEmpty(const BucketContents& bucketContents);

        static size_t getBucketContentsHashCode(const BucketContents& bucketContents);

        static size_t hashCodeFor(const ResourceID subjectID, const ResourceID predicateID, const ResourceID objectID);

        static size_t hashCodeFor(const ObjectType* const object);

        static void makeBucketEmpty(uint8_t* const bucket);

        static const ObjectType* getObject(const uint8_t* const bucket);

        static void setObject(uint8_t* const bucket, ObjectType* const object);

    };

    friend ObjectType;

    SequentialHashTable<LiteralPatternIndexPolicy> m_index;
    size_t m_patternCounts[8];

public:

    LiteralPatternIndex(MemoryManager& memoryManager);

    void initialize();

    void addObject(ObjectType* object);

    void removeObject(ObjectType* object);

    ObjectType* getFirstObject(ThreadContext& threadContext, const size_t indexingPatternNumber, const ResourceID subjectID, const ResourceID predicateID, const ResourceID objectID);

};

// PivotBodyLiteralInfoByPatternIndex

template<class PatternType>
class PivotBodyLiteralInfoByPatternIndex : public LiteralPatternIndex<PivotBodyLiteralInfo, PatternType> {

public:

    PivotBodyLiteralInfoByPatternIndex(MemoryManager& memoryManager);

    template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
    void applyRulesTo(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor);

};

// HeadAtomInfoByPatternIndex

template<class PatternType>
class HeadAtomInfoByPatternIndex : public LiteralPatternIndex<HeadAtomInfo, PatternType> {

public:

    HeadAtomInfoByPatternIndex(MemoryManager& memoryManager);

    HeadAtomInfo* getMatchingHeadAtomInfos(ThreadContext& threadContext, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t indexingPatternNumber);

};

// RuleConstantIndex

class RuleConstantIndex : private Unmovable {

protected:

    struct Entry {
        ArgumentIndex m_argumentsBufferIndex;
        RuleConstant* m_firstRuleConstant;

        Entry();
    };

    std::unordered_map<ResourceID, Entry> m_index;

public:

    RuleConstantIndex();

    void initialize();

    void newConstant(const ResourceID resourceID, const ArgumentIndex argumentsBufferIndex);

    bool getConstant(const ResourceID resourceID, ArgumentIndex& argumentsBufferIndex, RuleConstant* & firstRuleConstant) const;

    void addRuleConstant(RuleConstant& ruleConstant);

    void removeRuleConstant(RuleConstant& ruleConstant);

};

// RuleIndex

class RuleIndex : private Unmovable {

protected:

    struct ByThreadInfo : private ::Unmovable {
        ResourceValueCache m_resourceValueCache;
        std::vector<ResourceID> m_argumentBufferMain;
        std::vector<ResourceID> m_argumentBufferIncremental;
        const TupleFilter* m_positiveBodyLiteralFilterMain;
        const TupleFilter* m_negativeBodyLiteralFilterMain;
        const TupleFilter* m_positiveBodyLiteralFilterIncremental;
        const TupleFilter* m_negativeBodyLiteralFilterIncremental;
        const TupleFilter* m_positiveRuleEvaluatorFilterMain;
        const TupleFilter* m_negativeRuleEvaluatorFilterMain;
        const TupleFilter* m_positiveRuleEvaluatorFilterIncremental;
        const TupleFilter* m_negativeRuleEvaluatorFilterIncremental;
        const TupleFilter* m_positiveSupportingFactsFilter;
        const TupleFilter* m_negativeSupportingFactsFilter;

        ByThreadInfo(const Dictionary& dictionary, MemoryManager& memoryManager, const std::vector<ResourceID>& defaultArgumentsBuffer);

    };

    template<class T, BodyLiteralInfoFilter<T> positiveBodyLiteralInfoFilter, BodyLiteralInfoFilter<T> negativeBodyLiteralInfoFilter, bool isMain>
    friend class BodyLiteralInfoFilters;
    template<class T, BodyTupleIteratorFilter<T> positiveBodyTupleIteratorFilter, BodyTupleIteratorFilter<T> negativeBodyTupleIteratorFilter, BodyTupleIteratorFilterType type>
    friend class BodyTupleIteratorFilters;
    friend class BodyLiteralInfo;
    friend class PivotBodyLiteralInfo;
    friend class NonPivotBodyLiteralInfo;
    friend class PivotBodyLiteralInfoPatternMain;
    friend class PivotBodyLiteralInfoPatternIncremental;
    friend class HeadAtomInfo;
    friend class HeadAtomInfoPatternMain;
    friend class RuleInfo;

    DataStore& m_dataStore;
    const EqualityManager& m_equalityManager;
    EqualityManager m_provingEqualityManager;
    bool m_fastDestructors;
    TermArray m_termArray;
    LogicFactory m_logicFactory;
    std::vector<ResourceID> m_defaultArgumentsBuffer;
    unique_ptr_vector<ByThreadInfo> m_byThreadInfos;
    // Dependency graph
    DependencyGraph m_dependencyGraph;
    size_t m_componentLevelFilterLength;
    // Index of BodyLiteralInfo objects
    BodyLiteralInfoIndex m_bodyLiteralInfoIndex;
    // Index for materialization
    PivotBodyLiteralInfoByPatternIndexMain m_positivePivotBodyLiteralInfoByPatternIndexMain;
    PivotBodyLiteralInfoByPatternIndexMain m_negativePivotBodyLiteralInfoByPatternIndexMain;
    HeadAtomInfoByPatternIndexMain m_headAtomInfoByPatternIndexMain;
    // Index for incremental reasoning
    PivotBodyLiteralInfoByPatternIndexIncremental m_positivePivotBodyLiteralInfoByPatternIndexIncremental;
    // Index of rules by constants they contain
    RuleConstantIndex m_ruleConstantIndex;
    // m_ruleInfosByRule must die before other indexes, or the destructor of BodyLiteralInfo crashes.
    // Therefore, this member *must* be declared after the ones before.
    std::unordered_map<Rule, std::unique_ptr<RuleInfo> > m_ruleInfosByRule;
    RuleInfo* m_firstRuleInfo;
    RuleInfo* m_lastRuleInfo;
    size_t m_numberOfJustAddedRuleInfos;
    size_t m_numberOfJustDeletedRuleInfos;
    size_t m_numberOfPivotlessRules;
    size_t m_numberOfRulesWithNegation;
    size_t m_numberOfRulesWithAggregation;

    void addRuleInfo(const Rule& rule, const bool isInternalRule, const bool inMain, const bool justAdded, const bool justDeleted);

    size_t getCurrentNumberOfThreads() const;

    void updateDependencyGraph();

public:

    RuleIndex(DataStore& dataStore);

    ~RuleIndex();

    always_inline EqualityManager& getProvingEqualityManager() {
        return m_provingEqualityManager;
    }

    always_inline LogicFactory& getLogicFactory() {
        return m_logicFactory;
    }

    void initialize();

    always_inline const RuleInfo* getFirstRuleInfo() const {
        return m_firstRuleInfo;
    }

    always_inline const RuleInfo* getLastRuleInfo() const {
        return m_lastRuleInfo;
    }

    const RuleInfo* getRuleInfoFor(const Rule& rule) const;

    always_inline bool hasAtomNegations() const {
        return m_numberOfRulesWithNegation > 0;
    }

    always_inline bool hasAggregations() const {
        return m_numberOfRulesWithAggregation > 0;
    }

    always_inline bool isStratified() const {
        return m_dependencyGraph.isStratified();
    }

    always_inline size_t getFirstRuleComponentLevel() const {
        return m_dependencyGraph.getFirstRuleComponentLevel();
    }

    always_inline size_t getMaxComponentLevel() const {
        return m_dependencyGraph.getMaxComponentLevel();
    }

    always_inline bool componentLevelHasRules(const size_t componentLevel) const {
        return componentLevel == static_cast<size_t>(-1) || (m_dependencyGraph.getFirstRuleComponentLevel() <= componentLevel && componentLevel <= m_dependencyGraph.getMaxComponentLevel());
    }

    always_inline bool componentLevelHasRulesWithNegation(const size_t componentLevel) const {
        return componentLevel != static_cast<size_t>(-1) && m_dependencyGraph.containsRulesWithNegation(componentLevel);
    }

    always_inline bool componentLevelHasRulesWithAggregation(const size_t componentLevel) const {
        return componentLevel != static_cast<size_t>(-1) && m_dependencyGraph.containsRulesWithAggregation(componentLevel);
    }

    always_inline size_t getComponentLevel(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) const {
        return m_dependencyGraph.getComponentLevel(argumentsBuffer, argumentIndexes);
    }

    always_inline bool hasJustAddedRules() const {
        return m_numberOfJustAddedRuleInfos > 0;
    }

    always_inline bool hasJustDeletedRules() const {
        return m_numberOfJustDeletedRuleInfos > 0;
    }

    always_inline bool hasPivotlessRules() const {
        return m_numberOfPivotlessRules > 0;
    }

    always_inline bool hasRulesWithAggregation() const {
        return m_numberOfRulesWithAggregation > 0;
    }

    void forgetTemporaryConstants();

    void resetProving();

    void setThreadCapacity(const size_t numberOfThreads);

    void ensureThreadReady(const size_t threadIndex);

    bool addRule(const size_t currentNumberOfThreads, const Rule& rule, const bool isInternalRule);

    bool removeRule(const Rule& rule);

    void propagateDeletions();

    void propagateInsertions();

    void enqueueDeletedRules(LockFreeQueue<RuleInfo*>& ruleQueue);

    void enqueueInsertedRules(LockFreeQueue<RuleInfo*>& ruleQueue);

    template<bool checkComponentLevel>
    void enqueueRulesWithoutPositivePivot(const size_t componentLevel, LockFreeQueue<RuleInfo*>& ruleQueue);

    bool ensureConstantsAreNormalizedMain();

    template<bool checkComponentLevel>
    void enqueueRulesToReevaluateMain(const ResourceID mergedID, const size_t componentLevel, LockFreeQueue<RuleInfo*>& ruleQueue);

    bool ensureConstantsAreNormalizedIncremental();

    template<bool checkComponentLevel>
    void enqueueRulesToReevaluateIncremental(const ResourceID mergedID, const size_t componentLevel, LockFreeQueue<RuleInfo*>& ruleQueue);

    template<class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
    void applyRulesToPositiveLiteralMain(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor);

    template<class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
    void applyRulesToNegativeLiteralMain(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor);

    template<class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
    void applyRulesToPositiveLiteralIncremental(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor);

    HeadAtomInfo* getMatchingHeadAtomInfos(ThreadContext& threadContext, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t indexingPatternNumber);

    void getRules(DatalogProgram& datalogProgram, LogicFactory& logicFactory) const;

    void getRulePlan(std::ostream& output, Prefixes& prefixes);

    void recompileRules();

    void save(OutputStream& outputStream) const;

    void load(InputStream& inputStream);

};

// Some members that cannot be defined within class declaration due to the declaration order

template<uint8_t ruleType>
always_inline const std::vector<ResourceID>& BodyLiteralInfo::getArgumentsBuffer(const size_t threadIndex) const {
    switch (ruleType) {
    case 0:
    case 1:
    case 2:
        return m_ruleIndex.m_byThreadInfos[threadIndex]->m_argumentBufferMain;
    case 3:
        return m_ruleIndex.m_byThreadInfos[threadIndex]->m_argumentBufferIncremental;
    default:
        UNREACHABLE;
    }
}

always_inline const Atom& HeadAtomInfo::getAtom() const {
    return m_ruleInfo.getRule()->getHead(m_headAtomIndex);
}

always_inline const std::vector<ResourceID>& RuleInfo::getDefaultArgumentsBuffer() const {
    return m_ruleIndex.m_defaultArgumentsBuffer;
}

#endif /* RULEINDEX_H_ */
