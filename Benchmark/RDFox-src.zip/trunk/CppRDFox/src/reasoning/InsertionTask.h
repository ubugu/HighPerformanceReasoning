// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifndef INSERTIONTASK_H_
#define INSERTIONTASK_H_

#include "AbstractMaterializationTask.h"

class TupleReceiver;
class IncrementalReasoningState;
class IncrementalMonitor;
class BodyLiteralInfo;

// InsertionTask

class InsertionTask : public AbstractMaterializationTask {

protected:

    template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool mutithreaded>
    friend class InsertionTaskWorker;

    IncrementalReasoningState& m_incrementalReasoningState;
    const uint64_t m_afterLastAddedInPreviousLevels;

    template<bool callMonitor>
    std::unique_ptr<ReasoningTaskWorker> doCreateWorker1(DatalogEngineWorker& datalogEngineWorker);
    
    template<bool callMonitor, bool checkComponentLevel>
    std::unique_ptr<ReasoningTaskWorker> doCreateWorker2(DatalogEngineWorker& datalogEngineWorker);

    template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent>
    std::unique_ptr<ReasoningTaskWorker> doCreateWorker3(DatalogEngineWorker& datalogEngineWorker);

    template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
    std::unique_ptr<ReasoningTaskWorker> doCreateWorker4(DatalogEngineWorker& datalogEngineWorker);
    
    virtual std::unique_ptr<ReasoningTaskWorker> doCreateWorker(DatalogEngineWorker& datalogEngineWorker);

    void doInitialize();

public:

    InsertionTask(DatalogEngine& datalogEngine, IncrementalMonitor* const incrementalMonitor, IncrementalReasoningState& incrementalReasoningState, const size_t componentLeve, const uint64_t afterLastAddedInPreviousLevell);

    __ALIGNED(InsertionTask)

};

// InsertionTaskWorker

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
class InsertionTaskWorker : public AbstractMaterializationTaskWorker<InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded> > {

protected:

    InsertionTask& m_insertionTask;
    IncrementalReasoningState& m_incrementalReasoningState;

    typedef InsertionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded> InsertionTaskWorkerType;
    
public:

    static const bool s_callMonitor = callMonitor;
    static const bool s_checkComponentLevel = checkComponentLevel;
    static const EqualityAxiomatizationType s_equalityAxiomatizationType = equalityAxiomatizationType;
    static const bool s_multithreaded = multithreaded;

    InsertionTaskWorker(InsertionTask& insertionTask, DatalogEngineWorker& datalogEngineWorker);

    static bool isInIDA(const TupleIndex tupleIndex, const TupleStatus tupleStatus, InsertionTaskWorkerType& target);
    
    static bool isActiveAtomPreviousLevelsPositive(InsertionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus);

    static bool isActiveAtomPreviousLevelsNegative(InsertionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus);

    static bool isActiveAtomRecursivePositive(InsertionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus);

    static bool isActiveAtomRecursiveNegative(InsertionTaskWorkerType& target, const BodyLiteralInfo& bodyLiteralInfo, const TupleIndex tupleIndex, const TupleStatus tupleStatus);

    static bool isActiveAtomReevaluate(InsertionTaskWorkerType& target, const TupleIndex tupleIndex, const TupleStatus tupleStatus);

    static bool isActiveAtomRewrite(InsertionTaskWorkerType& target, const TupleIndex tupleIndex, const TupleStatus tupleStatus);

    void startRuleReevaluation();
    
    bool markMerged(const TupleIndex tupleIndex);

    bool addTuple(ThreadContext& threadContext, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes);

    void applyPreviousLevelRulesPositive(ThreadContext& threadContext);

    void applyPreviousLevelRulesNegative(ThreadContext& threadContext);

    bool tryApplyRecursiveRules(ThreadContext& threadContext);

    bool hasAllocatedWork();

    bool canAllocateMoreWork();
    
    virtual void run(ThreadContext& threadContext);

};

#endif /* INSERTIONTASK_H_ */
