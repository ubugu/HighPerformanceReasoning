// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "../RDFStoreException.h"
#include "../dictionary/ResourceValueCache.h"
#include "../builtins/BuiltinExpressionEvaluator.h"
#include "../builtins/FilterTupleIterator.h"
#include "../builtins/BindTupleIterator.h"
#include "../aggregates/AggregateFunctionEvaluator.h"
#include "../aggregates/AggregateTupleIterator.h"
#include "../formats/datalog/DatalogParser.h"
#include "../formats/sources/MemorySource.h"
#include "../querying/EmptyTupleIterator.h"
#include "../querying/NegationIterator.h"
#include "../querying/NestedIndexLoopJoinIterator.h"
#include "../storage/DataStore.h"
#include "../storage/TupleTable.h"
#include "../util/InputStream.h"
#include "../util/OutputStream.h"
#include "../util/ThreadContext.h"
#include "../util/InputImporter.h"
#include "../util/LockFreeQueue.h"
#include "RuleIndexImpl.h"

template<class RT>
static std::unique_ptr<TupleIterator> compileConjunction(const ArgumentIndexSet& initiallyBoundVariables, const std::vector<ResourceID>& defaultArgumentsBuffer, const std::vector<Literal>& conjunction, const std::vector<ArgumentIndexSet>& literalVariables, const std::vector<std::vector<ArgumentIndex> >& argumentIndexes, DataStore& dataStore, RT& resolver, ResourceValueCache& resourceValueCache, const TermArray& termArray, std::vector<ResourceID>& argumentsBuffer, const TupleFilter* & positiveTupleFilter, const TupleFilter* & negativeTupleFilter, const void* const tupleFilterContext);

template<class RT>
static std::unique_ptr<TupleIterator> createTupleIterator(const ArgumentIndexSet& variablesBoundSoFar, const std::vector<ResourceID>& defaultArgumentsBuffer, const Literal& literal, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, DataStore& dataStore, RT& resolver, ResourceValueCache& resourceValueCache, const TermArray& termArray, std::vector<ResourceID>& argumentsBuffer, const TupleFilter* & positiveTupleFilter, const TupleFilter* & negativeTupleFilter, const void* const tupleFilterContext) {
    switch (literal->getType()) {
    case ATOM_FORMULA:
        {
            // Add the constants to the tuple iterator, where constants are all arguments that are not variables.
            ArgumentIndexSet allInputArguments(variablesBoundSoFar);
            allInputArguments.intersectWith(literalVariables);
            for (auto iterator = argumentIndexes.begin(); iterator != argumentIndexes.end(); ++iterator)
                if (!literalVariables.contains(*iterator))
                    allInputArguments.add(*iterator);
            return dataStore.getTupleTable(to_pointer_cast<Atom>(literal)->getPredicate()->getName()).createTupleIterator(argumentsBuffer, argumentIndexes, allInputArguments, allInputArguments, positiveTupleFilter, tupleFilterContext);
        }
    case ATOM_NEGATION_FORMULA:
        {
            // Add the constants to the tuple iterator, where constants are all arguments that are not variables.
            ArgumentIndexSet allInputArguments(variablesBoundSoFar);
            allInputArguments.intersectWith(literalVariables);
            for (auto iterator = argumentIndexes.begin(); iterator != argumentIndexes.end(); ++iterator)
                if (!literalVariables.contains(*iterator))
                    allInputArguments.add(*iterator);
            return ::newNegationIterator(nullptr,dataStore.getTupleTable(to_pointer_cast<AtomNegation>(literal)->getAtom()->getPredicate()->getName()).createTupleIterator(argumentsBuffer, argumentIndexes, allInputArguments, allInputArguments, negativeTupleFilter, tupleFilterContext));
        }
    case FILTER_FORMULA:
        {
            // All arguments of FILTER are variables.
            ArgumentIndexSet allInputArguments(variablesBoundSoFar);
            allInputArguments.intersectWith(literalVariables);
            std::unique_ptr<BuiltinExpressionEvaluator> builtinExpressionEvaluatorMain(BuiltinExpressionEvaluator::compile(nullptr, dataStore, resourceValueCache, termArray, allInputArguments, allInputArguments, argumentsBuffer, to_pointer_cast<Filter>(literal)->getBuiltinExpression()));
            return ::newFilterTupleIterator(std::move(builtinExpressionEvaluatorMain), nullptr, argumentsBuffer, argumentIndexes, allInputArguments, allInputArguments);
        }
    case BIND_FORMULA:
        {
            // All arguments of BIND are variables.
            ArgumentIndexSet allInputArguments(variablesBoundSoFar);
            allInputArguments.intersectWith(literalVariables);
            std::unique_ptr<BuiltinExpressionEvaluator> builtinExpressionEvaluatorMain(BuiltinExpressionEvaluator::compile(nullptr, dataStore, resourceValueCache, termArray, allInputArguments, allInputArguments, argumentsBuffer, to_pointer_cast<Bind>(literal)->getBuiltinExpression()));
            return ::newBindTupleIterator<RT>(resolver, std::move(builtinExpressionEvaluatorMain), nullptr, argumentsBuffer, argumentIndexes, allInputArguments, allInputArguments);
        }
    case AGGREGATE_FORMULA:
        {
            Aggregate aggregate = static_pointer_cast<Aggregate>(literal);
            const std::vector<Atom>& conjunction = aggregate->getAtoms();
            ArgumentIndexSet initiallyBoundVariables(variablesBoundSoFar);
            initiallyBoundVariables.intersectWith(literalVariables);
            std::vector<Literal> underlyingConjunction;
            std::vector<ArgumentIndexSet> underlyingLiteralVariables;
            std::vector<std::vector<ArgumentIndex> > underlyingArgumentIndexes;
            for (auto atomIterator = conjunction.begin(); atomIterator != conjunction.end(); ++atomIterator) {
                underlyingConjunction.push_back(*atomIterator);
                underlyingLiteralVariables.emplace_back();
                underlyingArgumentIndexes.emplace_back();
                const std::vector<Term>& arguments = (*atomIterator)->getArguments();
                for (auto argumentIterator = arguments.begin(); argumentIterator != arguments.end(); ++argumentIterator) {
                    const ArgumentIndex argumentIndex = termArray.getPosition(*argumentIterator);
                    if ((*argumentIterator)->getType() == VARIABLE)
                        underlyingLiteralVariables.back().add(argumentIndex);
                    underlyingArgumentIndexes.back().push_back(argumentIndex);
                }
            }
            std::unique_ptr<TupleIterator> tupleIterator = compileConjunction<RT>(initiallyBoundVariables, defaultArgumentsBuffer, underlyingConjunction, underlyingLiteralVariables, underlyingArgumentIndexes, dataStore, resolver, resourceValueCache, termArray, argumentsBuffer, positiveTupleFilter, negativeTupleFilter, tupleFilterContext);
            ArgumentIndexSet allInputArguments;
            allInputArguments.setToUnion(variablesBoundSoFar, tupleIterator->getAllArguments());
            std::vector<AggregateFunctionCallInfo> aggregateFunctionCallInfos;
            const std::vector<AggregateBind>& aggregateBinds = aggregate->getAggregateBinds();
            for (auto bindIterator = aggregateBinds.begin(); bindIterator != aggregateBinds.end(); ++bindIterator) {
                const std::vector<BuiltinExpression>& arguments = (*bindIterator)->getArguments();
                aggregateFunctionCallInfos.emplace_back(AggregateFunctionEvaluator::createAggregateFunctionEvaluator((*bindIterator)->getFunctionName(), arguments.size()), unique_ptr_vector<BuiltinExpressionEvaluator>());
                for (auto argumentIterator = arguments.begin(); argumentIterator != arguments.end(); ++argumentIterator)
                    aggregateFunctionCallInfos.back().second.push_back(BuiltinExpressionEvaluator::compile(nullptr, dataStore, resourceValueCache, termArray, allInputArguments, allInputArguments, argumentsBuffer, *argumentIterator));
            }
            return ::newAggregateTupleIterator<RT>(resolver, nullptr, argumentIndexes, allInputArguments, allInputArguments, std::move(tupleIterator), aggregateFunctionCallInfos);
        }
    default:
        UNREACHABLE;
    }
}

static size_t getCountEstimate(const ArgumentIndexSet& boundVariablesFoFar, DataStore& dataStore, const std::vector<ResourceID>& defaultArgumentsBuffer, const Literal& literal, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes) {
    switch (literal->getType()) {
    case ATOM_FORMULA:
        {
            ArgumentIndexSet atomConstants;
            for (auto iterator = argumentIndexes.begin(); iterator != argumentIndexes.end(); ++iterator)
                if (literalVariables.contains(*iterator))
                    atomConstants.add(*iterator);
            return dataStore.getTupleTable(to_reference_cast<Atom>(literal).getPredicate()->getName()).getCountEstimate(ThreadContext::getCurrentThreadContext(), defaultArgumentsBuffer, argumentIndexes, atomConstants);
        }
    case ATOM_NEGATION_FORMULA:
        for (auto iterator = literalVariables.begin(); iterator != literalVariables.end(); ++iterator)
            if (!boundVariablesFoFar.contains(*iterator))
                return static_cast<size_t>(-1);
        return 1;
    case FILTER_FORMULA:
        // All arguments are guaranteed to be variables, because that is how FILTER atoms are constructed.
        for (auto iterator = argumentIndexes.begin(); iterator != argumentIndexes.end(); ++iterator)
            if (!boundVariablesFoFar.contains(*iterator))
                return static_cast<size_t>(-1);
        return 1;
    case BIND_FORMULA:
            // All arguments are guaranteed to be variables, because that is how BIND atoms are constructed.
        for (auto iterator = argumentIndexes.begin() + 1; iterator != argumentIndexes.end(); ++iterator)
            if (!boundVariablesFoFar.contains(*iterator))
                return static_cast<size_t>(-1);
        return 1;
    case AGGREGATE_FORMULA:
        {
            // The ON-variables are placed before all other arguments in AGGREGATE atoms.
            const auto onEnd = argumentIndexes.begin() + to_pointer_cast<Aggregate>(literal)->getOn().size();
            for (auto iterator = argumentIndexes.begin(); iterator != onEnd; ++iterator)
                if (!boundVariablesFoFar.contains(*iterator))
                    return static_cast<size_t>(-1);
            return 1;
        }
    default:
        UNREACHABLE;
    }
}

static size_t getNextBodyLiteralIndex(const ArgumentIndexSet& boundVariablesSoFar, DataStore& dataStore, const std::vector<ResourceID>& defaultArgumentsBuffer, const std::vector<Literal>& conjunction, std::vector<bool>& usedConjuncts, const std::vector<ArgumentIndexSet>& literalVariables, const std::vector<std::vector<ArgumentIndex> >& argumentIndexes) {
    size_t nextConjunctIndex = static_cast<size_t>(-1);
    bool bestSoFarIsCrossProduct = true;
    size_t bestSoFarCountEstimate = 0xffffffffffffffffULL;
    const size_t numberOfConjuncts = conjunction.size();
    for (size_t conjunctIndex = 0; conjunctIndex < numberOfConjuncts; ++conjunctIndex) {
        if (!usedConjuncts[conjunctIndex]) {
            const bool isCrossProduct = boundVariablesSoFar.size() != 0 && literalVariables[conjunctIndex].hasEmptyIntersectionWith(boundVariablesSoFar);
            const size_t countEstimate = getCountEstimate(boundVariablesSoFar, dataStore, defaultArgumentsBuffer, conjunction[conjunctIndex], literalVariables[conjunctIndex], argumentIndexes[conjunctIndex]);
            if (countEstimate != static_cast<size_t>(-1) && (nextConjunctIndex == static_cast<size_t>(-1) || (bestSoFarIsCrossProduct && !isCrossProduct) || (!bestSoFarIsCrossProduct && !isCrossProduct && countEstimate < bestSoFarCountEstimate))) {
                nextConjunctIndex = conjunctIndex;
                bestSoFarIsCrossProduct = isCrossProduct;
                bestSoFarCountEstimate = countEstimate;
            }
        }
    }
    return nextConjunctIndex;
}

template<class RT>
static std::unique_ptr<TupleIterator> compileConjunction(const ArgumentIndexSet& initiallyBoundVariables, const std::vector<ResourceID>& defaultArgumentsBuffer, const std::vector<Literal>& conjunction, const std::vector<ArgumentIndexSet>& literalVariables, const std::vector<std::vector<ArgumentIndex> >& argumentIndexes, DataStore& dataStore, RT& resolver, ResourceValueCache& resourceValueCache, const TermArray& termArray, std::vector<ResourceID>& argumentsBuffer, const TupleFilter* & positiveTupleFilter, const TupleFilter* & negativeTupleFilter, const void* const tupleFilterContext) {
    ArgumentIndexSet boundVariablesSoFar(initiallyBoundVariables);
    unique_ptr_vector<TupleIterator> childIterators;
    if (conjunction.size() == 0) {
        ArgumentIndexSet noBindings;
        childIterators.push_back(::newEmptyTupleIterator(nullptr, argumentsBuffer, noBindings, noBindings));
    }
    else {
        size_t conjunctsToMatch = conjunction.size();
        std::vector<bool> usedConjuncts(conjunctsToMatch, false);
        while (conjunctsToMatch != 0) {
            const size_t nextConjunctIndex = getNextBodyLiteralIndex(boundVariablesSoFar, dataStore, defaultArgumentsBuffer, conjunction, usedConjuncts, literalVariables, argumentIndexes);
            if (nextConjunctIndex == static_cast<size_t>(-1)) {
                std::ostringstream message;
                message << "Cannot reorder conjuncts to satisfy the binding requirements.";
                throw RDF_STORE_EXCEPTION(message.str());
            }
            childIterators.push_back(createTupleIterator<RT>(boundVariablesSoFar, defaultArgumentsBuffer, conjunction[nextConjunctIndex], literalVariables[nextConjunctIndex], argumentIndexes[nextConjunctIndex], dataStore, resolver, resourceValueCache, termArray, argumentsBuffer, positiveTupleFilter, negativeTupleFilter, tupleFilterContext));
            boundVariablesSoFar.unionWith(literalVariables[nextConjunctIndex]);
            usedConjuncts[nextConjunctIndex] = true;
            --conjunctsToMatch;
        }
    }
    return ::newNestedIndexLoopJoinIterator(nullptr, CARDINALITY_NOT_EXACT, dataStore, argumentsBuffer, initiallyBoundVariables, initiallyBoundVariables, boundVariablesSoFar, boundVariablesSoFar, boundVariablesSoFar, std::move(childIterators));
}

// ApplicationManager

ApplicationManager::ApplicationManager(const TermArray& termArray, const Literal& literal, const ArgumentIndexSet* variablesBoundBefore) :
    m_compareVariables(),
    m_copyToBuffer()
{
    const size_t numberOfArguments = literal->getNumberOfArguments();
    std::unordered_map<Variable, size_t> unboundVariablesToFirstOccurrences;
    for (size_t index = 0; index < numberOfArguments; ++index) {
        const Term& argument = literal->getArgument(index);
        if (argument->getType() == VARIABLE) {
            const ArgumentIndex argumentIndex = termArray.getPosition(argument);
            if (variablesBoundBefore == nullptr || !variablesBoundBefore->contains(argumentIndex)) {
                const Variable variable = static_pointer_cast<Variable>(argument);
                std::unordered_map<Variable, size_t>::iterator iterator = unboundVariablesToFirstOccurrences.find(variable);
                if (iterator == unboundVariablesToFirstOccurrences.end()) {
                    unboundVariablesToFirstOccurrences[variable] = index;
                    m_copyToBuffer.push_back(ArgumentToBuffer(index, argumentIndex));
                }
                else
                    m_compareVariables.push_back(CompareVariables(iterator->second, index));
            }
        }
    }
}

// LiteralPattern

template<class ObjectType, class PatternType>
LiteralPattern<ObjectType, PatternType>::LiteralPattern(const std::vector<ResourceID>& defaultArgumentsBuffer, const EqualityManager& equalityManager, const TermArray& termArray, const Literal& literal) :
    m_originalIndexingPattern(),
    m_currentIndexingPattern(),
    m_indexingPatternNumber(0),
    m_previousIndexed(nullptr),
    m_nextIndexed(nullptr),
    m_inByPatternIndex(false)
{
    const size_t numberOfArguments = literal->getNumberOfArguments();
    for (size_t index = 0; index < numberOfArguments; ++index) {
        m_indexingPatternNumber *= 2;
        const Term& argument = literal->getArgument(index);
        if (argument->getType() == VARIABLE) {
            m_originalIndexingPattern.push_back(INVALID_RESOURCE_ID);
            m_currentIndexingPattern.push_back(INVALID_RESOURCE_ID);
        }
        else {
            ++m_indexingPatternNumber;
            const ArgumentIndex argumentIndex = termArray.getPosition(argument);
            const ResourceID resourceID = defaultArgumentsBuffer[argumentIndex];
            m_originalIndexingPattern.push_back(resourceID);
            m_currentIndexingPattern.push_back(equalityManager.normalize(resourceID));
        }
    }
}

template<class ObjectType, class PatternType>
always_inline void LiteralPattern<ObjectType, PatternType>::ensureNormalized(const EqualityManager& equalityManager) {
    bool wasRemoved = false;
    const size_t indexingPatternSize = m_currentIndexingPattern.size();
    for (size_t index = 0; index < indexingPatternSize; ++index) {
        const ResourceID originalID = m_originalIndexingPattern[index];
        if (originalID != INVALID_RESOURCE_ID) {
            const ResourceID normalID = equalityManager.normalize(originalID);
            if (normalID != m_currentIndexingPattern[index]) {
                if (m_inByPatternIndex) {
                    static_cast<PatternType*>(this)->getLiteralPatternIndex().removeObject(static_cast<ObjectType*>(this));
                    wasRemoved = true;
                }
                m_currentIndexingPattern[index] = normalID;
            }
        }
    }
    if (wasRemoved)
        static_cast<PatternType*>(this)->getLiteralPatternIndex().addObject(static_cast<ObjectType*>(this));
}

// PivotBodyLiteralInfoPatternMain

PivotBodyLiteralInfoPatternMain::PivotBodyLiteralInfoPatternMain(const std::vector<ResourceID>& defaultArgumentsBuffer, const EqualityManager& equalityManager, const TermArray& termArray, const Literal& literal) :
    LiteralPattern<PivotBodyLiteralInfo, PivotBodyLiteralInfoPatternMain>(defaultArgumentsBuffer, equalityManager, termArray, literal)
{
}

always_inline LiteralPatternIndex<PivotBodyLiteralInfo, PivotBodyLiteralInfoPatternMain>& PivotBodyLiteralInfoPatternMain::getLiteralPatternIndex() {
    return static_cast<PivotBodyLiteralInfo*>(this)->m_isPositive ? static_cast<PivotBodyLiteralInfo*>(this)->m_ruleIndex.m_positivePivotBodyLiteralInfoByPatternIndexMain : static_cast<PivotBodyLiteralInfo*>(this)->m_ruleIndex.m_negativePivotBodyLiteralInfoByPatternIndexMain;
}

// PivotBodyLiteralInfoPatternIncremental

PivotBodyLiteralInfoPatternIncremental::PivotBodyLiteralInfoPatternIncremental(const std::vector<ResourceID>& defaultArgumentsBuffer, const EqualityManager& equalityManager, const TermArray& termArray, const Literal& literal) :
    LiteralPattern<PivotBodyLiteralInfo, PivotBodyLiteralInfoPatternIncremental>(defaultArgumentsBuffer, equalityManager, termArray, literal)
{
}

always_inline LiteralPatternIndex<PivotBodyLiteralInfo, PivotBodyLiteralInfoPatternIncremental>& PivotBodyLiteralInfoPatternIncremental::getLiteralPatternIndex() {
    return static_cast<PivotBodyLiteralInfo*>(this)->m_ruleIndex.m_positivePivotBodyLiteralInfoByPatternIndexIncremental;
}

// HeadAtomInfoPatternMain

HeadAtomInfoPatternMain::HeadAtomInfoPatternMain(const std::vector<ResourceID>& defaultArgumentsBuffer, const EqualityManager& equalityManager, const TermArray& termArray, const Literal& literal) :
    LiteralPattern<HeadAtomInfo, HeadAtomInfoPatternMain>(defaultArgumentsBuffer, equalityManager, termArray, literal)
{
}

always_inline LiteralPatternIndex<HeadAtomInfo, HeadAtomInfoPatternMain>& HeadAtomInfoPatternMain::getLiteralPatternIndex() {
    return static_cast<HeadAtomInfo*>(this)->m_ruleInfo.m_ruleIndex.m_headAtomInfoByPatternIndexMain;
}

// BodyLiteralInfo

always_inline void BodyLiteralInfo::addHeadAtomInfo(HeadAtomInfo& headAtomInfo) {
    m_lastLiteralForHeadAtoms.push_back(&headAtomInfo);
}

always_inline void BodyLiteralInfo::removeHeadAtomInfo(HeadAtomInfo& headAtomInfo) {
    std::vector<HeadAtomInfo*>::iterator iterator = m_lastLiteralForHeadAtoms.begin();
    while (iterator != m_lastLiteralForHeadAtoms.end()) {
        if (*iterator == &headAtomInfo)
            iterator = m_lastLiteralForHeadAtoms.erase(iterator);
        else
            ++iterator;
    }
}

always_inline void BodyLiteralInfo::resizeComponentLevelFilters() {
    for (int index = 0; index < ALL_COMPONENTS; ++index)
        m_componentLevelFilters[index].reset(new uint8_t[m_ruleIndex.m_componentLevelFilterLength]);
}

always_inline void BodyLiteralInfo::clearComponentLevelFilters() {
    for (int index = 0; index < ALL_COMPONENTS; ++index)
        ::memset(m_componentLevelFilters[index].get(), 0, m_ruleIndex.m_componentLevelFilterLength);
}

always_inline void BodyLiteralInfo::addToComponentLevelFilter(const ComponentLevelFilter componentLevelFilter, const size_t componentLevel) {
    m_componentLevelFilters[componentLevelFilter][componentLevel >> 3] |= static_cast<uint8_t>(1) << (componentLevel & 0x7);
}

BodyLiteralInfo::BodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, const size_t hashCode) :
    m_ruleIndex(ruleIndex),
    m_referenceCount(0),
    m_literal(literal),
    m_hashCode(hashCode),
    m_componentLevel(0),
    m_firstChild(nullptr),
    m_argumentIndexes(argumentIndexes),
    m_variablesBoundAfterLiteral(),
    m_lastLiteralForHeadAtoms(),
    m_componentLevelFilters()
{
    m_variablesBoundAfterLiteral.unionWith(literalVariables);
    m_variablesBoundAfterLiteral.shrinkToFit();
    // Put all atoms initially in component 0. In this way we don't need to initialize component levels
    // in case of equality reasoning; othrwise, this will get rewritten appropriately before reasoning.
    for (int index = 0; index < ALL_COMPONENTS; ++index) {
        m_componentLevelFilters[index].reset(new uint8_t[m_ruleIndex.m_componentLevelFilterLength]);
        m_componentLevelFilters[index][0] = 1;
    }
}

BodyLiteralInfo::~BodyLiteralInfo() {
    if (!m_ruleIndex.m_fastDestructors)
        m_ruleIndex.m_bodyLiteralInfoIndex.removeBodyLiteralInfo(this);
}

// PivotBodyLiteralInfo

void PivotBodyLiteralInfo::setThreadCapacity(const size_t numberOfThreads) {
}

void PivotBodyLiteralInfo::ensureThreadReady(const size_t threadIndex) {
}

PivotBodyLiteralInfo::PivotBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, const LiteralPosition literalPosition, BodyLiteralInfo* const parent) :
    ApplicationManager(ruleIndex.m_termArray, literal, nullptr),
    PivotBodyLiteralInfoPatternMain(ruleIndex.m_defaultArgumentsBuffer, ruleIndex.m_dataStore.getEqualityManager(), ruleIndex.m_termArray, literal),
    PivotBodyLiteralInfoPatternIncremental(ruleIndex.m_defaultArgumentsBuffer, ruleIndex.m_provingEqualityManager, ruleIndex.m_termArray, literal),
    BodyLiteralInfo(ruleIndex, literalVariables, argumentIndexes, literal, hashCodeFor(nullptr, literal, PIVOT_ATOM)),
    m_isPositive(m_literal->getType() == ATOM_FORMULA)
{
    assert(literalPosition == PIVOT_ATOM);
    assert(parent == nullptr);
    assert(m_literal->getType() == ATOM_FORMULA || m_literal->getType() == ATOM_NEGATION_FORMULA);
    PivotBodyLiteralInfoPatternMain::getLiteralPatternIndex().addObject(this);
    PivotBodyLiteralInfoPatternIncremental::getLiteralPatternIndex().addObject(this);
}

PivotBodyLiteralInfo::~PivotBodyLiteralInfo() {
    if (!m_ruleIndex.m_fastDestructors) {
        PivotBodyLiteralInfoPatternMain::getLiteralPatternIndex().removeObject(this);
        PivotBodyLiteralInfoPatternIncremental::getLiteralPatternIndex().removeObject(this);
    }
}

BodyLiteralInfo* PivotBodyLiteralInfo::getParent() const {
    return nullptr;
}

LiteralPosition PivotBodyLiteralInfo::getLiteralPosition() const {
    return PIVOT_ATOM;
}

// NonPivotBodyLiteralInfo

void NonPivotBodyLiteralInfo::setThreadCapacity(const size_t numberOfThreads) {
    while (m_tupleIteratorsByThreadMain.size() < numberOfThreads)
        m_tupleIteratorsByThreadMain.emplace_back(nullptr);
    while (m_tupleIteratorsByThreadMain.size() > numberOfThreads)
        m_tupleIteratorsByThreadMain.erase(m_tupleIteratorsByThreadMain.end() - 1);
    while (m_tupleIteratorsByThreadIncremental.size() < numberOfThreads)
        m_tupleIteratorsByThreadIncremental.emplace_back(nullptr);
    while (m_tupleIteratorsByThreadIncremental.size() > numberOfThreads)
        m_tupleIteratorsByThreadIncremental.erase(m_tupleIteratorsByThreadIncremental.end() - 1);
}

void NonPivotBodyLiteralInfo::ensureThreadReady(const size_t threadIndex) {
    if (m_tupleIteratorsByThreadMain[threadIndex].get() == nullptr) {
        CloneReplacements cloneReplacements;
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_positiveBodyLiteralFilterMain, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_positiveBodyLiteralFilterMain);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_negativeBodyLiteralFilterMain, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_negativeBodyLiteralFilterMain);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_argumentBufferMain, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_argumentBufferMain);
        m_tupleIteratorsByThreadMain[threadIndex] = m_tupleIteratorsByThreadMain[0]->clone(cloneReplacements);
    }
    if (m_tupleIteratorsByThreadIncremental[threadIndex].get() == nullptr) {
        CloneReplacements cloneReplacements;
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_positiveBodyLiteralFilterIncremental, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_positiveBodyLiteralFilterIncremental);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_negativeBodyLiteralFilterIncremental, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_negativeBodyLiteralFilterIncremental);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_argumentBufferIncremental, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_argumentBufferIncremental);
        m_tupleIteratorsByThreadIncremental[threadIndex] = m_tupleIteratorsByThreadIncremental[0]->clone(cloneReplacements);
    }
}

NonPivotBodyLiteralInfo::NonPivotBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, const LiteralPosition literalPosition, BodyLiteralInfo* const parent) :
    BodyLiteralInfo(ruleIndex, literalVariables, argumentIndexes, literal, hashCodeFor(parent, literal, literalPosition)),
    m_literalPosition(literalPosition),
    m_parent(parent),
    m_nextSibling(m_parent->m_firstChild),
    m_previousSibling(nullptr),
    m_tupleIteratorsByThreadMain(),
    m_tupleIteratorsByThreadIncremental()
{
    if (m_nextSibling)
        m_nextSibling->m_previousSibling = this;
    m_parent->m_firstChild = this;
    m_variablesBoundAfterLiteral.unionWith(m_parent->m_variablesBoundAfterLiteral);
    m_variablesBoundAfterLiteral.shrinkToFit();
    m_tupleIteratorsByThreadMain.push_back(createTupleIterator<Dictionary>(m_parent->m_variablesBoundAfterLiteral, m_ruleIndex.m_defaultArgumentsBuffer, m_literal, literalVariables, argumentIndexes, m_ruleIndex.m_dataStore, m_ruleIndex.m_dataStore.getDictionary(), m_ruleIndex.m_byThreadInfos[0]->m_resourceValueCache, m_ruleIndex.m_termArray, m_ruleIndex.m_byThreadInfos[0]->m_argumentBufferMain, m_ruleIndex.m_byThreadInfos[0]->m_positiveBodyLiteralFilterMain, m_ruleIndex.m_byThreadInfos[0]->m_negativeBodyLiteralFilterMain, this));
    m_tupleIteratorsByThreadIncremental.push_back(createTupleIterator<Dictionary>(m_parent->m_variablesBoundAfterLiteral, m_ruleIndex.m_defaultArgumentsBuffer, m_literal, literalVariables, argumentIndexes, m_ruleIndex.m_dataStore, m_ruleIndex.m_dataStore.getDictionary(), m_ruleIndex.m_byThreadInfos[0]->m_resourceValueCache, m_ruleIndex.m_termArray, m_ruleIndex.m_byThreadInfos[0]->m_argumentBufferIncremental, m_ruleIndex.m_byThreadInfos[0]->m_positiveBodyLiteralFilterIncremental, m_ruleIndex.m_byThreadInfos[0]->m_negativeBodyLiteralFilterIncremental, this));
    setThreadCapacity(m_ruleIndex.getCurrentNumberOfThreads());
}

NonPivotBodyLiteralInfo::~NonPivotBodyLiteralInfo() {
    if (!m_ruleIndex.m_fastDestructors) {
        if (m_nextSibling)
            m_nextSibling->m_previousSibling = m_previousSibling;
        if (m_previousSibling)
            m_previousSibling->m_nextSibling = m_nextSibling;
        else
            m_parent->m_firstChild = m_nextSibling;
    }
}

BodyLiteralInfo* NonPivotBodyLiteralInfo::getParent() const {
    return m_parent.get();
}

LiteralPosition NonPivotBodyLiteralInfo::getLiteralPosition() const {
    return m_literalPosition;
}

// BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy

always_inline void BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::getBucketContents(const uint8_t* const bucket, BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::BucketContents& bucketContents) {
    bucketContents.m_bodyLiteralInfo = const_cast<BodyLiteralInfo*>(*reinterpret_cast<const BodyLiteralInfo* const*>(bucket));
}

always_inline BucketStatus BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::getBucketContentsStatus(const BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::BucketContents& bucketContents, const size_t valuesHashCode, const BodyLiteralInfo* parent, const Literal& literal, const LiteralPosition literalPosition) {
    if (bucketContents.m_bodyLiteralInfo == nullptr)
        return BUCKET_EMPTY;
    else
        return bucketContents.m_bodyLiteralInfo->getParent() == parent && bucketContents.m_bodyLiteralInfo->getLiteral() == literal && bucketContents.m_bodyLiteralInfo->getLiteralPosition() == literalPosition ? BUCKET_CONTAINS : BUCKET_NOT_CONTAINS;
}

always_inline BucketStatus BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::getBucketContentsStatus(const BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::BucketContents& bucketContents, const size_t valuesHashCode, const BodyLiteralInfo* bodyLiteralInfo) {
    if (bucketContents.m_bodyLiteralInfo == nullptr)
        return BUCKET_EMPTY;
    else
        return bucketContents.m_bodyLiteralInfo == bodyLiteralInfo ? BUCKET_CONTAINS : BUCKET_NOT_CONTAINS;
}

always_inline bool BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::setBucketContentsIfEmpty(uint8_t* const bucket, const BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::BucketContents& bucketContents) {
    if (*reinterpret_cast<BodyLiteralInfo**>(bucket) == nullptr) {
        setBodyLiteralInfo(bucket, bucketContents.m_bodyLiteralInfo);
        return true;
    }
    else
        return false;
}

always_inline bool BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::isBucketContentsEmpty(const BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::BucketContents& bucketContents) {
    return bucketContents.m_bodyLiteralInfo == nullptr;
}

always_inline size_t BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::getBucketContentsHashCode(const BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::BucketContents& bucketContents) {
    return bucketContents.m_bodyLiteralInfo->getHashCode();
}

always_inline size_t BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::hashCodeFor(const BodyLiteralInfo* parent, const Literal& literal, const LiteralPosition literalPosition) {
    return BodyLiteralInfo::hashCodeFor(parent, literal, literalPosition);
}

always_inline size_t BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::hashCodeFor(const BodyLiteralInfo* bodyLiteralInfo) {
    return bodyLiteralInfo->getHashCode();
}

always_inline void BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::makeBucketEmpty(uint8_t* const bucket) {
    *reinterpret_cast<BodyLiteralInfo**>(bucket) = nullptr;
}

always_inline const BodyLiteralInfo* BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::getBodyLiteralInfo(const uint8_t* const bucket) {
    return *reinterpret_cast<const BodyLiteralInfo* const*>(bucket);
}

always_inline void BodyLiteralInfoIndex::BodyLiteralInfoIndexPolicy::setBodyLiteralInfo(uint8_t* const bucket, BodyLiteralInfo* const bodyLiteralInfo) {
    *reinterpret_cast<BodyLiteralInfo**>(bucket) = bodyLiteralInfo;
}

// BodyLiteralInfoIndex

void BodyLiteralInfoIndex::removeBodyLiteralInfo(const BodyLiteralInfo* bodyLiteralInfo) {
    SequentialHashTable<BodyLiteralInfoIndexPolicy>::BucketDescriptor bucketDescriptor;
    ThreadContext& threadContext = ThreadContext::getCurrentThreadContext();
    m_index.acquireBucket(threadContext, bucketDescriptor, bodyLiteralInfo);
    m_index.continueBucketSearch(threadContext, bucketDescriptor, bodyLiteralInfo);
    m_index.deleteBucket(threadContext, bucketDescriptor);
    m_index.releaseBucket(threadContext, bucketDescriptor);
}

template<class AT>
always_inline SmartPointer<AT> BodyLiteralInfoIndex::getBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, BodyLiteralInfo* const parent, const LiteralPosition literalPosition) {
    SequentialHashTable<BodyLiteralInfoIndexPolicy>::BucketDescriptor bucketDescriptor;
    ThreadContext& threadContext = ThreadContext::getCurrentThreadContext();
    m_index.acquireBucket(threadContext, bucketDescriptor, parent, literal, literalPosition);
    if (m_index.continueBucketSearch(threadContext, bucketDescriptor, parent, literal, literalPosition) == BUCKET_EMPTY) {
        bucketDescriptor.m_bucketContents.m_bodyLiteralInfo = new AT(ruleIndex, literalVariables, argumentIndexes, literal, literalPosition, parent);
        m_index.getPolicy().setBodyLiteralInfo(bucketDescriptor.m_bucket, bucketDescriptor.m_bucketContents.m_bodyLiteralInfo);
        m_index.acknowledgeInsert(threadContext, bucketDescriptor);
    }
    m_index.releaseBucket(threadContext, bucketDescriptor);
    return SmartPointer<AT>(static_cast<AT*>(bucketDescriptor.m_bucketContents.m_bodyLiteralInfo));
}

BodyLiteralInfoIndex::BodyLiteralInfoIndex(MemoryManager& memoryManager) : m_index(memoryManager, HASH_TABLE_LOAD_FACTOR) {
}

PivotBodyLiteralInfoPtr BodyLiteralInfoIndex::getPivotBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal) {
    return getBodyLiteralInfo<PivotBodyLiteralInfo>(ruleIndex, literalVariables, argumentIndexes, literal, nullptr, PIVOT_ATOM);
}

NonPivotBodyLiteralInfoPtr BodyLiteralInfoIndex::getNonPivotBodyLiteralInfo(RuleIndex& ruleIndex, const ArgumentIndexSet& literalVariables, const std::vector<ArgumentIndex>& argumentIndexes, const Literal& literal, BodyLiteralInfo* const parent, const LiteralPosition literalPosition) {
    return getBodyLiteralInfo<NonPivotBodyLiteralInfo>(ruleIndex, literalVariables, argumentIndexes, literal, parent, literalPosition);
}

void BodyLiteralInfoIndex::initialize() {
    if (!m_index.initialize(HASH_TABLE_INITIAL_SIZE))
        throw RDF_STORE_EXCEPTION("Cannot initialize BodyLiteralInfoIndex.");
}

void BodyLiteralInfoIndex::setThreadCapacity(const size_t numberOfThreads) {
    if (m_index.isInitialized()) {
        const uint8_t* bucket = m_index.getFirstBucket();
        while (bucket != m_index.getAfterLastBucket()) {
            BodyLiteralInfo* bodyLiteralInfo = const_cast<BodyLiteralInfo*>(m_index.getPolicy().getBodyLiteralInfo(bucket));
            if (bodyLiteralInfo != nullptr)
                bodyLiteralInfo->setThreadCapacity(numberOfThreads);
            bucket += m_index.getPolicy().BUCKET_SIZE;
        }
    }
}

void BodyLiteralInfoIndex::ensureThreadReady(const size_t threadIndex) {
    if (m_index.isInitialized()) {
        const uint8_t* bucket = m_index.getFirstBucket();
        while (bucket != m_index.getAfterLastBucket()) {
            BodyLiteralInfo* bodyLiteralInfo = const_cast<BodyLiteralInfo*>(m_index.getPolicy().getBodyLiteralInfo(bucket));
            if (bodyLiteralInfo != nullptr)
                bodyLiteralInfo->ensureThreadReady(threadIndex);
            bucket += m_index.getPolicy().BUCKET_SIZE;
        }
    }
}

BodyLiteralInfo* BodyLiteralInfoIndex::firstLiteralLocation(uint8_t* & location) {
    location = const_cast<uint8_t*>(m_index.getFirstBucket());
    while (location < m_index.getAfterLastBucket()) {
        BodyLiteralInfo* const bodyLiteralInfo = const_cast<BodyLiteralInfo*>(BodyLiteralInfoIndexPolicy::getBodyLiteralInfo(location));
        if (bodyLiteralInfo != nullptr)
            return bodyLiteralInfo;
        location += BodyLiteralInfoIndexPolicy::BUCKET_SIZE;
    }
    return nullptr;
}

BodyLiteralInfo*  BodyLiteralInfoIndex::nextLiteralLocation(uint8_t* & location) {
    location += BodyLiteralInfoIndexPolicy::BUCKET_SIZE;
    while (location < m_index.getAfterLastBucket()) {
        BodyLiteralInfo* const bodyLiteralInfo = const_cast<BodyLiteralInfo*>(BodyLiteralInfoIndexPolicy::getBodyLiteralInfo(location));
        if (bodyLiteralInfo != nullptr)
            return bodyLiteralInfo;
        location += BodyLiteralInfoIndexPolicy::BUCKET_SIZE;
    }
    return nullptr;
}

// SupportingFactsEvaluator

SupportingFactsEvaluator::SupportingFactsEvaluator(ResourceValueCache& resourceValueCache, const ArgumentIndexSet& headVariables, DataStore& dataStore, const std::vector<ResourceID>& defaultArgumentsBuffer, const Rule& rule, const std::vector<ArgumentIndexSet>& literalVariables, const std::vector<std::vector<ArgumentIndex> >& argumentIndexes, const TermArray& termArray, const TupleFilter* & positiveTupleFilter, const TupleFilter* & negativeTupleFilter) :
    m_resourceValueCache(resourceValueCache),
    m_argumentsBuffer(defaultArgumentsBuffer),
    m_tupleIterator(compileConjunction<ResourceValueCache>(headVariables, defaultArgumentsBuffer, rule->getBody(), literalVariables, argumentIndexes, dataStore, m_resourceValueCache, m_resourceValueCache, termArray, m_argumentsBuffer, positiveTupleFilter, negativeTupleFilter, nullptr))
{
}

SupportingFactsEvaluator::SupportingFactsEvaluator(const SupportingFactsEvaluator& other) :
    m_resourceValueCache(other.m_resourceValueCache),
    m_argumentsBuffer(other.m_argumentsBuffer),
    m_tupleIterator(other.m_tupleIterator->clone(CloneReplacements().registerReplacement(&other.m_resourceValueCache, &m_resourceValueCache).registerReplacement(&other.m_argumentsBuffer, &m_argumentsBuffer)))
{
}

SupportingFactsEvaluator::~SupportingFactsEvaluator() {
}

// RuleConstant

always_inline RuleConstant::RuleConstant(RuleInfo& forRule, const ResourceID resourceID, const EqualityManager& equalityManager, const EqualityManager& provingEqualityManager) :
    m_forRuleInfo(forRule),
    m_defaultID(resourceID),
    m_currentMainID(equalityManager.normalize(resourceID)),
    m_currentIncrementalID(provingEqualityManager.normalize(resourceID)),
    m_previous(nullptr),
    m_next(nullptr)
{
}

// HeadAtomInfo

void HeadAtomInfo::setComponentLevel(const size_t componentLevel) {
    m_componentLevel = componentLevel;
}

HeadAtomInfo::HeadAtomInfo(RuleInfo& ruleInfo, const size_t headAtomIndex, std::unordered_set<ResourceID>& ruleConstants, TermArray& termArraySupporting, const std::vector<ArgumentIndexSet>& literalVariablesSupporting, const std::vector<std::vector<ArgumentIndex> >& argumentIndexesSupporting) :
    ApplicationManager(ruleInfo.m_ruleIndex.m_termArray, ruleInfo.getRule()->getHead(headAtomIndex), nullptr),
    HeadAtomInfoPatternMain(ruleInfo.m_ruleIndex.m_defaultArgumentsBuffer, ruleInfo.m_ruleIndex.m_dataStore.getEqualityManager(), ruleInfo.m_ruleIndex.m_termArray, ruleInfo.getRule()->getHead(headAtomIndex)),
    m_ruleInfo(ruleInfo),
    m_headAtomIndex(headAtomIndex),
    m_componentLevel(0),
    m_headArgumentIndexes(),
    m_supportingFactsHeadArgumentIndexes(),
    m_supportingFactsLiterals(),
    m_supportingFactsCopyToBuffer(),
    m_supportingFactsEvaluatorPrototype(),
    m_supportingFactsEvaluators()
{
    EqualityManager& provingEqualityManager = m_ruleInfo.m_ruleIndex.m_provingEqualityManager;
    DataStore& dataStore = m_ruleInfo.m_ruleIndex.m_dataStore;
    RuleConstantIndex& ruleConstantIndex = m_ruleInfo.m_ruleIndex.m_ruleConstantIndex;

    // Some relevant *Body objects
    TermArray& termArrayBody = m_ruleInfo.m_ruleIndex.m_termArray;
    std::vector<ResourceID>& defaultArgumentsBufferBody = m_ruleInfo.m_ruleIndex.m_defaultArgumentsBuffer;

    // Index head atoms
    const std::vector<Term>& headAtomArguments = m_ruleInfo.getRule()->getHead(headAtomIndex)->getArguments();
    ArgumentIndexSet headVariablesSupporting;
    for (std::vector<Term>::const_iterator argumentIterator = headAtomArguments.begin(); argumentIterator != headAtomArguments.end(); ++argumentIterator) {
        const ArgumentIndex argumentIndexBody = termArrayBody.getPosition(*argumentIterator);
        const ArgumentIndex argumentIndexSupporting = termArraySupporting.getPosition(*argumentIterator);
        m_headArgumentIndexes.push_back(argumentIndexBody);
        m_supportingFactsHeadArgumentIndexes.push_back(argumentIndexSupporting);
        if ((*argumentIterator)->getType() == VARIABLE) {
            if (headVariablesSupporting.add(argumentIndexSupporting))
                m_supportingFactsCopyToBuffer.emplace_back(argumentIterator - headAtomArguments.begin(), argumentIndexSupporting);
        }
        else {
            const ResourceID constantID = defaultArgumentsBufferBody[termArrayBody.getPosition(*argumentIterator)];
            if (ruleConstants.insert(constantID).second) {
                m_ruleInfo.m_ruleConstants.push_back(std::unique_ptr<RuleConstant>(new RuleConstant(m_ruleInfo, constantID, dataStore.getEqualityManager(), provingEqualityManager)));
                ruleConstantIndex.addRuleConstant(*m_ruleInfo.m_ruleConstants.back());
            }
        }
    }

    // Compile the supporting facts evaluator
    m_supportingFactsEvaluatorPrototype.reset(new SupportingFactsEvaluator(m_ruleInfo.m_ruleIndex.m_byThreadInfos[0]->m_resourceValueCache, headVariablesSupporting, dataStore, m_ruleInfo.m_supportingFactsDefaultArgumentsBuffer, m_ruleInfo.getRule(), literalVariablesSupporting, argumentIndexesSupporting, termArraySupporting, m_ruleInfo.m_ruleIndex.m_byThreadInfos[0]->m_positiveSupportingFactsFilter, m_ruleInfo.m_ruleIndex.m_byThreadInfos[0]->m_negativeSupportingFactsFilter));
    dataStore.getEqualityManager().normalize(m_supportingFactsEvaluatorPrototype->m_argumentsBuffer, m_ruleInfo.m_supportingFactsConstantsIndexes);
    for (size_t atomIndex = 0; atomIndex < m_supportingFactsEvaluatorPrototype->getNumberOfBodyLiterals(); ++atomIndex) {
        TupleIndex dummyTupleIndex;
        TupleStatus dummyTupleStatus;
        m_supportingFactsLiterals.push_back(m_supportingFactsEvaluatorPrototype->getBodyLiteral(atomIndex).getCurrentTupleInfo(dummyTupleIndex, dummyTupleStatus));
    }

}

always_inline void HeadAtomInfo::normalizeConstantsMain(const EqualityManager& equalityManager) {
    std::vector<ResourceID>& supportingFactsDefaultArgumentsBuffer = m_ruleInfo.m_supportingFactsDefaultArgumentsBuffer;
    std::vector<ArgumentIndex>& supportingFactsConstantsIndexes = m_ruleInfo.m_supportingFactsConstantsIndexes;
    equalityManager.normalize(supportingFactsDefaultArgumentsBuffer, m_supportingFactsEvaluatorPrototype->m_argumentsBuffer, supportingFactsConstantsIndexes);
    for (auto iterator = m_supportingFactsEvaluators.begin(); iterator != m_supportingFactsEvaluators.end(); ++iterator)
        equalityManager.normalize(supportingFactsDefaultArgumentsBuffer, (*iterator)->m_argumentsBuffer, supportingFactsConstantsIndexes);
    HeadAtomInfoPatternMain::ensureNormalized(equalityManager);
}

// RuleInfo::EvaluationPlan

always_inline RuleInfo::EvaluationPlan::EvaluationPlan(PivotBodyLiteralInfo& pivotBodyLiteralInfo, BodyLiteralInfoPtr lastBodyLiteralInfo, size_t cost) :
    m_pivotBodyLiteralInfo(pivotBodyLiteralInfo),
    m_lastBodyLiteralInfo(lastBodyLiteralInfo),
    m_cost(cost)
{
}

// RuleInfo

void RuleInfo::compileForPivot(ArgumentIndexSet& boundArgumentsTemporary, const std::vector<ArgumentIndexSet>& literalVariables, const std::vector<std::vector<ArgumentIndex> >& argumentIndexes, const size_t pivotBodyIndex) {
    PivotBodyLiteralInfoPtr pivotBodyLiteralInfo = m_ruleIndex.m_bodyLiteralInfoIndex.getPivotBodyLiteralInfo(m_ruleIndex, literalVariables[pivotBodyIndex], argumentIndexes[pivotBodyIndex], m_rule->getBody(pivotBodyIndex));
    BodyLiteralInfoPtr lastBodyLiteralInfo(pivotBodyLiteralInfo);
    size_t atomsToMatch = m_rule->getNumberOfBodyLiterals();
    std::vector<bool> usedBodyLiterals(atomsToMatch, false);
    usedBodyLiterals[pivotBodyIndex] = true;
    --atomsToMatch;
    while (atomsToMatch != 0) {
        const size_t nextBodyIndex = getNextBodyLiteralIndex(lastBodyLiteralInfo->m_variablesBoundAfterLiteral, m_ruleIndex.m_dataStore, m_ruleIndex.m_defaultArgumentsBuffer, m_rule->getBody(), usedBodyLiterals, literalVariables, argumentIndexes);
        if (nextBodyIndex == static_cast<size_t>(-1)) {
            std::ostringstream message;
            message << "Cannot reorder atoms of the rule '" << m_rule->toString(Prefixes::s_defaultPrefixes) << "' to satisfy the binding requirements.";
            throw RDF_STORE_EXCEPTION(message.str());
        }
        lastBodyLiteralInfo = m_ruleIndex.m_bodyLiteralInfoIndex.getNonPivotBodyLiteralInfo(m_ruleIndex, literalVariables[nextBodyIndex], argumentIndexes[nextBodyIndex], m_rule->getBody(nextBodyIndex), lastBodyLiteralInfo.get(), nextBodyIndex < pivotBodyIndex ? BEFORE_PIVOT_ATOM : AFTER_PIVOT_ATOM);
        usedBodyLiterals[nextBodyIndex] = true;
        --atomsToMatch;
    }
    ArgumentIndexSet noBindings;
    const size_t planCost = getCountEstimate(noBindings, m_ruleIndex.m_dataStore, m_ruleIndex.m_defaultArgumentsBuffer, m_rule->getBody(pivotBodyIndex), literalVariables[pivotBodyIndex], argumentIndexes[pivotBodyIndex]);
    m_evaluationPlans.emplace_back(*pivotBodyLiteralInfo, lastBodyLiteralInfo, planCost);
}

always_inline void RuleInfo::ensureActive() {
    if (!m_active) {
        for (auto headAtomInfoIterator = m_headAtomInfos.begin(); headAtomInfoIterator != m_headAtomInfos.end(); ++headAtomInfoIterator) {
            HeadAtomInfo& headAtomInfo = **headAtomInfoIterator;
            for (auto plansIterator = m_evaluationPlans.begin(); plansIterator != m_evaluationPlans.end(); ++plansIterator)
                plansIterator->m_lastBodyLiteralInfo->addHeadAtomInfo(headAtomInfo);
            m_ruleIndex.m_headAtomInfoByPatternIndexMain.addObject(&headAtomInfo);
        }
        if (m_ruleIndex.m_dataStore.getEqualityAxiomatizationType() == EQUALITY_AXIOMATIZATION_OFF)
            m_ruleIndex.m_dependencyGraph.addRuleInfo(*this);
        m_active = true;
    }
}

always_inline void RuleInfo::ensureInactive() {
    if (m_active) {
        if (m_ruleIndex.m_dataStore.getEqualityAxiomatizationType() == EQUALITY_AXIOMATIZATION_OFF)
            m_ruleIndex.m_dependencyGraph.removeRuleInfo(*this);
        for (auto headAtomInfoIterator = m_headAtomInfos.begin(); headAtomInfoIterator != m_headAtomInfos.end(); ++headAtomInfoIterator) {
            HeadAtomInfo& headAtomInfo = **headAtomInfoIterator;
            m_ruleIndex.m_headAtomInfoByPatternIndexMain.removeObject(&headAtomInfo);
            for (auto iterator = m_evaluationPlans.begin(); iterator != m_evaluationPlans.end(); ++iterator)
                iterator->m_lastBodyLiteralInfo->removeHeadAtomInfo(headAtomInfo);
        }
        m_active = false;
    }
}

void RuleInfo::resizeComponentLevelFilter() {
    m_componentLevelFilter.reset(new uint8_t[m_ruleIndex.m_componentLevelFilterLength]);
    m_componentLevelFilter[0] = 1;
}

void RuleInfo::updateComponentLevelFilters() {
    ::memset(m_componentLevelFilter.get(), 0, m_ruleIndex.m_componentLevelFilterLength);
    for (auto iterator = m_headAtomInfos.begin(); iterator != m_headAtomInfos.end(); ++iterator) {
        const size_t componentLevel = (*iterator)->getComponentLevel();
        m_componentLevelFilter[componentLevel >> 3] |= static_cast<uint8_t>(1) << (componentLevel & 0x7);
        bool hasRecursiveLiterals = false;
        EvaluationPlan* bestNonrecursivePlan = nullptr;
        for (auto iterator = m_evaluationPlans.begin(); iterator != m_evaluationPlans.end(); ++iterator) {
            EvaluationPlan& evaluationPlan = *iterator;
            const bool pivotLiteralIsRecursive = (evaluationPlan.m_pivotBodyLiteralInfo.getComponentLevel() == componentLevel);
            if (pivotLiteralIsRecursive)
                hasRecursiveLiterals = true;
            else if (bestNonrecursivePlan == nullptr || evaluationPlan.m_cost < bestNonrecursivePlan->m_cost)
                bestNonrecursivePlan = &evaluationPlan;
            for (BodyLiteralInfo* bodyLiteralInfo = evaluationPlan.m_lastBodyLiteralInfo.get(); bodyLiteralInfo != nullptr; bodyLiteralInfo = bodyLiteralInfo->getParent()) {
                bodyLiteralInfo->addToComponentLevelFilter(ALL_IN_COMPONENT, componentLevel);
                if (pivotLiteralIsRecursive)
                    bodyLiteralInfo->addToComponentLevelFilter(WITH_PIVOT_IN_COMPONENT, componentLevel);
            }
        }
        if (!hasRecursiveLiterals && bestNonrecursivePlan != nullptr)
            for (BodyLiteralInfo* bodyLiteralInfo = bestNonrecursivePlan->m_lastBodyLiteralInfo.get(); bodyLiteralInfo != nullptr; bodyLiteralInfo = bodyLiteralInfo->getParent())
                bodyLiteralInfo->addToComponentLevelFilter(WITH_PIVOT_IN_COMPONENT, componentLevel);
    }
}

always_inline void RuleInfo::normalizeConstantsMain(const EqualityManager& equalityManager) {
    for (auto iterator = m_headAtomInfos.begin(); iterator != m_headAtomInfos.end(); ++iterator)
        (*iterator)->normalizeConstantsMain(equalityManager);
    for (auto iterator = m_evaluationPlans.begin(); iterator != m_evaluationPlans.end(); ++iterator)
        iterator->m_pivotBodyLiteralInfo.PivotBodyLiteralInfoPatternMain::ensureNormalized(equalityManager);
}

always_inline void RuleInfo::normalizeConstantsIncremental(const EqualityManager& equalityManager) {
    for (auto iterator = m_evaluationPlans.begin(); iterator != m_evaluationPlans.end(); ++iterator)
        iterator->m_pivotBodyLiteralInfo.PivotBodyLiteralInfoPatternIncremental::ensureNormalized(equalityManager);
}

RuleInfo::RuleInfo(RuleIndex& ruleIndex, const Rule& rule, const bool isInternalRule, const bool active, const bool justAdded, const bool justDeleted) :
    m_ruleIndex(ruleIndex),
    m_rule(rule),
    m_isInternalRule(isInternalRule),
    m_active(active),
    m_justAdded(justAdded),
    m_justDeleted(justDeleted),
    m_isWithoutPositivePivot(true),
    m_hasNegation(false),
    m_hasAggregation(false),
    m_componentLevelFilter(new uint8_t[m_ruleIndex.m_componentLevelFilterLength]),
    m_nextRuleInfo(nullptr),
    m_previousRuleInfo(nullptr),
    m_ruleConstants(),
    m_evaluationPlans(),
    m_headAtomInfos(),
    m_ruleEvaluatorsByThreadMain(),
    m_ruleEvaluatorsByThreadIncremental(),
    m_supportingFactsVariableIndexes(),
    m_supportingFactsConstantsIndexes(),
    m_supportingFactsDefaultArgumentsBuffer()
{
    // Finish the initialization of the object
    m_componentLevelFilter[0] = 1;

    // These are just for easier access
    EqualityManager& provingEqualityManager = m_ruleIndex.m_provingEqualityManager;
    DataStore& dataStore = m_ruleIndex.m_dataStore;
    RuleConstantIndex& ruleConstantIndex = m_ruleIndex.m_ruleConstantIndex;
    std::unordered_set<ResourceID> ruleConstants;
    const size_t numberOfHeadAtoms = m_rule->getNumberOfHeadAtoms();
    const std::vector<Literal>& bodyLiterals = m_rule->getBody();

    // Initialize *Body objects
    TermArray& termArrayBody = m_ruleIndex.m_termArray;
    std::vector<ResourceID>& defaultArgumentsBufferBody = m_ruleIndex.m_defaultArgumentsBuffer;
    std::vector<ArgumentIndexSet> literalVariablesBody;
    std::vector<std::vector<ArgumentIndex> > argumentIndexesBody;

    // Initialize *Supporting objects
    TermArray termArraySupporting(m_rule);
    for (ArgumentIndex argumentIndex = 0; static_cast<size_t>(argumentIndex) < termArraySupporting.getNumberOfTerms(); ++ argumentIndex) {
        const Term& term = termArraySupporting.getTerm(argumentIndex);
        const ResourceID resourceID = defaultArgumentsBufferBody[termArrayBody.getPosition(term)];
        m_supportingFactsDefaultArgumentsBuffer.push_back(resourceID);
        if (term->getType() == VARIABLE)
            m_supportingFactsVariableIndexes.push_back(std::make_pair(static_pointer_cast<Variable>(term), argumentIndex));
        else
            m_supportingFactsConstantsIndexes.push_back(argumentIndex);
    }
    std::vector<ArgumentIndexSet> literalVariablesSupporting;
    std::vector<std::vector<ArgumentIndex> > argumentIndexesSupporting;

    // Index body atoms
    for (auto bodyLiteralIterator = bodyLiterals.begin(); bodyLiteralIterator != bodyLiterals.end(); ++bodyLiteralIterator) {
        // Extend the *Body objects
        literalVariablesBody.emplace_back();
        argumentIndexesBody.emplace_back();
        // Extend the *Supporting objects
        literalVariablesSupporting.emplace_back();
        argumentIndexesSupporting.emplace_back();
        // Process the body literals
        const std::vector<Term>& bodyLiteralArguments = (*bodyLiteralIterator)->getArguments();
        for (auto argumentIterator = bodyLiteralArguments.begin(); argumentIterator != bodyLiteralArguments.end(); ++argumentIterator) {
            const ArgumentIndex argumentIndexBody = termArrayBody.getPosition(*argumentIterator);
            const ArgumentIndex argumentIndexSupporting = termArraySupporting.getPosition(*argumentIterator);
            argumentIndexesBody.back().push_back(argumentIndexBody);
            argumentIndexesSupporting.back().push_back(argumentIndexSupporting);
            if ((*argumentIterator)->getType() == VARIABLE) {
                literalVariablesBody.back().add(argumentIndexBody);
                literalVariablesSupporting.back().add(argumentIndexSupporting);
            }
            else {
                const ResourceID constantID = defaultArgumentsBufferBody[argumentIndexBody];
                if (ruleConstants.insert(constantID).second) {
                    m_ruleConstants.push_back(std::unique_ptr<RuleConstant>(new RuleConstant(*this, constantID, dataStore.getEqualityManager(), provingEqualityManager)));
                    ruleConstantIndex.addRuleConstant(*m_ruleConstants.back());
                }
            }
        }
    }

    // Index head atoms
    for (size_t headAtomIndex = 0; headAtomIndex < numberOfHeadAtoms; ++headAtomIndex)
        m_headAtomInfos.push_back(std::unique_ptr<HeadAtomInfo>(new HeadAtomInfo(*this, headAtomIndex, ruleConstants, termArraySupporting, literalVariablesSupporting, argumentIndexesSupporting)));

    // Compile body atoms
    ArgumentIndexSet boundArgumentsTemporary;
    for (std::vector<Literal>::const_iterator iterator = bodyLiterals.begin(); iterator != bodyLiterals.end(); ++iterator) {
        switch ((*iterator)->getType()) {
        case ATOM_FORMULA:
            compileForPivot(boundArgumentsTemporary, literalVariablesBody, argumentIndexesBody, iterator - bodyLiterals.begin());
            m_isWithoutPositivePivot = false;
            break;
        case ATOM_NEGATION_FORMULA:
            compileForPivot(boundArgumentsTemporary, literalVariablesBody, argumentIndexesBody, iterator - bodyLiterals.begin());
            m_hasNegation = true;
            break;
        case AGGREGATE_FORMULA:
            m_hasAggregation = true;
            break;
        default:
            break;
        }
    }

    // Compile the rule evaluators
    m_ruleEvaluatorsByThreadMain.push_back(compileConjunction<Dictionary>(ArgumentIndexSet(), defaultArgumentsBufferBody, m_rule->getBody(), literalVariablesBody, argumentIndexesBody, dataStore, m_ruleIndex.m_dataStore.getDictionary(), m_ruleIndex.m_byThreadInfos[0]->m_resourceValueCache, m_ruleIndex.m_termArray, m_ruleIndex.m_byThreadInfos[0]->m_argumentBufferMain, m_ruleIndex.m_byThreadInfos[0]->m_positiveRuleEvaluatorFilterMain, m_ruleIndex.m_byThreadInfos[0]->m_negativeRuleEvaluatorFilterMain, nullptr));
    CloneReplacements cloneReplacements;
    cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_argumentBufferMain, &m_ruleIndex.m_byThreadInfos[0]->m_argumentBufferIncremental);
    cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_positiveRuleEvaluatorFilterMain, &m_ruleIndex.m_byThreadInfos[0]->m_positiveRuleEvaluatorFilterIncremental);
    cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_negativeRuleEvaluatorFilterMain, &m_ruleIndex.m_byThreadInfos[0]->m_negativeRuleEvaluatorFilterIncremental);
    m_ruleEvaluatorsByThreadIncremental.push_back(m_ruleEvaluatorsByThreadMain[0]->clone(cloneReplacements));

    // Set the thread capacity
    setThreadCapacity(m_ruleIndex.getCurrentNumberOfThreads());

    // If m_active is true, we need to ensure that the rule is properly indexed. We do this using a mild hack
    // where we temporarily set if to false so that addToMain() correctly performs its work.
    if (m_active) {
        m_active = false;
        ensureActive();
    }
}

RuleInfo::~RuleInfo() {
    if (!m_ruleIndex.m_fastDestructors) {
        for (unique_ptr_vector<RuleConstant>::iterator iterator = m_ruleConstants.begin(); iterator != m_ruleConstants.end(); ++iterator)
            m_ruleIndex.m_ruleConstantIndex.removeRuleConstant(**iterator);
        ensureInactive();
    }
}

always_inline void RuleInfo::setThreadCapacity(const size_t numberOfThreads) {
    while (m_ruleEvaluatorsByThreadMain.size() < numberOfThreads)
        m_ruleEvaluatorsByThreadMain.push_back(nullptr);
    while (m_ruleEvaluatorsByThreadMain.size() > numberOfThreads)
        m_ruleEvaluatorsByThreadMain.erase(m_ruleEvaluatorsByThreadMain.end() - 1);
    while (m_ruleEvaluatorsByThreadIncremental.size() < numberOfThreads)
        m_ruleEvaluatorsByThreadIncremental.push_back(nullptr);
    while (m_ruleEvaluatorsByThreadIncremental.size() > numberOfThreads)
        m_ruleEvaluatorsByThreadIncremental.erase(m_ruleEvaluatorsByThreadIncremental.end() - 1);
}

always_inline void RuleInfo::ensureThreadReady(const size_t threadIndex) {
    if (m_ruleEvaluatorsByThreadMain[threadIndex].get() == nullptr) {
        CloneReplacements cloneReplacements;
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_resourceValueCache, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_resourceValueCache);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_argumentBufferMain, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_argumentBufferMain);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_positiveRuleEvaluatorFilterMain, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_positiveRuleEvaluatorFilterMain);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_negativeRuleEvaluatorFilterMain, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_negativeRuleEvaluatorFilterMain);
        m_ruleEvaluatorsByThreadMain[threadIndex] = m_ruleEvaluatorsByThreadMain[0]->clone(cloneReplacements);
    }
    if (m_ruleEvaluatorsByThreadIncremental[threadIndex].get() == nullptr) {
        CloneReplacements cloneReplacements;
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_resourceValueCache, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_resourceValueCache);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_argumentBufferIncremental, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_argumentBufferIncremental);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_positiveRuleEvaluatorFilterIncremental, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_positiveRuleEvaluatorFilterIncremental);
        cloneReplacements.registerReplacement(&m_ruleIndex.m_byThreadInfos[0]->m_negativeRuleEvaluatorFilterIncremental, &m_ruleIndex.m_byThreadInfos[threadIndex]->m_negativeRuleEvaluatorFilterIncremental);
        m_ruleEvaluatorsByThreadIncremental[threadIndex] = m_ruleEvaluatorsByThreadIncremental[0]->clone(cloneReplacements);
    }
}

// LiteralPatternIndex

template<class ObjectType, class PatternType>
always_inline LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndex(MemoryManager& memoryManager) : m_index(memoryManager, HASH_TABLE_LOAD_FACTOR) {
    for (size_t index = 0; index < 8; ++index)
        m_patternCounts[index] = 0;
}

template<class ObjectType, class PatternType>
always_inline void LiteralPatternIndex<ObjectType, PatternType>::initialize() {
    if (!m_index.initialize(HASH_TABLE_INITIAL_SIZE))
        throw RDF_STORE_EXCEPTION("Cannot initialize LiteralPatternIndex.");
    for (size_t index = 0; index < 8; ++index)
        m_patternCounts[index] = 0;
}

template<class ObjectType, class PatternType>
always_inline void LiteralPatternIndex<ObjectType, PatternType>::addObject(ObjectType* object) {
    if (!object->PatternType::m_inByPatternIndex) {
        ++m_patternCounts[object->PatternType::m_indexingPatternNumber];
        typename SequentialHashTable<LiteralPatternIndexPolicy>::BucketDescriptor bucketDescriptor;
        ThreadContext& threadContext = ThreadContext::getCurrentThreadContext();
        m_index.acquireBucket(threadContext, bucketDescriptor, object);
        if (m_index.continueBucketSearch(threadContext, bucketDescriptor, object) == BUCKET_EMPTY)
            m_index.acknowledgeInsert(threadContext, bucketDescriptor);
        else
            bucketDescriptor.m_bucketContents.m_object->PatternType::m_previousIndexed = object;
        object->PatternType::m_previousIndexed = nullptr;
        object->PatternType::m_nextIndexed = bucketDescriptor.m_bucketContents.m_object;
        m_index.getPolicy().setObject(bucketDescriptor.m_bucket, object);
        m_index.releaseBucket(threadContext, bucketDescriptor);
        object->PatternType::m_inByPatternIndex = true;
    }
}

template<class ObjectType, class PatternType>
always_inline void LiteralPatternIndex<ObjectType, PatternType>::removeObject(ObjectType* object) {
    if (object->PatternType::m_inByPatternIndex) {
        --m_patternCounts[object->PatternType::m_indexingPatternNumber];
        if (object->PatternType::m_nextIndexed != nullptr)
            object->PatternType::m_nextIndexed->PatternType::m_previousIndexed = object->PatternType::m_previousIndexed;
        if (object->PatternType::m_previousIndexed != nullptr)
            object->PatternType::m_previousIndexed->PatternType::m_nextIndexed = object->PatternType::m_nextIndexed;
        else {
            typename SequentialHashTable<LiteralPatternIndexPolicy>::BucketDescriptor bucketDescriptor;
            ThreadContext& threadContext = ThreadContext::getCurrentThreadContext();
            m_index.acquireBucket(threadContext, bucketDescriptor, object);
            m_index.continueBucketSearch(threadContext, bucketDescriptor, object);
            if (object->PatternType::m_nextIndexed != nullptr)
                m_index.getPolicy().setObject(bucketDescriptor.m_bucket, object->PatternType::m_nextIndexed);
            else
                m_index.deleteBucket(threadContext, bucketDescriptor);
            m_index.releaseBucket(threadContext, bucketDescriptor);
        }
        object->PatternType::m_previousIndexed = nullptr;
        object->PatternType::m_nextIndexed = nullptr;
        object->PatternType::m_inByPatternIndex = false;
    }
}

// PivotBodyLiteralInfoByPatternIndex

template<class PatternType>
PivotBodyLiteralInfoByPatternIndex<PatternType>::PivotBodyLiteralInfoByPatternIndex(MemoryManager& memoryManager) : LiteralPatternIndex<PivotBodyLiteralInfo, PatternType>(memoryManager) {
}

// HeadAtomInfoByPatternIndex

template<class PatternType>
HeadAtomInfoByPatternIndex<PatternType>::HeadAtomInfoByPatternIndex(MemoryManager& memoryManager) : LiteralPatternIndex<HeadAtomInfo, PatternType>(memoryManager) {
}

// RuleConstantIndex::Entry

always_inline RuleConstantIndex::Entry::Entry() : m_firstRuleConstant(nullptr) {
    // We deliberately do not initialize m_argumentsBufferIndex as that will be done in addConstant()
}

// RuleConstantIndex

always_inline RuleConstantIndex::RuleConstantIndex() : m_index() {
}

always_inline void RuleConstantIndex::initialize() {
    m_index.clear();
}

always_inline void RuleConstantIndex::newConstant(const ResourceID resourceID, const ArgumentIndex argumentsBufferIndex) {
    assert(m_index.find(resourceID) == m_index.end());
    m_index[resourceID].m_argumentsBufferIndex = argumentsBufferIndex;
}

always_inline bool RuleConstantIndex::getConstant(const ResourceID resourceID, ArgumentIndex& argumentsBufferIndex, RuleConstant* & firstRuleConstant) const {
    std::unordered_map<ResourceID, Entry>::const_iterator iterator = m_index.find(resourceID);
    if (iterator == m_index.end())
        return false;
    else {
        argumentsBufferIndex = iterator->second.m_argumentsBufferIndex;
        firstRuleConstant = iterator->second.m_firstRuleConstant;
        return true;
    }
}

always_inline void RuleConstantIndex::addRuleConstant(RuleConstant& ruleConstant) {
    assert(m_index.find(ruleConstant.m_defaultID) != m_index.end());
    Entry& entry = m_index[ruleConstant.m_defaultID];
    ruleConstant.m_previous = nullptr;
    ruleConstant.m_next = entry.m_firstRuleConstant;
    entry.m_firstRuleConstant = &ruleConstant;
}

always_inline void RuleConstantIndex::removeRuleConstant(RuleConstant& ruleConstant) {
    if (ruleConstant.m_previous != nullptr)
        ruleConstant.m_previous->m_next = ruleConstant.m_next;
    else {
        assert(m_index.find(ruleConstant.m_defaultID) != m_index.end());
        m_index[ruleConstant.m_defaultID].m_firstRuleConstant = ruleConstant.m_next;
    }
    if (ruleConstant.m_next != nullptr)
        ruleConstant.m_next->m_previous = ruleConstant.m_previous;
    ruleConstant.m_previous = ruleConstant.m_next = nullptr;
}

// RuleIndex::ByThreadInfo

always_inline RuleIndex::ByThreadInfo::ByThreadInfo(const Dictionary& dictionary, MemoryManager& memoryManager, const std::vector<ResourceID>& defaultArgumentsBuffer) :
    m_resourceValueCache(dictionary, memoryManager),
    m_argumentBufferMain(defaultArgumentsBuffer),
    m_argumentBufferIncremental(defaultArgumentsBuffer),
    m_positiveBodyLiteralFilterMain(nullptr),
    m_negativeBodyLiteralFilterMain(nullptr),
    m_positiveBodyLiteralFilterIncremental(nullptr),
    m_negativeBodyLiteralFilterIncremental(nullptr),
    m_positiveRuleEvaluatorFilterMain(nullptr),
    m_negativeRuleEvaluatorFilterMain(nullptr),
    m_positiveRuleEvaluatorFilterIncremental(nullptr),
    m_negativeRuleEvaluatorFilterIncremental(nullptr),
    m_positiveSupportingFactsFilter(nullptr),
    m_negativeSupportingFactsFilter(nullptr)
{
}

// RuleIndex

void RuleIndex::addRuleInfo(const Rule& rule, const bool isInternalRule, const bool inMain, const bool justAdded, const bool justDeleted) {
    ThreadContext& threadContext = ThreadContext::getCurrentThreadContext();
    m_termArray.visitFormula(rule);
    while (m_defaultArgumentsBuffer.size() < m_termArray.getNumberOfTerms()) {
        const ArgumentIndex argumentIndex = static_cast<ArgumentIndex>(m_defaultArgumentsBuffer.size());
        const Term& term = m_termArray.getTerm(argumentIndex);
        ResourceID resourceID;
        switch (term->getType()) {
        case RESOURCE_BY_ID:
            resourceID = to_reference_cast<ResourceByID>(term).getResourceID();
            break;
        case RESOURCE_BY_NAME:
            resourceID = m_dataStore.getDictionary().resolveResource(threadContext, nullptr, to_reference_cast<ResourceByName>(term).getResourceText());
            break;
        case VARIABLE:
        default:
            resourceID = INVALID_RESOURCE_ID;
            break;
        }
        if (term->getType() != VARIABLE)
            m_ruleConstantIndex.newConstant(resourceID, argumentIndex);
        const ResourceID normalizedMainResourceID = m_equalityManager.normalize(resourceID);
        const ResourceID normalizedIncrementalResourceID = m_provingEqualityManager.normalize(resourceID);
        for (auto iterator = m_byThreadInfos.begin(); iterator != m_byThreadInfos.end(); ++iterator) {
            assert((*iterator)->m_argumentBufferMain.size() == m_defaultArgumentsBuffer.size());
            assert((*iterator)->m_argumentBufferIncremental.size() == m_defaultArgumentsBuffer.size());
            (*iterator)->m_argumentBufferMain.push_back(normalizedMainResourceID);
            (*iterator)->m_argumentBufferIncremental.push_back(normalizedIncrementalResourceID);
        }
        m_defaultArgumentsBuffer.push_back(resourceID);
    }
    std::unique_ptr<RuleInfo>& ruleInfo = m_ruleInfosByRule[rule];
    ruleInfo.reset(new RuleInfo(*this, rule, isInternalRule, inMain, justAdded, justDeleted));
    if (m_lastRuleInfo == nullptr)
        m_firstRuleInfo = ruleInfo.get();
    else
        m_lastRuleInfo->m_nextRuleInfo = ruleInfo.get();
    ruleInfo->m_previousRuleInfo = m_lastRuleInfo;
    m_lastRuleInfo = ruleInfo.get();
    if (ruleInfo->getJustAdded())
        ++m_numberOfJustAddedRuleInfos;
    if (ruleInfo->getJustDeleted())
        ++m_numberOfJustDeletedRuleInfos;
    if (ruleInfo->m_isWithoutPositivePivot)
        ++m_numberOfPivotlessRules;
    if (ruleInfo->m_hasNegation)
        ++m_numberOfRulesWithNegation;
    if (ruleInfo->m_hasAggregation)
        ++m_numberOfRulesWithAggregation;
}

always_inline size_t RuleIndex::getCurrentNumberOfThreads() const {
    return m_byThreadInfos.size();
}

void RuleIndex::updateDependencyGraph() {
    if (m_dataStore.getEqualityAxiomatizationType() == EQUALITY_AXIOMATIZATION_OFF && m_dependencyGraph.updateComponents()) {
        const size_t maxComponentLevel = m_dependencyGraph.getMaxComponentLevel();
        const size_t requiredComponentLevelFilterLength = (maxComponentLevel / sizeof(uint8_t)) + 1;
        assert(requiredComponentLevelFilterLength != 0);
        uint8_t* literalLocation;
        if (requiredComponentLevelFilterLength < m_componentLevelFilterLength) {
            m_componentLevelFilterLength = requiredComponentLevelFilterLength;
            for (BodyLiteralInfo* bodyLiteralInfo = m_bodyLiteralInfoIndex.firstLiteralLocation(literalLocation); bodyLiteralInfo != nullptr; bodyLiteralInfo = m_bodyLiteralInfoIndex.nextLiteralLocation(literalLocation))
                bodyLiteralInfo->resizeComponentLevelFilters();
            RuleInfo* ruleInfo = m_firstRuleInfo;
            while (ruleInfo != nullptr) {
                ruleInfo->resizeComponentLevelFilter();
                ruleInfo = ruleInfo->m_nextRuleInfo;
            }
        }
        for (BodyLiteralInfo* bodyLiteralInfo = m_bodyLiteralInfoIndex.firstLiteralLocation(literalLocation); bodyLiteralInfo != nullptr; bodyLiteralInfo = m_bodyLiteralInfoIndex.nextLiteralLocation(literalLocation))
            bodyLiteralInfo->clearComponentLevelFilters();
        RuleInfo* ruleInfo = m_firstRuleInfo;
        while (ruleInfo != nullptr) {
            if (ruleInfo->m_active)
                ruleInfo->updateComponentLevelFilters();
            ruleInfo = ruleInfo->m_nextRuleInfo;
        }
    }
}

RuleIndex::RuleIndex(DataStore& dataStore) :
    m_dataStore(dataStore),
    m_equalityManager(m_dataStore.getEqualityManager()),
    m_provingEqualityManager(m_dataStore.getMemoryManager()),
    m_fastDestructors(false),
    m_termArray(),
    m_logicFactory(::newLogicFactory()),
    m_defaultArgumentsBuffer(),
    m_byThreadInfos(),
    m_dependencyGraph(m_termArray, m_dataStore.getMemoryManager()),
    m_componentLevelFilterLength(1),
    m_bodyLiteralInfoIndex(m_dataStore.getMemoryManager()),
    m_positivePivotBodyLiteralInfoByPatternIndexMain(m_dataStore.getMemoryManager()),
    m_negativePivotBodyLiteralInfoByPatternIndexMain(m_dataStore.getMemoryManager()),
    m_headAtomInfoByPatternIndexMain(m_dataStore.getMemoryManager()),
    m_positivePivotBodyLiteralInfoByPatternIndexIncremental(m_dataStore.getMemoryManager()),
    m_ruleConstantIndex(),
    m_ruleInfosByRule(),
    m_firstRuleInfo(nullptr),
    m_lastRuleInfo(nullptr),
    m_numberOfJustAddedRuleInfos(0),
    m_numberOfJustDeletedRuleInfos(0),
    m_numberOfPivotlessRules(0),
    m_numberOfRulesWithNegation(0),
    m_numberOfRulesWithAggregation(0)
{
}

RuleIndex::~RuleIndex() {
    m_fastDestructors = true;
}

void RuleIndex::initialize() {
    // The order of the following calls is the same as in the destructor of RuleIndex, which is critical for correct destruction.
    m_fastDestructors = true;
    m_firstRuleInfo = nullptr;
    m_lastRuleInfo = nullptr;
    m_numberOfJustAddedRuleInfos = 0;
    m_numberOfJustDeletedRuleInfos = 0;
    m_numberOfPivotlessRules = 0;
    m_numberOfRulesWithNegation = 0;
    m_numberOfRulesWithAggregation = 0;
    m_ruleInfosByRule.clear();
    m_ruleConstantIndex.initialize();
    m_bodyLiteralInfoIndex.initialize();
    m_positivePivotBodyLiteralInfoByPatternIndexIncremental.initialize();
    m_headAtomInfoByPatternIndexMain.initialize();
    m_positivePivotBodyLiteralInfoByPatternIndexMain.initialize();
    m_negativePivotBodyLiteralInfoByPatternIndexMain.initialize();
    if (m_dataStore.getEqualityAxiomatizationType() == EQUALITY_AXIOMATIZATION_OFF)
        m_dependencyGraph.initialize();
    m_componentLevelFilterLength = 1;
    for (auto iterator = m_byThreadInfos.begin(); iterator != m_byThreadInfos.end(); ++iterator) {
        (*iterator)->m_resourceValueCache.clear();
        (*iterator)->m_argumentBufferMain.clear();
        (*iterator)->m_argumentBufferIncremental.clear();
    }
    m_defaultArgumentsBuffer.clear();
    m_termArray.clear();
    if (!m_provingEqualityManager.initialize())
        throw RDF_STORE_EXCEPTION("Cannot initialize proving equality manager.");
    m_fastDestructors = false;
}

const RuleInfo* RuleIndex::getRuleInfoFor(const Rule& rule) const {
    const Rule ownRule = rule->clone(m_logicFactory);
    std::unordered_map<Rule, std::unique_ptr<RuleInfo> >::const_iterator iterator = m_ruleInfosByRule.find(ownRule);
    if (iterator == m_ruleInfosByRule.end())
        return nullptr;
    else
        return iterator->second.get();
}

void RuleIndex::forgetTemporaryConstants() {
    for (auto iterator = m_byThreadInfos.begin(); iterator != m_byThreadInfos.end(); ++iterator)
        (*iterator)->m_resourceValueCache.clear();
}

void RuleIndex::resetProving() {
    if (!m_provingEqualityManager.initialize())
        throw RDF_STORE_EXCEPTION("Cannot initialize proving equality manager.");
    ensureConstantsAreNormalizedIncremental();
}

void RuleIndex::setThreadCapacity(const size_t numberOfThreads) {
    while (m_byThreadInfos.size() < numberOfThreads)
        m_byThreadInfos.push_back(std::unique_ptr<ByThreadInfo>(new ByThreadInfo(m_dataStore.getDictionary(), m_dataStore.getMemoryManager(), m_defaultArgumentsBuffer)));
    while (m_byThreadInfos.size() > numberOfThreads)
        m_byThreadInfos.erase(m_byThreadInfos.end() - 1);
    m_bodyLiteralInfoIndex.setThreadCapacity(numberOfThreads);
    RuleInfo* ruleInfo = m_firstRuleInfo;
    while (ruleInfo != nullptr) {
        ruleInfo->setThreadCapacity(numberOfThreads);
        ruleInfo = ruleInfo->m_nextRuleInfo;
    }
}

void RuleIndex::ensureThreadReady(const size_t threadIndex) {
    m_bodyLiteralInfoIndex.ensureThreadReady(threadIndex);
    RuleInfo* ruleInfo = m_firstRuleInfo;
    while (ruleInfo != nullptr) {
        ruleInfo->ensureThreadReady(threadIndex);
        ruleInfo = ruleInfo->m_nextRuleInfo;
    }
}

bool RuleIndex::addRule(const size_t currentNumberOfThreads, const Rule& rule, const bool isInternalRule) {
    const Rule ownRule = rule->clone(m_logicFactory);
    std::unordered_map<Rule, std::unique_ptr<RuleInfo> >::iterator iterator = m_ruleInfosByRule.find(ownRule);
    if (iterator != m_ruleInfosByRule.end()) {
        if (iterator->second->getJustAdded())
            return false;
        iterator->second->m_justAdded = true;
        ++m_numberOfJustAddedRuleInfos;
    }
    else
        addRuleInfo(ownRule, isInternalRule, false, true, false);
    return true;
}

bool RuleIndex::removeRule(const Rule& rule) {
    Rule ownRule = rule->clone(m_logicFactory);
    std::unordered_map<Rule, std::unique_ptr<RuleInfo> >::iterator iterator = m_ruleInfosByRule.find(ownRule);
    if (iterator != m_ruleInfosByRule.end() && iterator->second->getActive() && !iterator->second->getJustDeleted()) {
        iterator->second->m_justDeleted = true;
        ++m_numberOfJustDeletedRuleInfos;
        return true;
    }
    else
        return false;
}

void RuleIndex::propagateDeletions() {
    if (m_numberOfJustDeletedRuleInfos > 0) {
        RuleInfo* ruleInfo = m_firstRuleInfo;
        while (ruleInfo != nullptr) {
            RuleInfo* nextRuleInfo = ruleInfo->m_nextRuleInfo;
            if (ruleInfo->getJustDeleted()) {
                ruleInfo->ensureInactive();
                ruleInfo->m_justDeleted = false;
                --m_numberOfJustDeletedRuleInfos;
                if (!ruleInfo->getJustAdded()) {
                    if (ruleInfo->m_previousRuleInfo == nullptr)
                        m_firstRuleInfo = ruleInfo->m_nextRuleInfo;
                    else
                        ruleInfo->m_previousRuleInfo->m_nextRuleInfo = ruleInfo->m_nextRuleInfo;
                    if (ruleInfo->m_nextRuleInfo == nullptr)
                        m_lastRuleInfo = ruleInfo->m_previousRuleInfo;
                    else
                        ruleInfo->m_nextRuleInfo->m_previousRuleInfo = ruleInfo->m_previousRuleInfo;
                    if (ruleInfo->m_isWithoutPositivePivot)
                        --m_numberOfPivotlessRules;
                    if (ruleInfo->m_hasNegation)
                        --m_numberOfRulesWithNegation;
                    if (ruleInfo->m_hasAggregation)
                        --m_numberOfRulesWithAggregation;
                    m_ruleInfosByRule.erase(m_ruleInfosByRule.find(ruleInfo->getRule()));
                }
            }
            ruleInfo = nextRuleInfo;
        }
        assert(m_numberOfJustDeletedRuleInfos == 0);
    }
}

void RuleIndex::propagateInsertions() {
    if (m_numberOfJustAddedRuleInfos > 0) {
        RuleInfo* ruleInfo = m_firstRuleInfo;
        while (ruleInfo != nullptr) {
            if (ruleInfo->getJustAdded()) {
                ruleInfo->ensureActive();
                ruleInfo->m_justAdded = false;
                --m_numberOfJustAddedRuleInfos;
            }
            ruleInfo = ruleInfo->m_nextRuleInfo;
        }
        assert(m_numberOfJustAddedRuleInfos == 0);
    }
    updateDependencyGraph();
}

void RuleIndex::enqueueDeletedRules(LockFreeQueue<RuleInfo*>& ruleQueue) {
    if (m_numberOfJustDeletedRuleInfos > 0) {
        RuleInfo* ruleInfo = m_firstRuleInfo;
        while (ruleInfo != nullptr) {
            if (ruleInfo->getActive() && ruleInfo->getJustDeleted())
                ruleQueue.enqueue<false>(ruleInfo);
            ruleInfo = ruleInfo->m_nextRuleInfo;
        }
    }
}

void RuleIndex::enqueueInsertedRules(LockFreeQueue<RuleInfo*>& ruleQueue) {
    if (m_numberOfJustAddedRuleInfos > 0) {
        RuleInfo* ruleInfo = m_firstRuleInfo;
        while (ruleInfo != nullptr) {
            if (!ruleInfo->getActive() && ruleInfo->getJustAdded())
                ruleQueue.enqueue<false>(ruleInfo);
            ruleInfo = ruleInfo->m_nextRuleInfo;
        }
    }
}

template<bool checkComponentLevel>
void RuleIndex::enqueueRulesWithoutPositivePivot(const size_t componentLevel, LockFreeQueue<RuleInfo*>& ruleQueue) {
    if (m_numberOfPivotlessRules > 0) {
        RuleInfo* ruleInfo = m_firstRuleInfo;
        while (ruleInfo != nullptr) {
            if (ruleInfo->getActive() && ruleInfo->m_isWithoutPositivePivot && (!checkComponentLevel || ruleInfo->isInComponentLevelFilter(componentLevel)))
                ruleQueue.enqueue<false>(ruleInfo);
            ruleInfo = ruleInfo->m_nextRuleInfo;
        }
    }
}

bool RuleIndex::ensureConstantsAreNormalizedMain() {
    bool hasChange = false;
    std::vector<ResourceID>& argumentsBufferForFirstThreadMain = m_byThreadInfos[0]->m_argumentBufferMain;
    const size_t numberOfTerms = argumentsBufferForFirstThreadMain.size();
    for (size_t index = 0; index < numberOfTerms; ++index) {
        const ResourceID originalID = m_defaultArgumentsBuffer[index];
        if (originalID != INVALID_RESOURCE_ID) {
            const ResourceID normalizedID = m_equalityManager.normalize(originalID);
            if (argumentsBufferForFirstThreadMain[index] != normalizedID) {
                for (auto iterator = m_byThreadInfos.begin(); iterator != m_byThreadInfos.end(); ++iterator)
                    (*iterator)->m_argumentBufferMain[index] = normalizedID;
                hasChange = true;
            }
        }
    }
    if (hasChange) {
        RuleInfo* ruleInfo = m_firstRuleInfo;
        while (ruleInfo != nullptr) {
            unique_ptr_vector<RuleConstant>& ruleConstants = ruleInfo->m_ruleConstants;
            bool hasChange = false;
            for (unique_ptr_vector<RuleConstant>::iterator iterator = ruleConstants.begin(); iterator != ruleConstants.end(); ++iterator) {
                const ResourceID normalizedID = m_equalityManager.normalize((*iterator)->m_defaultID);
                if (normalizedID != (*iterator)->m_currentMainID) {
                    (*iterator)->m_currentMainID = normalizedID;
                    hasChange = true;
                }
            }
            if (hasChange)
                ruleInfo->normalizeConstantsMain(m_equalityManager);
            ruleInfo = ruleInfo->m_nextRuleInfo;
        }
    }
    return hasChange;
}

template<bool checkComponentLevel>
void RuleIndex::enqueueRulesToReevaluateMain(const ResourceID mergedID, const size_t componentLevel, LockFreeQueue<RuleInfo*>& ruleQueue) {
    const ResourceID normalizedID = m_equalityManager.normalize(mergedID);
    for (ResourceID resourceID = mergedID; resourceID != INVALID_RESOURCE_ID; resourceID = m_equalityManager.getNextEqual(resourceID)) {
        ArgumentIndex argumentsBufferIndex;
        RuleConstant* ruleConstant;
        if (m_ruleConstantIndex.getConstant(resourceID, argumentsBufferIndex, ruleConstant)) {
            for (auto iterator = m_byThreadInfos.begin(); iterator != m_byThreadInfos.end(); ++iterator)
                (*iterator)->m_argumentBufferMain[argumentsBufferIndex] = normalizedID;
            while (ruleConstant != nullptr) {
                ruleConstant->m_currentMainID = normalizedID;
                RuleInfo& ruleInfo = ruleConstant->m_forRuleInfo;
                if (ruleInfo.getActive()) {
                    if (!checkComponentLevel || ruleInfo.isInComponentLevelFilter(componentLevel))
                        ruleQueue.enqueue<false>(&ruleInfo);
                    ruleInfo.normalizeConstantsMain(m_equalityManager);
                }
                ruleConstant = ruleConstant->m_next;
            }
        }
    }
}

bool RuleIndex::ensureConstantsAreNormalizedIncremental() {
    bool hasChange = false;
    std::vector<ResourceID>& argumentsBufferForFirstThreadIncremental = m_byThreadInfos[0]->m_argumentBufferIncremental;
    const size_t numberOfTerms = argumentsBufferForFirstThreadIncremental.size();
    for (size_t index = 0; index < numberOfTerms; ++index) {
        const ResourceID originalID = m_defaultArgumentsBuffer[index];
        if (originalID != INVALID_RESOURCE_ID) {
            const ResourceID normalizedID = m_provingEqualityManager.normalize(originalID);
            if (argumentsBufferForFirstThreadIncremental[index] != normalizedID) {
                for (auto iterator = m_byThreadInfos.begin(); iterator != m_byThreadInfos.end(); ++iterator)
                    (*iterator)->m_argumentBufferIncremental[index] = normalizedID;
                hasChange = true;
            }
        }
    }
    if (hasChange) {
        RuleInfo* ruleInfo = m_firstRuleInfo;
        while (ruleInfo != nullptr) {
            unique_ptr_vector<RuleConstant>& ruleConstants = ruleInfo->m_ruleConstants;
            bool hasChange = false;
            for (unique_ptr_vector<RuleConstant>::iterator iterator = ruleConstants.begin(); iterator != ruleConstants.end(); ++iterator) {
                const ResourceID normalizedID = m_provingEqualityManager.normalize((*iterator)->m_defaultID);
                if (normalizedID != (*iterator)->m_currentIncrementalID) {
                    (*iterator)->m_currentIncrementalID = normalizedID;
                    hasChange = true;
                }
            }
            if (hasChange)
                ruleInfo->normalizeConstantsMain(m_provingEqualityManager);
            ruleInfo = ruleInfo->m_nextRuleInfo;
        }
    }
    return hasChange;
}

template<bool checkComponentLevel>
void RuleIndex::enqueueRulesToReevaluateIncremental(const ResourceID mergedID, const size_t componentLevel, LockFreeQueue<RuleInfo*>& ruleQueue) {
    const ResourceID normalizedID = m_provingEqualityManager.normalize(mergedID);
    for (ResourceID resourceID = mergedID; resourceID != INVALID_RESOURCE_ID; resourceID = m_provingEqualityManager.getNextEqual(resourceID)) {
        ArgumentIndex argumentsBufferIndex;
        RuleConstant* ruleConstant;
        if (m_ruleConstantIndex.getConstant(resourceID, argumentsBufferIndex, ruleConstant)) {
            for (auto iterator = m_byThreadInfos.begin(); iterator != m_byThreadInfos.end(); ++iterator)
                (*iterator)->m_argumentBufferIncremental[argumentsBufferIndex] = normalizedID;
            while (ruleConstant != nullptr) {
                ruleConstant->m_currentIncrementalID = normalizedID;
                RuleInfo& ruleInfo = ruleConstant->m_forRuleInfo;
                if (ruleInfo.getActive()) {
                    if (!checkComponentLevel || ruleInfo.isInComponentLevelFilter(componentLevel))
                        ruleQueue.enqueue<false>(&ruleInfo);
                    ruleInfo.normalizeConstantsIncremental(m_provingEqualityManager);
                }
                ruleConstant = ruleConstant->m_next;
            }
        }
    }
}

void RuleIndex::getRules(DatalogProgram& datalogProgram, LogicFactory& logicFactory) const {
    RuleInfo* ruleInfo = m_firstRuleInfo;
    while (ruleInfo != nullptr) {
        if (!ruleInfo->isInternalRule() && !ruleInfo->getJustAdded() && !ruleInfo->getJustDeleted())
            datalogProgram.push_back(ruleInfo->getRule()->clone(logicFactory));
        ruleInfo = ruleInfo->m_nextRuleInfo;
    }
}

void RuleIndex::getRulePlan(std::ostream& output, Prefixes& prefixes) {
    RuleInfo* ruleInfo = m_firstRuleInfo;
    std::vector<BodyLiteralInfo*> rulePlan;
    while (ruleInfo != nullptr) {
        output << ruleInfo->getRule()->toString(prefixes);
        bool hasAnnotation = false;
        if (ruleInfo->isInternalRule()) {
            if (!hasAnnotation) {
                hasAnnotation = true;
            }
            else
                output << ", ";
            output << "INTERNAL";
        }
        if (ruleInfo->getJustAdded()) {
            if (!hasAnnotation) {
                output << "    [";
                hasAnnotation = true;
            }
            else
                output << ", ";
            output << "ADDED";
        }
        if (ruleInfo->getJustDeleted()) {
            if (!hasAnnotation) {
                output << "    [";
                hasAnnotation = true;
            }
            else
                output << ", ";
            output << "DELETED";
        }
        if (hasAnnotation)
            output << "]";
        output << std::endl;
        for (size_t headAtomIndex = 0; headAtomIndex < ruleInfo->getNumberOfHeadAtoms(); ++headAtomIndex) {
            HeadAtomInfo& headAtomInfo = ruleInfo->getHeadAtomInfo(headAtomIndex);
            output << "      + " << headAtomInfo.getAtom()->toString(prefixes) << '@' << headAtomInfo.getComponentLevel() << std::endl;
        }
        const std::vector<RuleInfo::EvaluationPlan>& evaluationPlans = ruleInfo->m_evaluationPlans;
        for (auto iterator = evaluationPlans.begin(); iterator != evaluationPlans.end(); ++iterator) {
            BodyLiteralInfo* bodyLiteralInfo = iterator->m_lastBodyLiteralInfo.get();
            while (bodyLiteralInfo != nullptr) {
                rulePlan.push_back(bodyLiteralInfo);
                bodyLiteralInfo = bodyLiteralInfo->getParent();
            }
            output << "    - ";
            bool first = true;
            for (std::vector<BodyLiteralInfo*>::reverse_iterator iterator = rulePlan.rbegin(); iterator != rulePlan.rend(); ++iterator) {
                if (first)
                    first = false;
                else
                    output << ", ";
                output << (*iterator)->getLiteral()->toString(prefixes);
                switch ((*iterator)->getLiteralPosition()) {
                case BEFORE_PIVOT_ATOM:
                    output << "^<";
                    break;
                case PIVOT_ATOM:
                    break;
                case AFTER_PIVOT_ATOM:
                    output << "^<=";
                    break;
                }
                output << '@' << (*iterator)->getComponentLevel();
            }
            output << " ." << std::endl;
            rulePlan.clear();
        }
        output << std::endl;
        ruleInfo = ruleInfo->m_nextRuleInfo;
    }
}

void RuleIndex::recompileRules() {
    struct RuleStorage : private Unmovable {
        Rule m_rule;
        bool m_isInternalRule;
        bool m_active;
        bool m_justAdded;
        bool m_justDeleted;

        RuleStorage(const RuleInfo* const ruleInfo) : m_rule(ruleInfo->getRule()), m_isInternalRule(ruleInfo->isInternalRule()), m_active(ruleInfo->getActive()), m_justAdded(ruleInfo->getJustAdded()), m_justDeleted(ruleInfo->getJustDeleted()) {
        }
    };

    unique_ptr_vector<RuleStorage> ruleStorage;
    RuleInfo* ruleInfo = m_firstRuleInfo;
    while (ruleInfo != nullptr) {
        ruleStorage.push_back(std::unique_ptr<RuleStorage>(new RuleStorage(ruleInfo)));
        ruleInfo = ruleInfo->m_nextRuleInfo;
    }
    initialize();
    for (unique_ptr_vector<RuleStorage>::iterator iterator = ruleStorage.begin(); iterator != ruleStorage.end(); ++iterator)
        addRuleInfo((*iterator)->m_rule, (*iterator)->m_isInternalRule, (*iterator)->m_active, (*iterator)->m_justAdded, (*iterator)->m_justDeleted);
}

void RuleIndex::save(OutputStream& outputStream) const {
    outputStream.writeString("RuleIndex");
    outputStream.write(m_ruleInfosByRule.size());
    RuleInfo* ruleInfo = m_firstRuleInfo;
    while (ruleInfo != nullptr) {
        outputStream.writeString(ruleInfo->getRule()->toString(Prefixes::s_emptyPrefixes));
        outputStream.write(ruleInfo->isInternalRule());
        outputStream.write(ruleInfo->getActive());
        outputStream.write(ruleInfo->getJustAdded());
        outputStream.write(ruleInfo->getJustDeleted());
        ruleInfo = ruleInfo->m_nextRuleInfo;
    }
}

void RuleIndex::load(InputStream& inputStream) {
    initialize();
    if (!inputStream.checkNextString("RuleIndex"))
        throw RDF_STORE_EXCEPTION("Invalid input file: cannot load RuleIndex.");
    const size_t numberOfRules = inputStream.read<size_t>();
    Prefixes prefixes;
    DatalogParser parser(prefixes);
    DatalogProgram datalogProgram;
    std::vector<Atom> facts;
    DatalogProgramInputImporter datalogProgramInputImporter(m_logicFactory, datalogProgram, facts, nullptr);
    std::string ruleText;
    for (size_t index = 0; index < numberOfRules; ++index) {
        inputStream.readString(ruleText, 1000000);
        const bool isInternalRule = inputStream.read<bool>();
        const bool inMain = inputStream.read<bool>();
        const bool justAdded = inputStream.read<bool>();
        const bool justDeleted = inputStream.read<bool>();
        datalogProgram.clear();
        MemorySource memorySource(ruleText.c_str(), ruleText.length());
        parser.bind(memorySource);
        parser.parse(m_logicFactory, datalogProgramInputImporter);
        parser.unbind();
        assert(datalogProgram.size() == 1);
        addRuleInfo(datalogProgram[0], isInternalRule, inMain, justAdded, justDeleted);
    }
    updateDependencyGraph();
}

template void RuleIndex::enqueueRulesWithoutPositivePivot<true>(const size_t, LockFreeQueue<RuleInfo*>&);
template void RuleIndex::enqueueRulesWithoutPositivePivot<false>(const size_t, LockFreeQueue<RuleInfo*>&);
template void RuleIndex::enqueueRulesToReevaluateMain<true>(const ResourceID, const size_t, LockFreeQueue<RuleInfo*>&);
template void RuleIndex::enqueueRulesToReevaluateMain<false>(const ResourceID, const size_t, LockFreeQueue<RuleInfo*>&);
template void RuleIndex::enqueueRulesToReevaluateIncremental<false>(const ResourceID, const size_t, LockFreeQueue<RuleInfo*>&);
template void RuleIndex::enqueueRulesToReevaluateIncremental<true>(const ResourceID, const size_t, LockFreeQueue<RuleInfo*>&);
