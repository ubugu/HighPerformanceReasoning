// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifndef RULEINDEXIMPL_H_
#define RULEINDEXIMPL_H_

#include "../dictionary/ResourceValueCache.h"
#include "../storage/DataStore.h"
#include "../util/SequentialHashTableImpl.h"
#include "MaterializationMonitor.h"
#include "RuleIndex.h"

// BodyLiteralInfoFilters

template<class T, BodyLiteralInfoFilter<T> positiveBodyLiteralInfoFilter, BodyLiteralInfoFilter<T> negativeBodyLiteralInfoFilter, bool isMain>
always_inline BodyLiteralInfoFilters<T, positiveBodyLiteralInfoFilter, negativeBodyLiteralInfoFilter, isMain>::BodyLiteralInfoFilters(RuleIndex& ruleIndex, T& target) :
    m_ruleIndex(ruleIndex),
    m_positiveTupleFilter(target),
    m_negativeTupleFilter(target)
{
    RuleIndex::ByThreadInfo& byTreadInfo = *m_ruleIndex.m_byThreadInfos[target.getWorkerIndex()];
    if (isMain) {
        byTreadInfo.m_positiveBodyLiteralFilterMain = &m_positiveTupleFilter;
        byTreadInfo.m_negativeBodyLiteralFilterMain = &m_negativeTupleFilter;
    }
    else {
        byTreadInfo.m_positiveBodyLiteralFilterIncremental = &m_positiveTupleFilter;
        byTreadInfo.m_negativeBodyLiteralFilterIncremental = &m_negativeTupleFilter;
    }
}

template<class T, BodyLiteralInfoFilter<T> positiveBodyLiteralInfoFilter, BodyLiteralInfoFilter<T> negativeBodyLiteralInfoFilter, bool isMain>
always_inline BodyLiteralInfoFilters<T, positiveBodyLiteralInfoFilter, negativeBodyLiteralInfoFilter, isMain>::~BodyLiteralInfoFilters() {
    RuleIndex::ByThreadInfo& byTreadInfo = *m_ruleIndex.m_byThreadInfos[m_positiveTupleFilter.m_target.getWorkerIndex()];
    if (isMain)
        byTreadInfo.m_positiveBodyLiteralFilterMain = byTreadInfo.m_negativeBodyLiteralFilterMain = nullptr;
    else
        byTreadInfo.m_positiveBodyLiteralFilterIncremental = byTreadInfo.m_negativeBodyLiteralFilterIncremental = nullptr;
}

// BodyTupleIteratorFilters

template<class T, BodyTupleIteratorFilter<T> positiveBodyTupleIteratorFilter, BodyTupleIteratorFilter<T> negativeBodyTupleIteratorFilter, BodyTupleIteratorFilterType type>
always_inline BodyTupleIteratorFilters<T, positiveBodyTupleIteratorFilter, negativeBodyTupleIteratorFilter, type>::BodyTupleIteratorFilters(RuleIndex& ruleIndex, T& target) :
    m_ruleIndex(ruleIndex),
    m_positiveTupleFilter(target),
    m_negativeTupleFilter(target)
{
    RuleIndex::ByThreadInfo& byTreadInfo = *m_ruleIndex.m_byThreadInfos[target.getWorkerIndex()];
    switch (type) {
    case BODY_TUPLE_ITERATOR_FILTER_MAIN:
        byTreadInfo.m_positiveRuleEvaluatorFilterMain = &m_positiveTupleFilter;
        byTreadInfo.m_negativeRuleEvaluatorFilterMain = &m_negativeTupleFilter;
        break;
    case BODY_TUPLE_ITERATOR_FILTER_INCREMENTAL:
        byTreadInfo.m_positiveRuleEvaluatorFilterIncremental = &m_positiveTupleFilter;
        byTreadInfo.m_negativeRuleEvaluatorFilterIncremental = &m_negativeTupleFilter;
        break;
    case BODY_TUPLE_ITERATOR_FILTER_SUPPORTING_FACTS:
        byTreadInfo.m_positiveSupportingFactsFilter = &m_positiveTupleFilter;
        byTreadInfo.m_negativeSupportingFactsFilter = &m_negativeTupleFilter;
        break;
    }
}

template<class T, BodyTupleIteratorFilter<T> positiveBodyTupleIteratorFilter, BodyTupleIteratorFilter<T> negativeBodyTupleIteratorFilter, BodyTupleIteratorFilterType type>
always_inline BodyTupleIteratorFilters<T, positiveBodyTupleIteratorFilter, negativeBodyTupleIteratorFilter, type>::~BodyTupleIteratorFilters() {
    RuleIndex::ByThreadInfo& byTreadInfo = *m_ruleIndex.m_byThreadInfos[m_positiveTupleFilter.m_target.getWorkerIndex()];
    switch (type) {
    case BODY_TUPLE_ITERATOR_FILTER_MAIN:
        byTreadInfo.m_positiveRuleEvaluatorFilterMain = byTreadInfo.m_negativeRuleEvaluatorFilterMain = nullptr;
        break;
    case BODY_TUPLE_ITERATOR_FILTER_INCREMENTAL:
        byTreadInfo.m_positiveRuleEvaluatorFilterIncremental = byTreadInfo.m_negativeRuleEvaluatorFilterIncremental = nullptr;
        break;
    case BODY_TUPLE_ITERATOR_FILTER_SUPPORTING_FACTS:
        byTreadInfo.m_positiveSupportingFactsFilter = byTreadInfo.m_negativeSupportingFactsFilter = nullptr;
        break;
    }
}

// ApplicationManager

always_inline bool ApplicationManager::satisfiesEqualities(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    if (!m_compareVariables.empty()) {
        for (std::vector<CompareVariables>::iterator iterator = m_compareVariables.begin(); iterator != m_compareVariables.end(); ++iterator)
            if (argumentsBuffer[argumentIndexes[iterator->m_index1]] != argumentsBuffer[argumentIndexes[iterator->m_index2]])
                return false;
    }
    return true;
}

always_inline bool ApplicationManager::prepareApply(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, std::vector<ResourceID>& targetArgumentsBuffer) {
    if (satisfiesEqualities(argumentsBuffer, argumentIndexes)) {
        for (std::vector<ArgumentToBuffer>::iterator iterator = m_copyToBuffer.begin(); iterator != m_copyToBuffer.end(); ++iterator)
            targetArgumentsBuffer[iterator->m_targetIndex] = argumentsBuffer[argumentIndexes[iterator->m_sourceIndex]];
        return true;
    }
    else
        return false;
}

// BodyLiteralInfo

template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
void BodyLiteralInfo::literalMatched(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) {
    if (callMonitor)
        materializationMonitor->bodyLiteralMatchedStarted(target.getWorkerIndex(), *this);
    for (std::vector<HeadAtomInfo*>::iterator iterator = m_lastLiteralForHeadAtoms.begin(); iterator != m_lastLiteralForHeadAtoms.end(); ++iterator)
        if (componentLevelFilter == ALL_COMPONENTS || (*iterator)->getComponentLevel() == componentLevel)
            (*iterator)->headAtomMatched<isMain, T, headAtomConsumer, callMonitor>(threadContext, target, this, materializationMonitor);
    NonPivotBodyLiteralInfo* currentChild = m_firstChild;
    while (currentChild != nullptr) {
        currentChild->matchLiteral<isMain, T, headAtomConsumer, componentLevelFilter, callMonitor>(threadContext, target, componentLevel, materializationMonitor);
        currentChild = currentChild->m_nextSibling;
    }
    if (callMonitor)
        materializationMonitor->bodyLiteralMatchedFinish(target.getWorkerIndex());
}

// PivotBodyLiteralInfo

template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
always_inline void PivotBodyLiteralInfo::applyTo(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) {
    if (isInComponentLevelFilter<componentLevelFilter>(componentLevel)) {
        std::vector<ResourceID>& targetArgumentsBuffer(isMain ? m_ruleIndex.m_byThreadInfos[target.getWorkerIndex()]->m_argumentBufferMain : m_ruleIndex.m_byThreadInfos[target.getWorkerIndex()]->m_argumentBufferIncremental);
        if (prepareApply(argumentsBuffer, argumentIndexes, targetArgumentsBuffer))
            literalMatched<isMain, T, headAtomConsumer, componentLevelFilter, callMonitor>(threadContext, target, componentLevel, materializationMonitor);
    }
}

// NonPivotBodyLiteralInfo

template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
always_inline void NonPivotBodyLiteralInfo::matchLiteral(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) {
    if (isInComponentLevelFilter<componentLevelFilter>(componentLevel)) {
        if (callMonitor)
            materializationMonitor->bodyLiteralMatchingStarted(target.getWorkerIndex(), *this);
        TupleIterator& tupleIterator = (isMain ? *m_tupleIteratorsByThreadMain[target.getWorkerIndex()] : *m_tupleIteratorsByThreadIncremental[target.getWorkerIndex()]);
        size_t multiplicity = tupleIterator.open(threadContext);
        while (multiplicity != 0) {
            literalMatched<isMain, T, headAtomConsumer, componentLevelFilter, callMonitor>(threadContext, target, componentLevel, materializationMonitor);
            multiplicity = tupleIterator.advance();
        }
        if (callMonitor)
            materializationMonitor->bodyLiteralMatchingFinished(target.getWorkerIndex());
    }
}

// SupportingFactsEvaluator

always_inline size_t SupportingFactsEvaluator::open(ThreadContext& threadContext) {
    return m_tupleIterator->open(threadContext);
}

always_inline size_t SupportingFactsEvaluator::advance() {
    return m_tupleIterator->advance();
}

// HeadAtomInfo

template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, bool callMonitor>
always_inline void HeadAtomInfo::headAtomMatched(ThreadContext& threadContext, T& target, const BodyLiteralInfo* const lastBodyLiteralInfo, MaterializationMonitor* const materializationMonitor) {
    if (m_ruleInfo.m_active) {
        std::vector<ResourceID>& argumentsBuffer(isMain ? m_ruleInfo.m_ruleIndex.m_byThreadInfos[target.getWorkerIndex()]->m_argumentBufferMain : m_ruleInfo.m_ruleIndex.m_byThreadInfos[target.getWorkerIndex()]->m_argumentBufferIncremental);
        if (callMonitor)
            materializationMonitor->ruleMatchedStarted(target.getWorkerIndex(), m_ruleInfo, lastBodyLiteralInfo, argumentsBuffer, m_headArgumentIndexes);
        (*headAtomConsumer)(threadContext, target, *this, argumentsBuffer, m_headArgumentIndexes);
        if (callMonitor)
            materializationMonitor->ruleMatchedFinished(target.getWorkerIndex());
    }
}

always_inline HeadAtomInfo* HeadAtomInfo::getNextMatchingHeadAtomInfo(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    HeadAtomInfo* result = HeadAtomInfoPatternMain::getNextIndexed();
    while (result != nullptr && !result->satisfiesEqualities(argumentsBuffer, argumentIndexes))
        result = result->HeadAtomInfoPatternMain::getNextIndexed();
    return result;
}

always_inline bool HeadAtomInfo::isSupportingFactsAtom(const size_t literalsIndex) const {
    return m_supportingFactsLiterals[literalsIndex];
}

always_inline SupportingFactsEvaluator& HeadAtomInfo::getSupportingFactsEvaluatorPrototype(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    std::vector<ResourceID>& targetArgumentsBuffer = m_supportingFactsEvaluatorPrototype->m_argumentsBuffer;
    for (std::vector<ArgumentToBuffer>::iterator iterator = m_supportingFactsCopyToBuffer.begin(); iterator != m_supportingFactsCopyToBuffer.end(); ++iterator)
        targetArgumentsBuffer[iterator->m_targetIndex] = argumentsBuffer[argumentIndexes[iterator->m_sourceIndex]];
    return *m_supportingFactsEvaluatorPrototype;
}

always_inline std::unique_ptr<SupportingFactsEvaluator> HeadAtomInfo::getSupportingFactsEvaluator(const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes) {
    std::unique_ptr<SupportingFactsEvaluator> result;
    if (m_supportingFactsEvaluators.empty())
        result.reset(new SupportingFactsEvaluator(*m_supportingFactsEvaluatorPrototype));
    else {
        result = std::move(m_supportingFactsEvaluators.back());
        m_supportingFactsEvaluators.erase(m_supportingFactsEvaluators.end() - 1);
    }
    std::vector<ResourceID>& targetArgumentsBuffer = result->m_argumentsBuffer;
    for (std::vector<ArgumentToBuffer>::iterator iterator = m_supportingFactsCopyToBuffer.begin(); iterator != m_supportingFactsCopyToBuffer.end(); ++iterator)
        targetArgumentsBuffer[iterator->m_targetIndex] = argumentsBuffer[argumentIndexes[iterator->m_sourceIndex]];
    return result;
}

always_inline void HeadAtomInfo::leaveSupportFactsEvaluator(std::unique_ptr<SupportingFactsEvaluator> supportingFactsEvaluator) {
    m_supportingFactsEvaluators.push_back(std::move(supportingFactsEvaluator));
}

// RuleInfo

template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, bool checkComponentLevel, bool callMonitor>
always_inline void RuleInfo::evaluateRule(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) const {
    TupleIterator& tupleIterator = (isMain ? *m_ruleEvaluatorsByThreadMain[target.getWorkerIndex()] : *m_ruleEvaluatorsByThreadIncremental[target.getWorkerIndex()]);
    std::vector<ResourceID>& argumentsBuffer = (isMain ? m_ruleIndex.m_byThreadInfos[target.getWorkerIndex()]->m_argumentBufferMain : m_ruleIndex.m_byThreadInfos[target.getWorkerIndex()]->m_argumentBufferIncremental);
    size_t multiplicity = tupleIterator.open(threadContext);
    while (multiplicity != 0) {
        for (auto iterator = m_headAtomInfos.begin(); iterator != m_headAtomInfos.end(); ++iterator) {
            HeadAtomInfo& headAtomInfo = **iterator;
            if (!checkComponentLevel || headAtomInfo.getComponentLevel() == componentLevel) {
                if (callMonitor)
                    materializationMonitor->ruleMatchedStarted(target.getWorkerIndex(), *this, nullptr, argumentsBuffer, headAtomInfo.m_headArgumentIndexes);
                (*headAtomConsumer)(threadContext, target, headAtomInfo, argumentsBuffer, headAtomInfo.m_headArgumentIndexes);
                if (callMonitor)
                    materializationMonitor->ruleMatchedFinished(target.getWorkerIndex());
            }
        }
        multiplicity = tupleIterator.advance();
    }
}

template<class T, HeadAtomConsumer<T> headAtomConsumer, bool checkComponentLevel, bool callMonitor>
always_inline void RuleInfo::evaluateRuleMain(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) const {
    evaluateRule<true, T, headAtomConsumer, checkComponentLevel, callMonitor>(threadContext, target, componentLevel, materializationMonitor);
}

template<class T, HeadAtomConsumer<T> headAtomConsumer, bool checkComponentLevel, bool callMonitor>
always_inline void RuleInfo::evaluateRuleIncremental(ThreadContext& threadContext, T& target, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) const {
    evaluateRule<false, T, headAtomConsumer, checkComponentLevel, callMonitor>(threadContext, target, componentLevel, materializationMonitor);
}

// LiteralPatternIndex::LiteralPatternIndexPolicy

template<class ObjectType, class PatternType>
always_inline void LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::getBucketContents(const uint8_t* const bucket, typename LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::BucketContents& bucketContents) {
    bucketContents.m_object = const_cast<ObjectType*>(*reinterpret_cast<const ObjectType* const *>(bucket));
}

template<class ObjectType, class PatternType>
always_inline BucketStatus LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::getBucketContentsStatus(const typename LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::BucketContents& bucketContents, const size_t valuesHashCode, const ResourceID subjectID, const ResourceID predicateID, const ResourceID objectID) {
    if (bucketContents.m_object == nullptr)
        return BUCKET_EMPTY;
    else
        return bucketContents.m_object->PatternType::m_currentIndexingPattern[0] == subjectID && bucketContents.m_object->PatternType::m_currentIndexingPattern[1] == predicateID && bucketContents.m_object->PatternType::m_currentIndexingPattern[2] == objectID ? BUCKET_CONTAINS : BUCKET_NOT_CONTAINS;
}

template<class ObjectType, class PatternType>
always_inline BucketStatus LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::getBucketContentsStatus(const typename LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::BucketContents& bucketContents, const size_t valuesHashCode, const ObjectType* const object) {
    if (bucketContents.m_object == nullptr)
        return BUCKET_EMPTY;
    else
        return bucketContents.m_object->PatternType::m_currentIndexingPattern[0] == object->PatternType::m_currentIndexingPattern[0] && bucketContents.m_object->PatternType::m_currentIndexingPattern[1] == object->PatternType::m_currentIndexingPattern[1] && bucketContents.m_object->PatternType::m_currentIndexingPattern[2] == object->PatternType::m_currentIndexingPattern[2] ? BUCKET_CONTAINS : BUCKET_NOT_CONTAINS;
}

template<class ObjectType, class PatternType>
always_inline bool LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::setBucketContentsIfEmpty(uint8_t* const bucket, const typename LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::BucketContents& bucketContents) {
    if (*reinterpret_cast<ObjectType**>(bucket) == nullptr) {
        setObject(bucket, bucketContents.m_object);
        return true;
    }
    else
        return false;
}

template<class ObjectType, class PatternType>
always_inline bool LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::isBucketContentsEmpty(const typename LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::BucketContents& bucketContents) {
    return bucketContents.m_object == nullptr;
}

template<class ObjectType, class PatternType>
always_inline size_t LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::getBucketContentsHashCode(const typename LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::BucketContents& bucketContents) {
    return hashCodeFor(bucketContents.m_object->PatternType::m_currentIndexingPattern[0], bucketContents.m_object->PatternType::m_currentIndexingPattern[1], bucketContents.m_object->PatternType::m_currentIndexingPattern[2]);
}

template<class ObjectType, class PatternType>
always_inline size_t LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::hashCodeFor(const ResourceID subjectID, const ResourceID predicateID, const ResourceID objectID) {
    size_t hash = 0;

    hash += subjectID;
    hash += (hash << 10);
    hash ^= (hash >> 6);

    hash += predicateID;
    hash += (hash << 10);
    hash ^= (hash >> 6);

    hash += objectID;
    hash += (hash << 10);
    hash ^= (hash >> 6);

    hash += (hash << 3);
    hash ^= (hash >> 11);
    hash += (hash << 15);
    return hash;
}

template<class ObjectType, class PatternType>
always_inline size_t LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::hashCodeFor(const ObjectType* const object) {
    return hashCodeFor(object->PatternType::m_currentIndexingPattern[0], object->PatternType::m_currentIndexingPattern[1], object->PatternType::m_currentIndexingPattern[2]);
}

template<class ObjectType, class PatternType>
always_inline void LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::makeBucketEmpty(uint8_t* const bucket) {
    *reinterpret_cast<ObjectType**>(bucket) = nullptr;
}

template<class ObjectType, class PatternType>
always_inline const ObjectType* LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::getObject(const uint8_t* const bucket) {
    return *reinterpret_cast<const ObjectType* const *>(bucket);
}

template<class ObjectType, class PatternType>
always_inline void LiteralPatternIndex<ObjectType, PatternType>::LiteralPatternIndexPolicy::setObject(uint8_t* const bucket, ObjectType* const object) {
    *reinterpret_cast<ObjectType**>(bucket) = object;
}

// LiteralPatternIndex

template<class ObjectType, class PatternType>
always_inline ObjectType* LiteralPatternIndex<ObjectType, PatternType>::getFirstObject(ThreadContext& threadContext, const size_t indexingPatternNumber, const ResourceID subjectID, const ResourceID predicateID, const ResourceID objectID) {
    const ResourceID querySubjectID = ((indexingPatternNumber & 0x4) == 0 ? INVALID_RESOURCE_ID : subjectID);
    const ResourceID queryPredicateID = ((indexingPatternNumber & 0x2) == 0 ? INVALID_RESOURCE_ID : predicateID);
    const ResourceID queryObjectID = ((indexingPatternNumber & 0x1) == 0 ? INVALID_RESOURCE_ID : objectID);
    typename SequentialHashTable<LiteralPatternIndexPolicy>::BucketDescriptor bucketDescriptor;
    m_index.acquireBucket(threadContext, bucketDescriptor, querySubjectID, queryPredicateID, queryObjectID);
    m_index.continueBucketSearch(threadContext, bucketDescriptor, querySubjectID, queryPredicateID, queryObjectID);
    m_index.releaseBucket(threadContext, bucketDescriptor);
    return bucketDescriptor.m_bucketContents.m_object;
}

// BodyLiteralInfoByPatternIndex

template<class PatternType>
template<bool isMain, class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
always_inline void PivotBodyLiteralInfoByPatternIndex<PatternType>::applyRulesTo(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) {
    for (size_t indexingPatternNumber = 0; indexingPatternNumber < 8; ++indexingPatternNumber) {
        if (this->m_patternCounts[indexingPatternNumber] != 0) {
            PivotBodyLiteralInfo* pivotBodyLiteralInfo = this->getFirstObject(threadContext, indexingPatternNumber, argumentsBuffer[argumentIndexes[0]], argumentsBuffer[argumentIndexes[1]], argumentsBuffer[argumentIndexes[2]]);
            while (pivotBodyLiteralInfo != nullptr) {
                pivotBodyLiteralInfo->template applyTo<isMain, T, headAtomConsumer, componentLevelFilter, callMonitor>(threadContext, target, argumentsBuffer, argumentIndexes, componentLevel, materializationMonitor);
                pivotBodyLiteralInfo = pivotBodyLiteralInfo->PatternType::getNextIndexed();
            }
        }
    }
}

// HeadAtomInfoByPatternIndex

template<class PatternType>
always_inline HeadAtomInfo* HeadAtomInfoByPatternIndex<PatternType>::getMatchingHeadAtomInfos(ThreadContext& threadContext, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t indexingPatternNumber) {
    if (this->m_patternCounts[indexingPatternNumber] != 0) {
        HeadAtomInfo* headAtomInfo = this->getFirstObject(threadContext, indexingPatternNumber, argumentsBuffer[argumentIndexes[0]], argumentsBuffer[argumentIndexes[1]], argumentsBuffer[argumentIndexes[2]]);
        while (headAtomInfo != nullptr && !headAtomInfo->satisfiesEqualities(argumentsBuffer, argumentIndexes))
            headAtomInfo = headAtomInfo->PatternType::getNextIndexed();
        return headAtomInfo;
    }
    else
        return nullptr;
}

// RuleIndex

template<class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
always_inline void RuleIndex::applyRulesToPositiveLiteralMain(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) {
    m_positivePivotBodyLiteralInfoByPatternIndexMain.applyRulesTo<true, T, headAtomConsumer, componentLevelFilter, callMonitor>(threadContext, target, argumentsBuffer, argumentIndexes, componentLevel, materializationMonitor);
}

template<class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
always_inline void RuleIndex::applyRulesToNegativeLiteralMain(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) {
    m_negativePivotBodyLiteralInfoByPatternIndexMain.applyRulesTo<true, T, headAtomConsumer, componentLevelFilter, callMonitor>(threadContext, target, argumentsBuffer, argumentIndexes, componentLevel, materializationMonitor);
}

template<class T, HeadAtomConsumer<T> headAtomConsumer, ComponentLevelFilter componentLevelFilter, bool callMonitor>
always_inline void RuleIndex::applyRulesToPositiveLiteralIncremental(ThreadContext& threadContext, T& target, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t componentLevel, MaterializationMonitor* const materializationMonitor) {
    m_positivePivotBodyLiteralInfoByPatternIndexIncremental.applyRulesTo<false, T, headAtomConsumer, componentLevelFilter, callMonitor>(threadContext, target, argumentsBuffer, argumentIndexes, componentLevel, materializationMonitor);
}

always_inline HeadAtomInfo* RuleIndex::getMatchingHeadAtomInfos(ThreadContext& threadContext, const std::vector<ResourceID>& argumentsBuffer, const std::vector<ArgumentIndex>& argumentIndexes, const size_t indexingPatternNumber) {
    return m_headAtomInfoByPatternIndexMain.getMatchingHeadAtomInfos(threadContext, argumentsBuffer, argumentIndexes, indexingPatternNumber);
}

#endif /* RULEINDEXIMPL_H_ */
