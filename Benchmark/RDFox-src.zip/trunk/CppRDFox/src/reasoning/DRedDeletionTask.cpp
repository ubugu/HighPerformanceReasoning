// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "AbstractDeletionTaskImpl.h"
#include "DRedDeletionTask.h"

// DRedDeletionTask

template<bool callMonitor>
always_inline std::unique_ptr<ReasoningTaskWorker> DRedDeletionTask::doCreateWorker1(DatalogEngineWorker& datalogEngineWorker) {
    if (m_componentLevel == static_cast<size_t>(-1))
        return doCreateWorker2<callMonitor, false>(datalogEngineWorker);
    else
        return doCreateWorker2<callMonitor, true>(datalogEngineWorker);
}

template<bool callMonitor, bool checkComponentLevel>
always_inline std::unique_ptr<ReasoningTaskWorker> DRedDeletionTask::doCreateWorker2(DatalogEngineWorker& datalogEngineWorker) {
    if (m_datalogEngine.getRuleIndex().componentLevelHasRules(m_componentLevel))
        return doCreateWorker3<callMonitor, checkComponentLevel, true>(datalogEngineWorker);
    else
        return doCreateWorker3<callMonitor, checkComponentLevel, false>(datalogEngineWorker);
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent>
always_inline std::unique_ptr<ReasoningTaskWorker> DRedDeletionTask::doCreateWorker3(DatalogEngineWorker& datalogEngineWorker) {
    switch (m_datalogEngine.getDataStore().getEqualityAxiomatizationType()) {
    case EQUALITY_AXIOMATIZATION_NO_UNA:
        return doCreateWorker4<callMonitor, checkComponentLevel, hasRulesInComponent, EQUALITY_AXIOMATIZATION_NO_UNA>(datalogEngineWorker);
    case EQUALITY_AXIOMATIZATION_UNA:
        return doCreateWorker4<callMonitor, checkComponentLevel, hasRulesInComponent, EQUALITY_AXIOMATIZATION_UNA>(datalogEngineWorker);
    case EQUALITY_AXIOMATIZATION_OFF:
    default:
        return doCreateWorker4<callMonitor, checkComponentLevel, hasRulesInComponent, EQUALITY_AXIOMATIZATION_OFF>(datalogEngineWorker);
    }
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType>
always_inline std::unique_ptr<ReasoningTaskWorker> DRedDeletionTask::doCreateWorker4(DatalogEngineWorker& datalogEngineWorker) {
    if (isMultithreaded())
        return std::unique_ptr<ReasoningTaskWorker>(new DRedDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, true>(*this, datalogEngineWorker));
    else
        return std::unique_ptr<ReasoningTaskWorker>(new DRedDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, false>(*this, datalogEngineWorker));
}

std::unique_ptr<ReasoningTaskWorker> DRedDeletionTask::doCreateWorker(DatalogEngineWorker& datalogEngineWorker) {
    if (m_incrementalMonitor == nullptr)
        return doCreateWorker1<false>(datalogEngineWorker);
    else
        return doCreateWorker1<true>(datalogEngineWorker);
}

DRedDeletionTask::DRedDeletionTask(DatalogEngine& datalogEngine, IncrementalMonitor* const incrementalMonitor, IncrementalReasoningState& incrementalReasoningState, const size_t componentLevel) : AbstractDeletionTask(datalogEngine, incrementalMonitor, incrementalReasoningState, componentLevel) {
}

// FBFDeletionTaskWorker

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
DRedDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::DRedDeletionTaskWorker(DRedDeletionTask& dredDeletionTask, DatalogEngineWorker& datalogEngineWorker) :
    AbstractDeletionTaskWorker<DRedDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded> >(dredDeletionTask, datalogEngineWorker)
{
}

template<bool callMonitor, bool checkComponentLevel, bool hasRulesInComponent, EqualityAxiomatizationType equalityAxiomatizationType, bool multithreaded>
always_inline bool DRedDeletionTaskWorker<callMonitor, checkComponentLevel, hasRulesInComponent, equalityAxiomatizationType, multithreaded>::check(ThreadContext& threadContext, TupleIndex checkTupleIndex, const std::vector<ResourceID>* checkArgumentsBuffer, const std::vector<ArgumentIndex>* checkArgumentIndexes) {
    return false;
}
