// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "../RDFStoreException.h"
#include "../dictionary/Dictionary.h"
#include "../dictionary/ResourceValueCache.h"
#include "../logic/Logic.h"
#include "../storage/DataStore.h"
#include "../querying/QueryCompiler.h"
#include "../querying/QueryIterator.h"
#include "../formats/turtle/SPARQLParser.h"
#include "../util/ThreadContext.h"
#include "ResultFormat.h"
#include "SPARQLEndPoint.h"

SPARQLEndPoint::SPARQLEndPoint() {
}

always_inline static void setFaultMessage(const char* const message, std::ostringstream& output, dlib::outgoing_things& outgoing) {
    outgoing.headers.insert(std::pair<std::string, std::string>("Content-Type", "text/plain; charset=UTF-8"));
    outgoing.http_return = 400;
    outgoing.http_return_status = "Bad Request";
    output.str("");
    output.clear();
    output << message;
}

const std::string SPARQLEndPoint::on_request(const dlib::incoming_things& incoming, dlib::outgoing_things& outgoing) {
    std::ostringstream output;
    try {
        // TODO: Queries are stored as key_value_map, but protocol allows to have multiple default-graph-uri
        // and named-graph-uri. We should write our request url parser or extend/modify the one in dlib
        const std::string& queryString = incoming.queries["query"];
        Prefixes prefixes;
        SPARQLParser parser(prefixes);
        LogicFactory factory(::newLogicFactory());
        Query query = parser.parse(factory, queryString.c_str(), queryString.length());
        std::vector<std::string> answerVariableNames;
        std::vector<ArgumentIndex> answerVariablePositions;
        const std::vector<Term>& answerTerms = query->getAnswerTerms();
        for (std::vector<Term>::const_iterator iterator = answerTerms.begin(); iterator != answerTerms.end(); ++iterator) {
            if ((*iterator)->getType() == VARIABLE) {
                answerVariableNames.push_back(to_pointer_cast<Variable>(*iterator)->getName());
                answerVariablePositions.push_back(static_cast<ArgumentIndex>(iterator - answerTerms.begin()));
            }
        }
        DataStore* dataStore = getDataStore();
        if (dataStore == 0)
            setFaultMessage("No data store is active at present.", output, outgoing);
        else {
            const std::string& resultFormatName = incoming.queries["output"];
            std::unique_ptr<ResultFormat> resultFormat = ResultFormat::newResultFormat(resultFormatName, output, false, answerVariableNames);
            if (resultFormat.get()) {
                QueryCompiler queryCompiler(*dataStore);
                std::unique_ptr<QueryIterator> queryIterator = queryCompiler.compileQuery(query);
                resultFormat->printPrologue();
                size_t multiplicity = queryIterator->open();
                resultFormat->startResultBlock();
                const ResourceValueCache& resourceValueCache = queryIterator->getResourceValueCache();
                const std::vector<ResourceID>& argumentsBuffer = queryIterator->getArgumentsBuffer();
                ResourceValue resourceValue;
                std::string lexicalForm;
                DatatypeID datatypeID;
                while (multiplicity != 0) {
                    resultFormat->printResultStart();
                    for (std::vector<ArgumentIndex>::iterator iterator = answerVariablePositions.begin(); iterator != answerVariablePositions.end(); ++iterator) {
                        const ResourceID resourceID = argumentsBuffer[*iterator];
                        if (resourceValueCache.getResource(resourceID, resourceValue)) {
                            Dictionary::toLexicalForm(resourceValue, lexicalForm);
                            datatypeID = resourceValue.getDatatypeID();
                        }
                        else {
                            std::ostringstream message;
                            message << "Resource ID " << resourceID << " cannot be resolved in the dictionary.";
                            lexicalForm = message.str();
                            datatypeID = D_XSD_STRING;
                        }
                        resultFormat->printResultResource(lexicalForm, datatypeID);
                    }
                    resultFormat->printResultEnd();
                    multiplicity = queryIterator->advance();
                }
                resultFormat->printEpilogue();
            }
            else {
                std::ostringstream message;
                message << "Format with name '" << resultFormatName << "' is not supported.";
                setFaultMessage(message.str().c_str(), output, outgoing);
            }
        }
    }
    catch (const RDFStoreException& e) {
        setFaultMessage(e.what(), output, outgoing);
    }
    return output.str();
}
