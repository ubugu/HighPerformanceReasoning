// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "../dictionary/Dictionary.h"
#include "../storage/TupleIterator.h"
#include "ResultFormat.h"

class Dictionary;
class TupleIterator;

const static char HEX[16] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

// XMLResultFormat

class XMLResultFormat : public ResultFormat {

protected:

    bool m_atLeastOneResult;
    std::vector<std::string>::const_iterator m_nextResultVariable;

public:

    XMLResultFormat(std::ostream& output, const bool isAskQuery, const std::vector<std::string>& answerVariableNames) :
        ResultFormat("xml", "application/sparql-results+xml", output, isAskQuery, answerVariableNames),
        m_atLeastOneResult(false),
        m_nextResultVariable(m_answerVariableNames.end())
    {
    }

    void write(std::string::const_iterator start, std::string::const_iterator end);

    virtual void printPrologue();

    virtual void printResultBlockLink();

    virtual void startResultBlock();

    virtual void printResultStart();

    virtual void printResultResource(const std::string& lexicalForm, const DatatypeID datatypeID);

    virtual void printResultEnd();

    virtual void printEpilogue();

};

always_inline void XMLResultFormat::write(std::string::const_iterator start, std::string::const_iterator end) {
    for (; start != end; ++start) {
        const char c = *start;
        switch (c) {
        case '&':
            m_output << "&amp;";
            break;
        case '\"':
            m_output << "&quot;";
            break;
        case '\'':
            m_output << "&apos;";
            break;
        case '<':
            m_output << "&lt;";
            break;
        case '>':
            m_output << "&gt;";
            break;
        default:
            m_output << c;
            break;
        }
    }
}

void XMLResultFormat::printPrologue() {
    m_output <<
        "<?xml version=\"1.0\"?>\n"
        "<sparql xmlns=\"http://www.w3.org/2005/sparql-results#\">\n"
        "<head>\n";
    for (std::vector<std::string>::const_iterator iterator = m_answerVariableNames.begin(); iterator != m_answerVariableNames.end(); ++iterator) {
        m_output << "  <variable name=\"";
        write(iterator->begin(), iterator->end());
        m_output << "\"/>\n";
    }
    m_output << "</head>\n";
    if (!m_isAskQuery)
        m_output << "<results>\n";
}

void XMLResultFormat::printResultBlockLink() {
    m_atLeastOneResult = true;
}

void XMLResultFormat::startResultBlock() {
}

void XMLResultFormat::printResultStart() {
    if (!m_isAskQuery)
        m_output << " <result>\n";
    m_nextResultVariable = m_answerVariableNames.begin();
}

void XMLResultFormat::printResultResource(const std::string& lexicalForm, const DatatypeID datatypeID) {
    if (datatypeID != D_INVALID_DATATYPE_ID) {
        m_output << "  <binding name=\"";
        write(m_nextResultVariable->begin(), m_nextResultVariable->end());
        m_output << "\">";
        switch (datatypeID) {
        case D_IRI_REFERENCE:
            m_output << "<uri>";
            write(lexicalForm.begin(), lexicalForm.end());
            m_output << "</uri>";
            break;
        case D_BLANK_NODE:
            m_output << "<bnode>";
            write(lexicalForm.begin(), lexicalForm.end());
            m_output << "</bnode>";
            break;
        case D_XSD_STRING:
            m_output << "<literal>";
            write(lexicalForm.begin(), lexicalForm.end());
            m_output << "</literal>";
            break;
        case D_RDF_PLAIN_LITERAL:
            {
                const std::string::const_iterator atPosition = lexicalForm.begin() + lexicalForm.find_last_of('@');
                m_output << "<literal xml:lang=\"";
                write(atPosition + 1, lexicalForm.end());
                m_output << "\">";
                write(lexicalForm.begin(), atPosition);
                m_output << "</literal>";
            }
            break;
        default:
            {
                const std::string& datatypeIRI = Dictionary::getDatatypeIRI(datatypeID);
                m_output << "<literal datatype=\"";
                write(datatypeIRI.begin(), datatypeIRI.end());
                m_output << "\">";
                write(lexicalForm.begin(), lexicalForm.end());
                m_output << "</literal>";
            }
            break;
        }
        m_output << "</binding>\n";
    }
    ++m_nextResultVariable;
}

void XMLResultFormat::printResultEnd() {
    if (m_isAskQuery) {
        if (!m_atLeastOneResult)
            m_output << "    <boolean>true</boolean>\n";
    }
    else
        m_output << " </result>\n";
    m_atLeastOneResult = true;
}

void XMLResultFormat::printEpilogue() {
    if (m_isAskQuery) {
        if (!m_atLeastOneResult)
            m_output << "    <boolean>false</boolean>\n";
    }
    else
        m_output << "</results>\n";
    m_output << "</sparql>\n";
}

// JSONResultFormat

class JSONResultFormat : public ResultFormat {

protected:

    bool m_atLeastOneResult;
    bool m_atLeastOneResultWasPrintedInBlock;
    bool m_atLeastOneResourceWasPrintedInResult;
    std::vector<std::string>::const_iterator m_nextResultVariable;

public:

    JSONResultFormat(std::ostream& output, const bool isAskQuery, const std::vector<std::string>& answerVariableNames) :
        ResultFormat("json", "application/sparql-results+json", output, isAskQuery, answerVariableNames),
        m_atLeastOneResult(false),
        m_atLeastOneResultWasPrintedInBlock(false),
        m_atLeastOneResourceWasPrintedInResult(false),
        m_nextResultVariable(m_answerVariableNames.end())
    {
    }

    void write(std::string::const_iterator start, std::string::const_iterator end);

    virtual void printPrologue();

    virtual void printResultBlockLink();

    virtual void startResultBlock();

    virtual void printResultStart();

    virtual void printResultResource(const std::string& lexicalForm, const DatatypeID datatypeID);

    virtual void printResultEnd();

    virtual void printEpilogue();

};

void JSONResultFormat::write(std::string::const_iterator start, std::string::const_iterator end) {
    m_output << '\"';
    for (; start != end; ++start) {
        const char c = *start;
        if ((0 <= static_cast<uint8_t>(c) && static_cast<uint8_t>(c) <= 0x001Fu) || (0x007Fu <= static_cast<uint8_t>(c) && static_cast<uint8_t>(c) <= 0x009Fu)) {
            switch (c) {
            case '\"':
            case '\\':
            case '\b':
            case '\f':
            case '\n':
            case '\r':
            case '\t':
                m_output << '\\' << c;
                break;
            default:
                m_output << "\\u00" << HEX[static_cast<uint8_t>(c) >> 4] << HEX[static_cast<uint8_t>(c) & 0x0Fu];
                break;
            }
        }
        else
            m_output << c;
    }
    m_output << '\"';
}

void JSONResultFormat::printPrologue() {
    m_output <<
        "{\n"
        "    \"head\": { ";
    if (!m_answerVariableNames.empty()) {
        m_output << "\"vars\": [ ";
        bool first = true;
        for (std::vector<std::string>::const_iterator iterator = m_answerVariableNames.begin(); iterator != m_answerVariableNames.end(); ++iterator) {
            if (first)
                first = false;
            else
                m_output << ", ";
            write(iterator->begin(), iterator->end());
        }
        m_output << " ]";
    }
    m_output << " },\n";
    if (!m_isAskQuery) {
        m_output <<
            "    \"results\": {\n"
            "        \"bindings\": [";
    }
}

void JSONResultFormat::printResultBlockLink() {
    m_output << ',';
    m_atLeastOneResult = true;
}

void JSONResultFormat::startResultBlock() {
    m_atLeastOneResultWasPrintedInBlock = false;
}

void JSONResultFormat::printResultStart() {
    if (!m_isAskQuery) {
        if (m_atLeastOneResultWasPrintedInBlock)
            m_output << ',';
        else
            m_atLeastOneResultWasPrintedInBlock = true;
        m_output << "\n{";
    }
    m_nextResultVariable = m_answerVariableNames.begin();
    m_atLeastOneResourceWasPrintedInResult = false;
}

void JSONResultFormat::printResultResource(const std::string& lexicalForm, const DatatypeID datatypeID) {
    if (datatypeID != D_INVALID_DATATYPE_ID) {
        if (m_atLeastOneResourceWasPrintedInResult)
            m_output << ',';
        else
            m_atLeastOneResourceWasPrintedInResult = true;
        m_output << "\n    ";
        write(m_nextResultVariable->begin(), m_nextResultVariable->end());
        m_output << ": { ";
        switch (datatypeID) {
        case D_IRI_REFERENCE:
            m_output << "\"type\" : \"uri\", \"value\" : ";
            write(lexicalForm.begin(), lexicalForm.end());
            break;
        case D_BLANK_NODE:
            m_output << "\"type\" : \"bnode\", \"value\" : ";
            write(lexicalForm.begin(), lexicalForm.end());
            break;
        case D_XSD_STRING:
            m_output << "\"type\" : \"literal\", \"value\" : ";
            write(lexicalForm.begin(), lexicalForm.end());
            break;
        case D_RDF_PLAIN_LITERAL:
            {
                const std::string::const_iterator atPosition = lexicalForm.begin() + lexicalForm.find_last_of('@');
                m_output << "\"type\" : \"literal\", \"value\" : ";
                write(lexicalForm.begin(), atPosition);
                m_output << ", \"xml:lang\" : ";
                write(atPosition + 1, lexicalForm.end());
            }
            break;
        default:
            {
                const std::string& datatypeIRI = Dictionary::getDatatypeIRI(datatypeID);
                m_output << "\"type\" : \"literal\", \"value\" : ";
                write(lexicalForm.begin(), lexicalForm.end());
                m_output << ", \"datatype\" : ";
                write(datatypeIRI.begin(), datatypeIRI.end());
            }
            break;
        }
        m_output << " }";
    }
    ++m_nextResultVariable;
}

void JSONResultFormat::printResultEnd() {
    if (m_isAskQuery) {
        if (!m_atLeastOneResult)
            m_output << "    \"boolean\": true";
    }
    else
        m_output << "\n}";
    m_atLeastOneResult = true;
}

void JSONResultFormat::printEpilogue() {
    if (m_isAskQuery) {
        if (!m_atLeastOneResult)
            m_output << "    \"boolean\": false";
    }
    else {
        m_output <<
            "\n"
            "        ]\n"
            "    }";
    }
    m_output << "\n}\n";
}

// CSVResultFormat

class CSVResultFormat : public ResultFormat {

protected:

    bool m_atLeastOneResult;
    bool m_atLeastOneResourceWasPrintedInResult;

public:

    CSVResultFormat(std::ostream& output, const bool isAskQuery, const std::vector<std::string>& answerVariableNames) :
        ResultFormat("csv", "text/csv; charset=UTF-8; header=present", output, isAskQuery, answerVariableNames),
        m_atLeastOneResult(false),
        m_atLeastOneResourceWasPrintedInResult(false)
    {
    }

    void write(std::string::const_iterator start, std::string::const_iterator end);

    virtual void printPrologue();

    virtual void printResultBlockLink();

    virtual void startResultBlock();

    virtual void printResultStart();

    virtual void printResultResource(const std::string& lexicalForm, const DatatypeID datatypeID);

    virtual void printResultEnd();

    virtual void printEpilogue();
    
};

void CSVResultFormat::write(std::string::const_iterator start, std::string::const_iterator end) {
    bool useQuote = false;
    for (std::string::const_iterator current = start; current != end; ++current) {
        const char c = *current;
        if (c == '\n' || c == '\r' || c == '\"' || c == ',') {
            useQuote = true;
            m_output << '\"';
            break;
        }
    }
    for (; start != end; ++start) {
        const char c = *start;
        if (c == '\"')
            m_output << '\"';
        m_output << c;
    }
    if (useQuote)
        m_output << '\"';
}

void CSVResultFormat::printPrologue() {
    bool first = true;
    for (std::vector<std::string>::const_iterator iterator = m_answerVariableNames.begin(); iterator != m_answerVariableNames.end(); ++iterator) {
        if (first)
            first = false;
        else
            m_output << ',';
        write(iterator->begin(), iterator->end());
    }
    m_output << "\r\n";
}

void CSVResultFormat::printResultBlockLink() {
    m_atLeastOneResult = true;
}

void CSVResultFormat::startResultBlock() {
}

void CSVResultFormat::printResultStart() {
    m_atLeastOneResourceWasPrintedInResult = false;
}

void CSVResultFormat::printResultResource(const std::string& lexicalForm, const DatatypeID datatypeID) {
    if (m_atLeastOneResourceWasPrintedInResult)
        m_output << ',';
    else
        m_atLeastOneResourceWasPrintedInResult = true;
    switch (datatypeID) {
    case D_INVALID_DATATYPE_ID:
        break;
    case D_BLANK_NODE:
        {
            std::string nodeName("_:");
            nodeName.append(lexicalForm);
            write(nodeName.begin(), nodeName.end());
        }
        break;
    case D_RDF_PLAIN_LITERAL:
        write(lexicalForm.begin(), lexicalForm.begin() + lexicalForm.find_last_of('@'));
        break;
    default:
        write(lexicalForm.begin(), lexicalForm.end());
        break;
    }
}

void CSVResultFormat::printResultEnd() {
    if (!m_isAskQuery || !m_atLeastOneResult)
        m_output << "\r\n";
    m_atLeastOneResult = true;
}

void CSVResultFormat::printEpilogue() {
}

// TSVResultFormat

class TSVResultFormat : public ResultFormat {

protected:

    bool m_atLeastOneResult;
    bool m_atLeastOneResourceWasPrintedInResult;

public:

    TSVResultFormat(std::ostream& output, const bool isAskQuery, const std::vector<std::string>& answerVariableNames) :
        ResultFormat("tsv", "text/tab-separated-value; charset=UTF-8", output, isAskQuery, answerVariableNames),
        m_atLeastOneResult(false),
        m_atLeastOneResourceWasPrintedInResult(false)
    {
    }

    void write(std::string::const_iterator start, std::string::const_iterator end);

    virtual void printPrologue();

    virtual void printResultBlockLink();

    virtual void startResultBlock();

    virtual void printResultStart();

    virtual void printResultResource(const std::string& lexicalForm, const DatatypeID datatypeID);

    virtual void printResultEnd();

    virtual void printEpilogue();
    
};

void TSVResultFormat::write(std::string::const_iterator start, std::string::const_iterator end) {
    for (; start != end; ++start) {
        const char c = *start;
        switch (c) {
        case '\n':
            m_output << "\\n";
            break;
        case '\r':
            m_output << "\\r";
            break;
        case '\t':
            m_output << "\\t";
            break;
        case '\"':
            m_output << "\\\"";
            break;
        case '\\':
            m_output << "\\\\";
            break;
        default:
            m_output << c;
            break;
        }
    }
}

void TSVResultFormat::printPrologue() {
    bool first = true;
    for (std::vector<std::string>::const_iterator iterator = m_answerVariableNames.begin(); iterator != m_answerVariableNames.end(); ++iterator) {
        if (first)
            first = false;
        else
            m_output << '\t';
        m_output << '?';
        write(iterator->begin(), iterator->end());
    }
    m_output << "\r\n";
}

void TSVResultFormat::printResultBlockLink() {
    m_atLeastOneResult = true;
}

void TSVResultFormat::startResultBlock() {
}

void TSVResultFormat::printResultStart() {
    m_atLeastOneResourceWasPrintedInResult = false;
}

void TSVResultFormat::printResultResource(const std::string& lexicalForm, const DatatypeID datatypeID) {
    if (m_atLeastOneResourceWasPrintedInResult)
        m_output << '\t';
    else
        m_atLeastOneResourceWasPrintedInResult = true;
    switch (datatypeID) {
    case D_INVALID_DATATYPE_ID:
        break;
    case D_IRI_REFERENCE:
        m_output << "<";
        write(lexicalForm.begin(), lexicalForm.end());
        m_output << ">";
        break;
    case D_BLANK_NODE:
        m_output << "_:";
        write(lexicalForm.begin(), lexicalForm.end());
        break;
    case D_XSD_STRING:
        m_output << '\"';
        write(lexicalForm.begin(), lexicalForm.end());
        m_output << '\"';
        break;
    case D_RDF_PLAIN_LITERAL:
        {
            const std::string::const_iterator atPosition = lexicalForm.begin() + lexicalForm.find_last_of('@');
            m_output << '\"';
            write(lexicalForm.begin(), atPosition);
            m_output << '\"';
            write(atPosition, lexicalForm.end());
        }
        break;
    case D_XSD_INTEGER:
    case D_XSD_FLOAT:
    case D_XSD_DOUBLE:
    case D_XSD_BOOLEAN:
        m_output << lexicalForm;
        break;
    default:
        {
            const std::string& datatypeIRI = Dictionary::getDatatypeIRI(datatypeID);
            m_output << '\"';
            write(lexicalForm.begin(), lexicalForm.end());
            m_output << "\"^^<";
            write(datatypeIRI.begin(), datatypeIRI.end());
            m_output << '>';
        }
        break;
    }
}

void TSVResultFormat::printResultEnd() {
    if (!m_isAskQuery || !m_atLeastOneResult)
        m_output << "\r\n";
    m_atLeastOneResult = true;
}

void TSVResultFormat::printEpilogue() {
}

// ResultFormat

ResultFormat::ResultFormat(const std::string& name, const std::string& contentType, std::ostream& output, const bool isAskQuery, const std::vector<std::string>& answerVariableNames) :
    m_name(name),
    m_contentType(contentType),
    m_output(output),
    m_isAskQuery(isAskQuery),
    m_answerVariableNames(answerVariableNames)
{
}

ResultFormat::~ResultFormat() {
}

std::unique_ptr<ResultFormat> ResultFormat::newResultFormat(const std::string& resultFormatName, std::ostream& output, const bool isAskQuery, const std::vector<std::string>& answerVariableNames) {
    if (resultFormatName == "xml")
        return std::unique_ptr<ResultFormat>(new XMLResultFormat(output, isAskQuery, answerVariableNames));
    else if (resultFormatName == "json")
        return std::unique_ptr<ResultFormat>(new JSONResultFormat(output, isAskQuery, answerVariableNames));
    else if (resultFormatName == "csv")
        return std::unique_ptr<ResultFormat>(new CSVResultFormat(output, isAskQuery, answerVariableNames));
    else if (resultFormatName == "tsv")
        return std::unique_ptr<ResultFormat>(new TSVResultFormat(output, isAskQuery, answerVariableNames));
    else
        return std::unique_ptr<ResultFormat>();
}
