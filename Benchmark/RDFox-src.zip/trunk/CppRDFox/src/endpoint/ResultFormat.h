// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifndef RESULTFORMAT_H_
#define RESULTFORMAT_H_

#include "../Common.h"

class Dictionary;

class ResultFormat : private Unmovable {

protected:

    const std::string m_name;
    const std::string m_contentType;
    std::ostream& m_output;
    const bool m_isAskQuery;
    const std::vector<std::string>& m_answerVariableNames;

public:

    ResultFormat(const std::string& name, const std::string& contentType, std::ostream& output, const bool isAskQuery, const std::vector<std::string>& answerVariableNames);

    virtual ~ResultFormat();

    always_inline const std::string& getName() const {
        return m_name;
    }

    always_inline const std::string& getContentType() const {
        return m_contentType;
    }

    virtual void printPrologue() = 0;

    virtual void printResultBlockLink() = 0;

    virtual void startResultBlock() = 0;

    virtual void printResultStart() = 0;

    virtual void printResultResource(const std::string& lexicalForm, const DatatypeID datatypeID) = 0;

    virtual void printResultEnd() = 0;

    virtual void printEpilogue() = 0;

    static std::unique_ptr<ResultFormat> newResultFormat(const std::string& resultFormatName, std::ostream& output, const bool isAskQuery, const std::vector<std::string>& answerVariableNames);

};

#endif /* RESULTFORMAT_H_ */
