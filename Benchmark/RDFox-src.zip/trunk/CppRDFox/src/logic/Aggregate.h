// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifndef AGGREGATE_H_
#define AGGREGATE_H_

#include "Formula.h"

class _Aggregate : public _Literal {

    friend class _LogicFactory::FactoryInterningManager<Aggregate>;

protected:

    std::vector<Atom> m_atoms;
    const bool m_skipEmptyGroups;
    std::vector<Variable> m_on;
    std::vector<AggregateBind> m_aggregateBinds;

    _Aggregate(_LogicFactory* const factory, const size_t hash, const std::vector<Atom>& atoms, const bool skipEmptyGroups, const std::vector<Variable>& on, const std::vector<AggregateBind>& aggregateBinds);

    static size_t hashCodeFor(const std::vector<Atom>& atoms, const bool skipEmptyGroups, const std::vector<Variable>& on, const std::vector<AggregateBind>& aggregateBinds);

    bool isEqual(const std::vector<Atom>& atoms, const bool skipEmptyGroups, const std::vector<Variable>& on, const std::vector<AggregateBind>& aggregateBinds) const;

    virtual LogicObject doClone(const LogicFactory& logicFactory) const;

    virtual Formula doApply(const Substitution& substitution, const bool renameImplicitExistentialVariables, size_t& formulaWithImplicitExistentialVariablesCounter) const;

public:

    virtual ~_Aggregate();

    always_inline Aggregate clone(const LogicFactory& logicFactory) const {
        return static_pointer_cast<Aggregate>(doClone(logicFactory));
    }

    virtual const std::vector<Atom>& getAtoms() const;

    virtual bool getSkipEmptyGroups() const;

    virtual const std::vector<Variable>& getOn() const;

    virtual const std::vector<AggregateBind>& getAggregateBinds() const;

    virtual FormulaType getType() const;

    virtual bool isGround() const;

    virtual void getFreeVariablesEx(std::unordered_set<Variable>& freeVariables) const;

    always_inline Aggregate applyEx(const Substitution& substitution, const bool renameImplicitExistentialVariables, size_t& formulaWithImplicitExistentialVariablesCounter) const {
        return static_pointer_cast<Aggregate>(doApply(substitution, renameImplicitExistentialVariables, formulaWithImplicitExistentialVariablesCounter));
    }

    always_inline Aggregate apply(const Substitution& substitution) const {
        size_t formulaWithImplicitExistentialVariablesCounter = 0;
        return applyEx(substitution, false, formulaWithImplicitExistentialVariablesCounter);
    }

    virtual void accept(LogicObjectVisitor& visitor) const;

    virtual std::string toString(const Prefixes& prefixes) const;

};

#endif /* AGGREGATE_H_ */
