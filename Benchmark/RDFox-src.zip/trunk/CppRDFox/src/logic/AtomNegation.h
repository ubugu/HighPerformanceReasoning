// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#ifndef ATOMNEGATION_H_
#define ATOMNEGATION_H_

#include "Formula.h"

class _AtomNegation : public _Literal {

    friend class _LogicFactory::FactoryInterningManager<AtomNegation>;

protected:
    
    Atom m_atom;
    
    _AtomNegation(_LogicFactory* const factory, const size_t hash, const Atom& atom);

    static size_t hashCodeFor(const Atom& atom);
    
    bool isEqual(const Atom& atom) const;
    
    virtual LogicObject doClone(const LogicFactory& logicFactory) const;
    
    virtual Formula doApply(const Substitution& substitution, const bool renameImplicitExistentialVariables, size_t& formulaWithImplicitExistentialVariablesCounter) const;
    
public:
    
    virtual ~_AtomNegation();
    
    always_inline AtomNegation clone(const LogicFactory& logicFactory) const {
        return static_pointer_cast<AtomNegation>(doClone(logicFactory));
    }
    
    virtual const Atom& getAtom() const;

    virtual FormulaType getType() const;
    
    always_inline AtomNegation applyEx(const Substitution& substitution, const bool renameImplicitExistentialVariables, size_t& formulaWithImplicitExistentialVariablesCounter) const {
        return static_pointer_cast<AtomNegation>(doApply(substitution, renameImplicitExistentialVariables, formulaWithImplicitExistentialVariablesCounter));
    }
    
    always_inline AtomNegation apply(const Substitution& substitution) const {
        size_t formulaWithImplicitExistentialVariablesCounter = 0;
        return applyEx(substitution, false, formulaWithImplicitExistentialVariablesCounter);
    }
    
    virtual void accept(LogicObjectVisitor& visitor) const;
    
    virtual std::string toString(const Prefixes& prefixes) const;
    
};

#endif /* ATOMNEGATION_H_ */
