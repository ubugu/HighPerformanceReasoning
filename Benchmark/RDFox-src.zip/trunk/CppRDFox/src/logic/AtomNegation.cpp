// RDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

#include "Logic.h"

_AtomNegation::_AtomNegation(_LogicFactory* const factory, const size_t hash, const Atom& atom) :
    _Literal(factory, hash, atom->getArguments()),
    m_atom(atom)
{
}

size_t _AtomNegation::hashCodeFor(const Atom& atom) {
    size_t result = atom->hash();
    result += (result << 10);
    result ^= (result >> 6);

    result += (result << 3);
    result ^= (result >> 11);
    result += (result << 15);
    return result;
}

bool _AtomNegation::isEqual(const Atom& atom) const {
    return m_atom == atom;
}

LogicObject _AtomNegation::doClone(const LogicFactory& logicFactory) const {
    Atom newAtom = m_atom->clone(logicFactory);
    return logicFactory->getAtomNegation(newAtom);
}

Formula _AtomNegation::doApply(const Substitution& substitution, const bool renameImplicitExistentialVariables, size_t& formulaWithImplicitExistentialVariablesCounter) const {
    Atom newAtom = m_atom->applyEx(substitution, renameImplicitExistentialVariables, formulaWithImplicitExistentialVariablesCounter);
    return m_factory->getAtomNegation(newAtom);
}

_AtomNegation::~_AtomNegation() {
    m_factory->dispose(this);
}

const Atom& _AtomNegation::getAtom() const {
    return m_atom;
}

FormulaType _AtomNegation::getType() const {
    return ATOM_NEGATION_FORMULA;
}

void _AtomNegation::accept(LogicObjectVisitor& visitor) const {
    visitor.visit(AtomNegation(this));
}

std::string _AtomNegation::toString(const Prefixes& prefixes) const {
    std::ostringstream buffer;
    buffer << "not " << m_atom->toString(prefixes);
    return buffer.str();
}
