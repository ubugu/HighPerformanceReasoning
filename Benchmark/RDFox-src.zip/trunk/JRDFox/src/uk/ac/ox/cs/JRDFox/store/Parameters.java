// JRDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

// Changes to this file require changes in the java-bridge.

package uk.ac.ox.cs.JRDFox.store;

public class Parameters {
	
	public enum QueryDomain {
		EDB,
		IDB,
		IDBrep,
		IDBrepNoEDB
	}
	
	public boolean m_useBushy = false;
	public boolean m_useDistinct = false;
	public boolean m_exactCardinality = true;
	public boolean m_allAnswersInRoot = false;
	public int m_windowSize = 1000;
	public QueryDomain m_queryDomain = QueryDomain.IDB;
}
