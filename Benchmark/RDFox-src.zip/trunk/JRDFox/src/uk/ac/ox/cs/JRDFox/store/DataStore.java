// JRDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

package uk.ac.ox.cs.JRDFox.store;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.semanticweb.owlapi.model.OWLOntology;

import uk.ac.ox.cs.JRDFox.JRDFoxException;
import uk.ac.ox.cs.JRDFox.Prefixes;
import uk.ac.ox.cs.JRDFox.model.Atom;
import uk.ac.ox.cs.JRDFox.model.BlankNode;
import uk.ac.ox.cs.JRDFox.model.Datatype;
import uk.ac.ox.cs.JRDFox.model.GroundTerm;
import uk.ac.ox.cs.JRDFox.model.Individual;
import uk.ac.ox.cs.JRDFox.model.Literal;
import uk.ac.ox.cs.JRDFox.model.Rule;
import uk.ac.ox.cs.JRDFox.owl2rl.OWL2RLTranslator;
import uk.ac.ox.cs.JRDFox.owl2rl.RuleListener;

public class DataStore {

	public enum UpdateType {
		Add,
		ScheduleForAddition,
		ScheduleForDeletion
	}
	
	public enum EqualityAxiomatizationType {
		/** No equality handling. */
		Off("off"),
		/** Native equality handling without the unique name assumption. */
		NoUNA("noUNA"),
		/** Native equality handling with the unique name assumption. */
		UNA("UNA");
		
		public final static String s_key = "equality";
		
		protected final String m_type;
	    
	    private EqualityAxiomatizationType(String type) {
	    	m_type = type;
	    }
	    
	    public String getType() {
	    	return m_type;
	    }
	}
	
	public enum Format {
		Turtle("Turtle"),
		NTriples("N-Triples"),
		Datalog("Datalog");		
		
		protected final String m_name;
	    
	    private Format(String name) {
	    	m_name = name;
	    }
	    
	    public String getName() {
	    	return m_name;
	    }
	}

	/**
	 * The different store types supported by RDFox.
	 * 
	 * The SequentialHead store uses the RDFox default data layout. The SequentialHead store is 
	 * sequential, which means that it should be used from one thread only. In particular, 
	 * reasoning should be done with one thread, and also only one query at a time should be 
	 * issued. It can store up to 2^48 triples.
	 *
	 * The SequentialTail store uses an experimental data layout which in certain cases achieves
	 * faster reasoning. The SequentialTail store is sequential, which means that it should be 
	 * used from one thread only. In particular, reasoning should be done with one thread, and 
	 * also only one query at a time should be issued. It can store up to 2^48 triples.
	 * 
	 * The NarrowParallelHead store uses the RDFox default data layout. The NarrowParallelHead store is 
	 * parallel, which means that it supports parallel operation, both for reasoning and for query 
	 * answering. It can store up to 2^32 triples.
	 * 
	 * The WideParallelHead store uses the RDFox default data layout. The WideParallelHead store is 
	 * parallel, which means that it supports parallel operation, both for reasoning and for query 
	 * answering. It can store up to 2^64 triples at the expense of higher memory consumption per triple.
	 *  
	 */
	public enum StoreType {
		/**
		 * The Sequential store uses the RDFox default data layout. The store is sequential, which 
		 * means that it should be used from one thread only. In particular, reasoning should be 
		 * done with one thread, and also only one query at a time should be issued. It can store 
		 * up to 2^48 triples.
		 */
		Sequential("seq"),
		
		/**
		 * The ParallelSimpleNN store uses the RDFox default data layout. The store is parallel, which
		 * means that it supports parallel operation, both for reasoning and for query answering. 
		 * It employs a simple indexing scheme designed for highly-efficient updates. It can store up 
		 * to 2^32 resources and up to 2^32 triples.  
		 */
		ParallelSimpleNN("par-simple-nn"),
		
		/**
         * The ParallelSimpleNN store uses the RDFox default data layout. The store is parallel, which
         * means that it supports parallel operation, both for reasoning and for query answering. 
         * It employs a simple indexing scheme designed for highly-efficient updates. It can store up to 
         * 2^32 resources and up to 2^64 triples. 
         */
		ParallelSimpleNW("par-simple-nw"),
		
		/**
         * The ParallelSimpleNN store uses the RDFox default data layout. The store is parallel, which
         * means that it supports parallel operation, both for reasoning and for query answering. 
         * It employs a simple indexing scheme designed for highly-efficient updates. It can store up to 
         * 2^64 resources and up to 2^64 triples. 
         */
        ParallelSimpleWW("par-simple-ww"),
        
        /**
         * The ParallelSimpleNN store uses the RDFox default data layout. The store is parallel, which
         * means that it supports parallel operation, both for reasoning and for query answering. 
         * It employs a complex indexing scheme designed for highly-efficient data access. It can store up 
         * to 2^32 resources and up to 2^32 triples.  
         */
        ParallelComplexNN("par-complex-nn"),
        
        /**
         * The ParallelSimpleNN store uses the RDFox default data layout. The store is parallel, which
         * means that it supports parallel operation, both for reasoning and for query answering. 
         * It employs a complex indexing scheme designed for highly-efficient data access. It can store up 
         * to 2^32 resources and up to 2^64 triples. 
         */
        ParallelComplexNW("par-complex-nw"),
        
        /**
         * The ParallelSimpleNN store uses the RDFox default data layout. The store is parallel, which
         * means that it supports parallel operation, both for reasoning and for query answering. 
         * It employs a complex indexing scheme designed for highly-efficient data access. It can store up 
         * to 2^64 resources and up to 2^64 triples. 
         */
        ParallelComplexWW("par-complex-ww");

		private final String m_type;

		private StoreType(String type) {
			m_type = type;
		}

		public String getType() {
			return m_type;
		}

	}

	static {
		try {
			String logAPI = (System.getProperty("log.RDFox") != null && !System.getProperty("log.RDFox").equalsIgnoreCase("false")) ? "-logAPI" : "";
			String libName = "CppRDFox" + logAPI;
			String libJarSource = "/uk/ac/ox/cs/JRDFox/dll/libCppRDFox" + logAPI;
			Field loadedLibraryNames = ClassLoader.class.getDeclaredField("loadedLibraryNames");
			loadedLibraryNames.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<String> loadedLibraries = (List<String>)loadedLibraryNames.get(null);
			boolean loaded = false;
			for (String library : loadedLibraries)
				if (library.contains("CppRDFox"))
					loaded = true;
			if (!loaded)
				if (!loadRDFoxFromJar(libJarSource))  
					System.loadLibrary(libName);
		}
		catch (IOException e) {
			throw new RuntimeException(e);
		}
		catch (NoSuchFieldException e) {
			throw new RuntimeException(e);
		}
		catch (IllegalAccessException e) {
			throw new RuntimeException(e);
		}
	}

	protected static boolean loadRDFoxFromJar(String path) throws IOException {
		InputStream inputStream = DataStore.class.getResourceAsStream(path);
		if (inputStream == null)
			return false;
		try {
			File temp = File.createTempFile("CppRDFox", ".dylib");
			if (!temp.exists())
				return false;
			temp.deleteOnExit();
			byte[] buffer = new byte[1024];
			int readBytes;
			OutputStream outputStream = new FileOutputStream(temp);
			try {
				while ((readBytes = inputStream.read(buffer)) != -1)
					outputStream.write(buffer, 0, readBytes);
			}
			finally {
				outputStream.close();
			}
			System.load(temp.getAbsolutePath());
			return true;
		}
		finally {
			inputStream.close();
		}
	}

	protected volatile long m_storePtr;
	protected final Dictionary m_dictionary;
	protected volatile long m_generation;

	protected native static void nCreate(String dataStoreType, String[] parameterKeys, String[] parameterValues, long[] pointers) throws JRDFoxException;

	protected native static void nInitialize(long dataStorePtr) throws JRDFoxException;

	protected native static long nGetTriplesCount(long dataStorePtr) throws JRDFoxException;

	protected native static void nSetNumberOfThreads(long dataStorePtr, int numberOfThreads) throws JRDFoxException; 

	protected native static void nAddTriples(long dataStorePtr, String[] lexicalForms, int[] datatypeIDs, int numberOfResources, int updateType) throws JRDFoxException;

	protected native static void nAddTriplesByResourceIDs(long dataStorePtr, long[] resourceIDs, int numberOfResources, int updateType) throws JRDFoxException;

	protected native static void nImportFiles(long dataStorePtr, String[] fileNames, int updateType, boolean useTreeDecomposition) throws JRDFoxException;

	protected native static void nImportText(long dataStorePtr, String text, int updateType, boolean useTreeDecomposition, String[] prefixes) throws JRDFoxException;
	
	protected native static void nExport(long dataStorePtr, String fileName, String formatName) throws JRDFoxException;

	protected native static void nApplyRules(long dataStorePtr, boolean incrementally) throws JRDFoxException;

	protected native static void nUpdateStatistics(long dataStorePtr) throws JRDFoxException;
	
	protected native static void nMakeFactsExplicit(long dataStorePtr) throws JRDFoxException;

	protected native static void nClearRulesAndMakeFactsExplicit(long dataStorePtr) throws JRDFoxException;

	protected native static void nSave(long datastorePtr, String fileName) throws JRDFoxException;

	protected native static void nLoad(String fileName, long[] pointers) throws JRDFoxException;

	protected native static void nDispose(long dataStorePtr);

	protected void ensureValidState() throws JRDFoxException {
		if (m_storePtr == 0)
			throw new JRDFoxException("This store has already been disposed and thus cannot be accessed any more.");
	}

	public DataStore(final StoreType dataStoreType) throws JRDFoxException {
		this(dataStoreType, EqualityAxiomatizationType.Off);
	}

	public DataStore(final StoreType dataStoreType, final EqualityAxiomatizationType equalityAxiomatizationType) throws JRDFoxException {
		this(dataStoreType, equalityAxiomatizationType, true, true);
	}
	
	public DataStore(final StoreType dataStoreType, final EqualityAxiomatizationType equalityAxiomatizationType, final boolean cacheResources, final boolean cacheGroundTerms) throws JRDFoxException {
		this(dataStoreType, 
				new HashMap<String, String>() {
					private static final long serialVersionUID = 1L;
					{ this.put(EqualityAxiomatizationType.s_key, equalityAxiomatizationType.m_type);} }, 
				cacheResources, 
				cacheGroundTerms);
	}
	
	public DataStore(final StoreType dataStoreType, final HashMap<String, String> parameters, final boolean cacheResources, final boolean cacheGroundTerms) throws JRDFoxException {
		long[] pointers = new long[2];
		String[] keys = new String[parameters.size()];
		String[] values = new String[parameters.size()];
		int index = 0;
		for (Entry<String, String> mapEntry : parameters.entrySet()) {
			keys[index] = mapEntry.getKey();
			values[index] = mapEntry.getValue();
		}
		nCreate(dataStoreType.getType(), keys, values, pointers);
		m_storePtr = pointers[0];
		m_dictionary = new Dictionary(this, pointers[1], cacheResources, cacheGroundTerms);
		m_generation = 1;
		initialize();
	}

	public DataStore(final File file) throws JRDFoxException {
		this(file, true);        
	}
	
	public DataStore(final File file, final boolean nativeEqualityResouning) throws JRDFoxException {
		this(file, nativeEqualityResouning, false, true);
	}
	
	public DataStore(final File file, final boolean nativeEqualityResouning, final boolean cacheResources, final boolean cacheGroundTerms) throws JRDFoxException {
		long[] pointers = new long[2];        
		nLoad(file.getAbsolutePath(), pointers);
		m_storePtr = pointers[0];
		m_dictionary = new Dictionary(this, pointers[1], cacheResources, cacheGroundTerms);
		m_generation = 1;
		m_dictionary.initialize();		
	}

	/**
	 * Initializes an empty store.
	 * 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public synchronized void initialize() throws JRDFoxException {
		ensureValidState();
		m_generation++;
		m_dictionary.initialize();
		nInitialize(m_storePtr);
	}

	/**
	 * @return the number of triples currently in the store
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public long getTriplesCount() throws JRDFoxException {
		ensureValidState();
		return nGetTriplesCount(m_storePtr);
	}

	/**
	 * Sets the number of threads used during reasoning and parallel import of data,
	 * 
	 * @param numberOfThreads       the new number of threads to use
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void setNumberOfThreads(final int numberOfThreads) throws JRDFoxException {
		ensureValidState();
		nSetNumberOfThreads(m_storePtr, numberOfThreads);
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param triples               the triples to be added to the store
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriples(final Resource[] triples) throws JRDFoxException {
		addTriples(triples, triples.length, UpdateType.Add);
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param triples               the triples to be added to the store
	 * @param updateType            determines what action should be performed on the triples 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriples(final Resource[] triples, final UpdateType updateType) throws JRDFoxException { 
		addTriples(triples, triples.length, updateType);
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param triples               the triples to be added to the store
	 * @param numberOfResources		the number of entries in the <code>triples</code> array that should be added
	 * @param updateType            determines what action should be performed on the triples 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriples(final Resource[] triples, final int numberOfResources, final UpdateType updateType) throws JRDFoxException { 
		ensureValidState();
		if (numberOfResources % 3 != 0)
			throw new JRDFoxException("Invalid input: the number of resources should be a multiple of 3.");
		String[] lexicalForms = new String[numberOfResources];
		int[] datatypeIDs = new int[numberOfResources];                
		for (int index = 0; index < numberOfResources; index ++) {
			lexicalForms[index] = triples[index].m_lexicalForm;
			datatypeIDs[index] = triples[index].m_datatype.getDatatypeID();
		}
		nAddTriples(m_storePtr, lexicalForms, datatypeIDs, numberOfResources, updateType.ordinal());
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param triples               the triples to be added to the store
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriples(final GroundTerm[] triples) throws JRDFoxException {
		addTriples(triples, triples.length, UpdateType.Add);
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param triples               the triples to be added to the store
	 * @param updateType            determines what action should be performed on the triples 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriples(final GroundTerm[] triples, final UpdateType updateType) throws JRDFoxException {
		addTriples(triples, triples.length, updateType);
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param triples               the triples to be added to the store
	 * @param numberOfResources		the number of entries in the <code>triples</code> array that should be added
	 * @param updateType            determines what action should be performed on the triples 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriples(final GroundTerm[] triples, final int numberOfResources, final UpdateType updateType) throws JRDFoxException { 
		ensureValidState();
		if (numberOfResources % 3 != 0)
			throw new JRDFoxException("Invalid input: the number of resources should be a multiple of 3.");
		String[] lexicalForms = new String[numberOfResources];
		int[] datatypeIDs = new int[numberOfResources];                
		for (int index = 0; index < numberOfResources; index ++)         	
			writeTerm(triples[index], index, lexicalForms, datatypeIDs);
		nAddTriples(m_storePtr, lexicalForms, datatypeIDs, numberOfResources, updateType.ordinal());
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param lexicalForms			the lexical forms of the triple resources
	 * @param datatypeIDs			the datatype IDs of the triple resources
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriples(final String[] lexicalForms, final int[] datatypeIDs) throws JRDFoxException {
		addTriples(lexicalForms, datatypeIDs, lexicalForms.length, UpdateType.Add);
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param lexicalForms			the lexical forms of the triple resources
	 * @param datatypeIDs			the datatype IDs of the triple resources
	 * @param updateType            determines what action should be performed on the triples 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriples(final String[] lexicalForms, final int[] datatypeIDs, final UpdateType updateType) throws JRDFoxException {
		addTriples(lexicalForms, datatypeIDs, lexicalForms.length, updateType);
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param lexicalForms			the lexical forms of the triple resources
	 * @param datatypeIDs			the datatype IDs of the triple resources
	 * @param numberOfResources		the number of entries in the <code>triples</code> array that should be added
	 * @param updateType            determines what action should be performed on the triples 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriples(final String[] lexicalForms, final int[] datatypeIDs, final int numberOfResources, final UpdateType updateType) throws JRDFoxException { 
		ensureValidState();
		if (numberOfResources % 3 != 0)
			throw new JRDFoxException("Invalid input: the number of resources should be a multiple of 3.");
		if (numberOfResources > lexicalForms.length)
			throw new JRDFoxException("Invalid input: the number of resources is larger than the number of lexical forms.");
		if (numberOfResources > datatypeIDs.length)
			throw new JRDFoxException("Invalid input: the number of resources is larger than the number of datatype IDs.");
		nAddTriples(m_storePtr, lexicalForms, datatypeIDs, numberOfResources, updateType.ordinal());
	}
	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param triples               the triples to be added to the store
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriplesByResourceIDs(final long[] triples) throws JRDFoxException {
		addTriplesByResourceIDs(triples, triples.length, UpdateType.Add);
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param triples               the triples to be added to the store
	 * @param updateType            determines what action should be performed on the triples
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriplesByResourceIDs(final long[] triples, final UpdateType updateType) throws JRDFoxException {
		addTriplesByResourceIDs(triples, triples.length, updateType);
	}

	/**
	 * Adds the specified triples to the store without performing reasoning.
	 * 
	 * @param triples               the triples to be added to the store
	 * @param numberOfResources		the number of entries in the <code>triples</code> array that should be added
	 * @param updateType            determines what action should be performed on the triples
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void addTriplesByResourceIDs(final long[] triples, final int numberOfResources, UpdateType updateType) throws JRDFoxException { 
		ensureValidState();       
		if (numberOfResources % 3 != 0)
			throw new JRDFoxException("Invalid input: the number of resources should be a multiple of 3.");
		nAddTriplesByResourceIDs(m_storePtr, triples, numberOfResources, updateType.ordinal());
	}

	protected void writeTerm(final GroundTerm term, final int index, final String[] lexicalForms, final int[] datatypeIDs) throws JRDFoxException {
		if (term instanceof Individual) {
			lexicalForms[index] = ((Individual)term).getIRI();
			datatypeIDs[index] = Datatype.IRI_REFERENCE.getDatatypeID();
		}
		else if (term instanceof BlankNode) {
			lexicalForms[index] = ((BlankNode)term).getID();
			datatypeIDs[index] = Datatype.BLANK_NODE.getDatatypeID();
		}
		else if (term instanceof Literal) {
			lexicalForms[index] = ((Literal)term).getLexicalForm();
			String datatypeIRI = ((Literal)term).getDatatype().getIRI();
			Datatype datatype = Datatype.value(datatypeIRI);
			if (datatype != null)
				datatypeIDs[index] = datatype.getDatatypeID();
			else
				throw new JRDFoxException("Unknown datatype IRI:" + datatypeIRI);
		}
	}

	/**
	 * Imports the specified datalog or data files; the importation is done in parallel if the store supports it.
	 * 
	 * @param files                 the files to be imported
	 * @param prefixes              the prefixes to be populated
	 * @param updateType            determines what action should be performed on the triples
	 * @param useTreeDecomposition  determines whether rules should be optimized using tree decomposition
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importFiles(final File[] files, final Prefixes prefixes, final UpdateType updateType, final boolean useTreeDecomposition) throws JRDFoxException {
		ensureValidState();
		String[] fileNames = new String[files.length];
		for (int index = 0; index < files.length; index++)
			fileNames[index] = files[index].getAbsolutePath();
		nImportFiles(m_storePtr, fileNames, updateType.ordinal(), useTreeDecomposition);
	}

	/**
	 * Imports the specified datalog or data files; the importation is done in parallel if the store supports it.
	 * 
	 * @param files                 the files to be imported
	 * @param prefixes              the prefixes to be populated
	 * @param updateType            determines what action should be performed on the data
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importFiles(final File[] files, final Prefixes prefixes, final UpdateType updateType) throws JRDFoxException {
		importFiles(files, prefixes, updateType, false);
	}
	
	/**
	 * Imports the specified datalog or data files; the importation is done in parallel if the store supports it.
	 * 
	 * @param files                 the files to be imported
	 * @param prefixes              the prefixes to be populated
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importFiles(final File[] files, final Prefixes prefixes) throws JRDFoxException {
		importFiles(files, prefixes, UpdateType.Add);
	}

	/**
	 * Imports the specified datalog or data files; the importation is done in parallel if the store supports it.
	 * 
	 * @param files                 the files to be imported
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importFiles(final File[] files) throws JRDFoxException {		
		importFiles(files, new Prefixes());
	}
	
	/**
	 * Imports the specified datalog or data files; the importation is done in parallel if the store supports it.
	 * 
	 * @param text                  the textual representation of the imported data
	 * @param prefixes              the prefixes to be populated
	 * @param updateType            determines what action should be performed on the triples
	 * @param useTreeDecomposition  determines whether rules should be optimized using tree decomposition
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importText(final String text, final Prefixes prefixes, final UpdateType updateType, final boolean useTreeDecomposition) throws JRDFoxException {
		ensureValidState();
		nImportText(m_storePtr, text, updateType.ordinal(), useTreeDecomposition, Utilities.mapToStringArray(prefixes.getPrefixIRIsByPrefixName()));
	}

	/**
	 * Imports the specified datalog or data files; the importation is done in parallel if the store supports it.
	 * 
	 * @param text                  the textual representation of the imported data
	 * @param prefixes              the prefixes to be populated
	 * @param updateType            determines what action should be performed on the data
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importText(final String text, final Prefixes prefixes, final UpdateType updateType) throws JRDFoxException {
		importText(text, prefixes, updateType, false);
	}
	
	/**
	 * Imports the specified datalog or data files; the importation is done in parallel if the store supports it.
	 * 
	 * @param text                  the textual representation of the imported data
	 * @param prefixes              the prefixes to be populated
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importText(final String text, final Prefixes prefixes) throws JRDFoxException {
		importText(text, prefixes, UpdateType.Add);
	}

	/**
	 * Imports the specified datalog or data files; the importation is done in parallel if the store supports it.
	 * 
	 * @param text                  the textual representation of the imported data
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importText(final String text) throws JRDFoxException {		
		importText(text, new Prefixes());
	}

	/**
	 * Imports the datalog fragment of the ontology into the store.
	 * 
	 * @param ontology          	the ontology to be transformed
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importOntology(final OWLOntology ontology) throws JRDFoxException {
		importOntology(ontology, UpdateType.Add);
	}

	/**
	 * Imports the datalog fragment of the ontology into the store.
	 * 
	 * @param ontology          	the ontology to be transformed
	 * @param updateType            determines what action should be performed on the triples
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importOntology(final OWLOntology ontology, final UpdateType updateType) throws JRDFoxException {
		importOntology(ontology, updateType, true, false);
	}

	/**
	 * Imports the datalog fragment of the ontology into the store.
	 * 
	 * @param ontology          	the ontology to be transformed
	 * @param updateType            determines what action should be performed on the triples
	 * @param processTBoxAxioms		specifies whether the TBox axioms in the ontology should be processed
	 * @param processABoxAxioms		specifies whether the ABox axioms in the ontology should be processed
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importOntology(final OWLOntology ontology, final UpdateType updateType, final boolean processTBoxAxioms, final boolean processABoxAxioms) throws JRDFoxException {
		importOntology(ontology, updateType, processTBoxAxioms, processABoxAxioms, false);
	}

	/**
	 * Imports the triples and the datalog fragment of the ontology into the store.
	 * 
	 * @param ontology              the ontology to be transformed
	 * @param updateType            determines what action should be performed on the triples
	 * @param processTBoxAxioms		specifies whether the TBox axioms in the ontology should be processed
	 * @param processABoxAxioms		specifies whether the ABox axioms in the ontology should be processed
	 * @param useTreeDecomposition  determines whether to optimize the rules using tree decomposition
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void importOntology(final OWLOntology ontology, final UpdateType updateType, final boolean processTBoxAxioms, final boolean processABoxAxioms, final boolean useTreeDecomposition) throws JRDFoxException {
		ensureValidState();
		final String CRLF = System.getProperty("line.separator");
		final int importWindowSize = 3 * 10;
		final List<Resource> resources = new ArrayList<Resource>(importWindowSize);
		List<JRDFoxException> errors = new ArrayList<JRDFoxException>();
		final StringBuilder buffer = new StringBuilder();
		new OWL2RLTranslator(new RuleListener() {
			public void addRule(Rule rule) {
				rule.toString(buffer, Prefixes.DEFAULT_IMMUTABLE_INSTANCE);
				buffer.append(CRLF);
			}
			public void addAtom(Atom atom) {
				if (!atom.isGround())
					return;
				GroundTerm subject = (GroundTerm)atom.getArgument(0); 
				if (subject instanceof BlankNode)
					resources.add(new Resource(((BlankNode)subject).getID(), Datatype.BLANK_NODE));
				else
					resources.add(new Resource(((Individual)subject).getIRI(), Datatype.IRI_REFERENCE));            	
				if (atom.getNumberOfArguments() == 2) {
					resources.add(new Resource(atom.getPredicate().getIRI(), Datatype.IRI_REFERENCE));            		
					GroundTerm object = (GroundTerm)atom.getArgument(1);
					if (object instanceof BlankNode)
						resources.add(new Resource(((BlankNode)object).getID(), object.getDatatype()));
					else if (object instanceof Individual)
						resources.add(new Resource(((Individual)object).getIRI(), object.getDatatype()));
					else if (object instanceof Literal)
						resources.add(new Resource(((Literal)object).getLexicalForm(), object.getDatatype()));
					else 
						throw new Error("Unknown ground term type.");
				}
				else if (atom.getNumberOfArguments() == 1) {
					resources.add(new Resource("http://www.w3.org/1999/02/22-rdf-syntax-ns#type", Datatype.IRI_REFERENCE));
					resources.add(new Resource(atom.getPredicate().getIRI(), Datatype.IRI_REFERENCE));
				}
				else
					throw new Error("Unsupported arity: " + atom.getNumberOfArguments());				
				if (resources.size() == importWindowSize) {
					try {
						addTriples(resources.toArray(new Resource[resources.size()]));						
					}
					catch (JRDFoxException e) {
					}
					finally {
						resources.clear();
					}
				}
			}
		}, errors, processTBoxAxioms, processABoxAxioms).translate(ontology, true);
		if (resources.size() > 0)
			addTriples(resources.toArray(new Resource[resources.size()]));
		importText(new String(buffer.toString()), Prefixes.DEFAULT_IMMUTABLE_INSTANCE, updateType, useTreeDecomposition);
	}
	

	/**
	 * Exports the triples of the current store into a file
	 * @param outputFile			the output file
	 * @param format				the format
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void export(final File outputFile, final Format format) throws JRDFoxException {
		ensureValidState();
		nExport(m_storePtr, outputFile.getAbsolutePath(), format.getName());
	}

	/**
	 * Performs reasoning with the rules and data currently loaded into the store.
	 * 
	 * @param incrementally         determines whether to reason incrementally
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void applyReasoning(final boolean incrementally) throws JRDFoxException {
		ensureValidState();
		nApplyRules(m_storePtr, incrementally);
	}

	/**
	 * Performs reasoning with the rules and data currently loaded into the store.
	 * 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void applyReasoning() throws JRDFoxException {
		applyReasoning(false);
	}

	/**
	 * Updates the statistical information about the data in the store. This information is used to optimize query and rule processing.
	 * 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void updateStatistics() throws JRDFoxException {
		ensureValidState();
		nUpdateStatistics(m_storePtr);
	}

	/**
	 * Makes all facts explicit.
	 * 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void makeFactsExplicit() throws JRDFoxException {
		ensureValidState();
		nMakeFactsExplicit(m_storePtr);
	}

	/**
	 * Removes all rules and makes the current facts EDBs.
	 * 
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void clearRulesAndMakeFactsExplicit() throws JRDFoxException {
		ensureValidState();
		nClearRulesAndMakeFactsExplicit(m_storePtr);
	}

	/**
	 * Saves the current store into a file.
	 * 
	 * @param file                  the file where the store is saved.
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public void save(final File file) throws JRDFoxException {
		ensureValidState();
		nSave(m_storePtr, file.getAbsolutePath());
	}

	/**
	 * Compiles a query.
	 * 
	 * @param query                 the query
	 * @param prefixes              the prefixes used in the query
	 * @param parameters            the parameters used during query compilation
	 * @return                      a tuple iterator
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public TupleIterator compileQuery(final String query, final Prefixes prefixes, final Parameters parameters) throws JRDFoxException {
		ensureValidState();		
		return new TupleIterator(this, query, prefixes, parameters);
	}

	/**
	 * Compiles a query.
	 * 
	 * @param query                 the query
	 * @param prefixes              the prefixes used in the query
	 * @return                      a tuple iterator
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public TupleIterator compileQuery(final String query, final Prefixes prefixes) throws JRDFoxException { 
		return compileQuery(query, prefixes, new Parameters());
	}

	/**
	 * Compiles a query.
	 * 
	 * @param query                 the query
	 * @return                      a tuple iterator
	 * @throws JRDFoxException   thrown if there is an error
	 */
	public TupleIterator compileQuery(final String query) throws JRDFoxException {
		return compileQuery(query, Prefixes.EMPTY_IMMUTABLE_INSTANCE);
	}

	/**
	 * Retrieves the dictionary object for the current store
	 * @return Returns the dictionary used by the current store
	 * @throws JRDFoxException	thrown if the store has been disposed
	 */
	public Dictionary getDictionary() throws JRDFoxException {
		return m_dictionary;
	}

	/**
	 * Disposes the store. Make sure you always call this method once the store is no longer needed!
	 */
	public synchronized void dispose() {
		if (m_storePtr != 0) {
			nDispose(m_storePtr);
			m_storePtr = 0;
			m_dictionary.m_dictionaryPtr = 0;
		}
	}

	protected void finalize() {
		dispose();
	}

}
