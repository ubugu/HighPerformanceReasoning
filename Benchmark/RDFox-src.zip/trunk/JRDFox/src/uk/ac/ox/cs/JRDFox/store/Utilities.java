// JRDFox(c) Copyright University of Oxford, 2013. All Rights Reserved.

package uk.ac.ox.cs.JRDFox.store;

import java.util.Map;

import uk.ac.ox.cs.JRDFox.Prefixes;

class Utilities {
	
	static public String[] mapToStringArray(Map<String, String> map) {
		String[] stringArray = new String[2 * map.size()];
		int currentIndex = 0;
		for (Map.Entry<String, String> entry : map.entrySet()) {
			stringArray[currentIndex++] = entry.getKey();
			stringArray[currentIndex++] = entry.getValue();
		}
		return stringArray;
	}
	
	static public void stringArrayToMap(String[] strings, Map<String, String> map) {
		for (int prefixIndex = 0; prefixIndex < strings.length; prefixIndex += 2) 
			map.put(strings[prefixIndex], strings[prefixIndex + 1]);
	}
	
	static public void stringArrayToPrefixes(String[] strings, Prefixes prefixes) {
		for (int prefixIndex = 0; prefixIndex < strings.length; prefixIndex += 2) 
			prefixes.declarePrefix(strings[prefixIndex], strings[prefixIndex + 1]);
	}
}
